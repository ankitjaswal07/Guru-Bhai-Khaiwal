# Satta20 – Custom WordPress Theme

Exact recreation of the current satta20.com design as a clean, lightweight, fully dynamic
WordPress theme (no Elementor). Content is managed with **ACF PRO**; all game / result data
comes from your **existing results plugin** through its shortcodes.

```
Existing plugin (games, results, charts)  ──shortcodes──►  Theme (design + ACF content)
```

## Requirements
* WordPress 6.3+, PHP 7.4+
* Advanced Custom Fields PRO (active)
* Your existing results plugin (active)

## Installation
1. Zip the `satta20` folder (or download the ZIP from the preview app) and upload it under
   **Appearance › Themes › Add New › Upload Theme**, then activate.
2. Go to **Satta20 › Shortcodes** and paste your plugin's shortcodes
   (Games, Live status, Today, Yesterday, Current month, Previous month, Result chart).
3. **Appearance › Menus** – assign your menu to *Primary Menu (Header)*.
4. **Settings › Reading** – set the static front page + posts page (Blog).
5. Assign page templates: *Result Chart*, *Results: Today*, *Results: Yesterday*,
   *Results: Monthly*, *Results: Single Game Chart* (per-game pages), *Contact Page*, *FAQ Page*.
   Each of these pages has a **Results Page Settings** box for its own shortcode.
6. Review every tab of **Satta20 › General / Header / Homepage / Results / Contact /
   Payment / FAQ / Footer / Social** – all defaults mirror the live site and are editable.

Repeaters (promo cards, payment methods, FAQ items, footer columns, contact details,
social links) are seeded once with the live-site content on first admin load.

## Structure
```
satta20/
├── style.css, functions.php
├── header.php, footer.php, front-page.php, page.php, single.php, home.php, archive.php,
│   index.php, search.php, 404.php, searchform.php, comments.php
├── inc/                 theme-setup, enqueue, helpers, icons, shortcodes, acf, acf-options,
│                        acf-fields, acf-defaults, template-functions, blog, contact-form
├── template-parts/      header/ hero/ games/ payment/ results/ promotional/ contact/ blog/ faq/ footer/
├── page-templates/      template-result-chart, -today-results, -yesterday-results,
│                        -monthly-results, -game-results, -contact, -faq
└── assets/css (main, header, homepage, results, tables, blog, faq, footer, responsive, admin)
    assets/js  (navigation, main, blog, faq)
```

## Shortcode rendering
`s20_resolve_shortcode( $page_field, $option_field )` picks the page-level value first,
then the global Shortcode Settings value. `s20_shortcode_output()` passes it to
`do_shortcode()` and `s20_shortcode_section()` / `s20_render_shortcode()` wrap the output in
`.s20-table-scroll` so wide result tables scroll horizontally on small screens.
Empty shortcode fields hide the section (or show a configurable fallback message).

## Notes
* No Game / Result CPTs, no custom tables, no duplicate admin screens –
  *Satta20 › Games & Results →* is only a shortcut to your plugin's page.
* Compatible with Yoast SEO / Rank Math (title-tag, semantic markup, clean headings).
* Child-theme friendly: hooks `s20_front_page_sections`, `s20_option`, `s20_latest_posts_args`,
  `s20_is_results_context`.
