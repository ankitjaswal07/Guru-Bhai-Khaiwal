/**
 * Satta20 – homepage helpers: live date/time clock (d/m/Y H:i:s like the live site).
 */
(function () {
  'use strict';

  var clocks = document.querySelectorAll('[data-s20-clock]');
  if (!clocks.length) { return; }

  function pad(n) { return String(n).padStart(2, '0'); }

  function tick() {
    var now = new Date();
    var text = now.getDate() + '/' + (now.getMonth() + 1) + '/' + now.getFullYear() + ' ' +
      pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
    for (var i = 0; i < clocks.length; i++) { clocks[i].textContent = text; }
  }

  tick();
  setInterval(tick, 1000);
})();
