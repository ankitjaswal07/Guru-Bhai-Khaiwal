<?php
/**
 * 404 template.
 *
 * @package Satta20
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<section class="s20-section s20-page-section s20-404">
	<div class="s20-container s20-container--narrow s20-text-center">
		<p class="s20-404-code">404</p>
		<h1 class="s20-section-title"><?php esc_html_e( 'Page not found', 'satta20' ); ?></h1>
		<p><?php esc_html_e( 'The page you are looking for does not exist or has been moved.', 'satta20' ); ?></p>
		<div class="s20-section-action"><?php s20_button( __( 'Back to Home', 'satta20' ), home_url( '/' ) ); ?></div>
		<?php get_search_form(); ?>
	</div>
</section>
<?php
get_footer();
