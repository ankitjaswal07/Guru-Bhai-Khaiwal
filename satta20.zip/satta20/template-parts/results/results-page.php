<?php
/**
 * Shared layout for result page templates.
 *
 * @param array $args {
 *   @type array  $blocks  List of [ 'page_field' => '', 'option_field' => '', 'heading_option' => '', 'heading' => '' ].
 *   @type string $class   Extra classes.
 * }
 * @package Satta20
 */

defined( 'ABSPATH' ) || exit;

$args    = wp_parse_args( isset( $args ) ? $args : array(), array( 'blocks' => array(), 'class' => '' ) );
$post_id = get_the_ID();
$intro   = s20_get_field( 'page_intro', $post_id, s20_get_option( 'results_intro', '' ) );
$override = s20_get_field( 'page_heading', $post_id, '' );
$width   = (int) s20_get_option( 'results_container_width', 1500 );
$printed = 0;
?>
			<?php
		$index = 0;
		foreach ( $args['blocks'] as $block ) :
			$index++;
			$block     = wp_parse_args( $block, array( 'page_field' => '', 'option_field' => '', 'heading_option' => '', 'heading' => '' ) );
			$shortcode = s20_resolve_shortcode( $block['page_field'], $block['option_field'] );
			$output    = s20_shortcode_output( $shortcode );
			if ( '' === $output ) {
				$output = s20_shortcode_fallback();
			}
			$heading = $block['heading'];
			if ( 1 === $index && $override ) {
				$heading = $override;
			} elseif ( ! $heading && $block['heading_option'] ) {
				$heading = s20_get_option( $block['heading_option'], get_the_title() );
			}
			if ( 1 === $index ) {
				$heading = $heading ? $heading : get_the_title();
			}
			if ( '' === $output && ! $heading ) {
				continue;
			}
			?>
			<?php s20_section_heading( $heading, 1 === $index ? $intro : '', 1 === $index ? 'h1' : 'h2' ); ?>
<article id="post-<?php echo (int) $post_id; ?>" <?php post_class( 's20-section s20-page-section s20-results-page ' . $args['class'] ); ?>>

	<div class="s20-container s20-container--wide"<?php echo $width ? ' ' : ''; ?>>

			<div class="s20-results-block">

				<?php if ( '' !== $output ) : ?>
					<?php s20_scroll_hint(); ?>
					<div class="s20-shortcode s20-table-scroll"><?php echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plugin output. ?></div>
					<?php $printed++; ?>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>

		<?php if ( get_the_content() ) : ?>
			<div class="s20-entry-content s20-results-content"><?php the_content(); ?></div>
		<?php endif; ?>

		<?php s20_render_shortcode( s20_get_field( 'page_extra_shortcode', $post_id, '' ), 's20-results-extra' ); ?>
		<?php s20_render_page_sections( $post_id ); ?>

		<?php if ( 0 === $printed && current_user_can( 'manage_options' ) ) : ?>
			<p class="s20-admin-hint"><?php esc_html_e( 'Admin hint: no shortcode configured for this page. Add it in the "Results Page Settings" box of this page or in Satta20 > Shortcodes.', 'satta20' ); ?></p>
		<?php endif; ?>

		<?php s20_page_notice(); ?>
	</div>
</article>
