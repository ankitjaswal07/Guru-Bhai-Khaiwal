<?php
/**
 * Default content for repeater fields (ACF has no default_value for repeaters).
 *
 * Seeded ONCE into the ACF options (after theme activation) so administrators start
 * with the live-site content and can edit / delete anything afterwards.
 *
 * @package Satta20
 */

defined( 'ABSPATH' ) || exit;

function s20_default_promo_cards() {
	return array(
		array(
			'card_enabled'      => 1,
			'card_heading'      => '♕ LEAK LEAK LEAK ♕',
			'card_icon'         => 'none',
			'card_description'  => 'आज की आने वाली लीक जोडी पाने के लिए संपर्क करे 101 % पासिंग की गारंटी👍',
			'card_person_name'  => 'Vishu bhai',
			'card_phone_text'   => '☎ +917986030340 ☎️',
			'card_phone'        => '+917986030340',
			'card_whatsapp'     => '+917986030340',
			'card_button_text'  => 'Whatsaap Us',
			'card_button_url'   => '',
			'card_note'         => '',
		),
		array(
			'card_enabled'      => 1,
			'card_heading'      => '🙏🏻 नमस्कार साथियो 🙏🏻',
			'card_icon'         => 'whatsapp',
			'card_description'  => '👇 से कांटेक्ट करे इस नम्बर पर केवल खाईवाली का पर्चा देने के लिए ही msg करे! 👇',
			'card_person_name'  => '',
			'card_phone_text'   => '☎+918307492992☎️',
			'card_phone'        => '+918307492992',
			'card_whatsapp'     => '+918307492992',
			'card_button_text'  => 'Whatsaap Us',
			'card_button_url'   => '',
			'card_note'         => '',
		),
		array(
			'card_enabled'      => 1,
			'card_heading'      => '♕ आज की सोलिड जोडियां ♕',
			'card_icon'         => 'none',
			'card_description'  => 'पासिंग की फुल गांरटी👍',
			'card_person_name'  => 'Vishu Bhai',
			'card_phone_text'   => '☎+917986030340☎️',
			'card_phone'        => '+917986030340',
			'card_whatsapp'     => '+917986030340',
			'card_button_text'  => 'Whatsaap Us',
			'card_button_url'   => '',
			'card_note'         => '',
		),
	);
}

function s20_default_homepage_section_order() {
	return array_map(
		static function ( $section ) {
			return array( 'section' => $section );
		},
		array( 'hero', 'games', 'today_yesterday', 'promo', 'current_month', 'previous_month', 'contact_direct', 'contact_us', 'blog', 'faq' )
	);
}

function s20_default_payment_methods() {
	return array(
		array( 'image' => '', 'name' => 'Paytm', 'description' => '', 'active' => 1 ),
		array( 'image' => '', 'name' => 'Bank Transfer', 'description' => '', 'active' => 1 ),
		array( 'image' => '', 'name' => 'PhonePe', 'description' => '', 'active' => 1 ),
		array( 'image' => '', 'name' => 'Google Pay', 'description' => '', 'active' => 1 ),
	);
}

function s20_default_faq_items() {
	$file = S20_DIR . '/inc/data/faq-defaults.php';
	$items = file_exists( $file ) ? include $file : array();
	return is_array( $items ) ? $items : array();
}

function s20_default_footer_columns() {
	$quick = array(
		array( 'label' => 'Home', 'url' => '/', 'new_tab' => 0 ),
		array( 'label' => 'Result Chart', 'url' => '/result-chart/', 'new_tab' => 0 ),
		array( 'label' => 'FAQ', 'url' => '/faq/', 'new_tab' => 0 ),
		array( 'label' => 'Blog', 'url' => '/blog/', 'new_tab' => 0 ),
		array( 'label' => 'Contact', 'url' => '/contact/', 'new_tab' => 0 ),
	);

	// Result chart links: built from existing pages whose slug ends with "-results"
	// (these pages display the plugin's per-game chart shortcode). No game data is stored here.
	$charts = array();
	$pages  = get_pages( array( 'post_status' => 'publish', 'number' => 50, 'sort_column' => 'menu_order,post_title' ) );
	foreach ( (array) $pages as $page ) {
		if ( preg_match( '/-results?$/', $page->post_name ) ) {
			$charts[] = array( 'label' => get_the_title( $page ), 'url' => str_replace( home_url(), '', get_permalink( $page ) ), 'new_tab' => 0 );
		}
	}
	if ( empty( $charts ) ) {
		$charts[] = array( 'label' => 'Result Chart', 'url' => '/result-chart/', 'new_tab' => 0 );
	}

	$info = array(
		array( 'label' => 'About Us', 'url' => '/about-us/', 'new_tab' => 0 ),
		array( 'label' => 'Privacy Policy', 'url' => '/privacy-policy/', 'new_tab' => 0 ),
		array( 'label' => 'Disclaimer', 'url' => '/disclaimer/', 'new_tab' => 0 ),
		array( 'label' => 'Terms & Conditions', 'url' => '/terms-and-conditions/', 'new_tab' => 0 ),
		array( 'label' => 'Contact', 'url' => '/contact/', 'new_tab' => 0 ),
	);

	return array(
		array( 'heading' => 'Quick Links', 'links' => $quick ),
		array( 'heading' => 'Result Chart', 'links' => $charts ),
		array( 'heading' => 'Information', 'links' => $info ),
	);
}

function s20_default_contact_details() {
	$rows = array();
	if ( s20_site_phone() ) {
		$rows[] = array( 'icon' => 'phone', 'label' => 'Phone', 'value' => s20_site_phone(), 'url' => s20_tel_href( s20_site_phone() ) );
	}
	if ( s20_site_whatsapp() ) {
		$rows[] = array( 'icon' => 'whatsapp', 'label' => 'WhatsApp', 'value' => s20_site_whatsapp(), 'url' => s20_whatsapp_href( s20_site_whatsapp() ) );
	}
	if ( s20_site_telegram() ) {
		$rows[] = array( 'icon' => 'telegram', 'label' => 'Telegram', 'value' => 'Join our channel', 'url' => s20_site_telegram() );
	}
	$email = s20_get_option( 'site_email', get_option( 'admin_email' ) );
	if ( $email ) {
		$rows[] = array( 'icon' => 'mail', 'label' => 'Email', 'value' => $email, 'url' => 'mailto:' . $email );
	}
	return $rows;
}

function s20_default_social_links() {
	$rows = array();
	if ( s20_site_telegram() ) {
		$rows[] = array( 'icon' => 'telegram', 'custom_icon' => '', 'label' => 'Telegram', 'url' => s20_site_telegram() );
	}
	if ( s20_site_whatsapp() ) {
		$rows[] = array( 'icon' => 'whatsapp', 'custom_icon' => '', 'label' => 'WhatsApp', 'url' => s20_whatsapp_href( s20_site_whatsapp() ) );
	}
	return $rows;
}

/**
 * Seed repeater defaults once.
 */
function s20_seed_defaults() {
	if ( ! function_exists( 'update_field' ) || ! function_exists( 'get_field' ) ) {
		return;
	}
	if ( get_option( 's20_defaults_seeded' ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
		return;
	}

	$seed = array(
		'field_s20_home_homepage_section_order' => s20_default_homepage_section_order(),
		'field_s20_home_promo_cards'      => s20_default_promo_cards(),
		'field_s20_payment_payment_methods' => s20_default_payment_methods(),
		'field_s20_faq_faq_items'         => s20_default_faq_items(),
		'field_s20_footer_footer_columns' => s20_default_footer_columns(),
		'field_s20_contact_contact_details' => s20_default_contact_details(),
		'field_s20_social_social_links'   => s20_default_social_links(),
	);

	foreach ( $seed as $field_key => $rows ) {
		$field = function_exists( 'acf_get_field' ) ? acf_get_field( $field_key ) : null;
		if ( ! $field ) {
			continue;
		}
		$existing = get_field( $field['name'], 'option' );
		if ( empty( $existing ) && ! empty( $rows ) ) {
			update_field( $field_key, $rows, 'option' );
		}
	}

	update_option( 's20_defaults_seeded', S20_VERSION );
}
add_action( 'admin_init', 's20_seed_defaults', 20 );
