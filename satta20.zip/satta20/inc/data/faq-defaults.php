<?php
/**
 * Default FAQ items (captured from the live website). Editable in Satta20 > FAQ.
 *
 * @package Satta20
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'question' => "About Satta",
		'answer'   => "<p>Satta is a well-known form of lottery and betting that has captivated players across India for decades. This game is based on choosing numbers and betting on their outcome.</p>",
		'active'   => 1,
	),
	array(
		'question' => "What is Satta King?",
		'answer'   => "<p>Satta King refers to a lottery-based game in which participants choose numbers and place their bets. The winning number is declared at the end of the round.</p>",
		'active'   => 1,
	),
	array(
		'question' => "History of Satta King",
		'answer'   => "<p>The origins of Satta King can be traced back to the early 1960s when it began as a form of betting on cotton rates transmitted from the New York Cotton Exchange.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Who Is Satta King?",
		'answer'   => "<p>The title of Satta King is given to the individual who correctly predicts the winning number in the game.</p>",
		'active'   => 1,
	),
	array(
		'question' => "How You Are Able to Make Gain from Satta King?",
		'answer'   => "<p>◦ Study previous result charts to identify trends.<br>◦ Bet responsibly and avoid staking large amounts.<br>◦ Diversify your bets across different markets.</p>",
		'active'   => 1,
	),
	array(
		'question' => "How to Get Your Satta Result?",
		'answer'   => "<p>Trusted platforms provide real-time updates on Faridabad, Gali and Disawar results.</p>",
		'active'   => 1,
	),
	array(
		'question' => "How to Play Satta King?",
		'answer'   => "<p>1. Select a reliable platform.<br>2. Choose your market.<br>3. Pick a number and place your bet.<br>4. Wait for the result declaration.</p>",
		'active'   => 1,
	),
	array(
		'question' => "How to Play Satta King Online?",
		'answer'   => "<p>◦ Select a trusted online platform.<br>◦ Create an account.<br>◦ Deposit funds securely.<br>◦ Place your bet.<br>◦ Monitor results online.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Things You Should Know About Satta King 2026",
		'answer'   => "<p>Online gaming platforms have made it easier than ever to access results, place bets and track performance.</p>",
		'active'   => 1,
	),
	array(
		'question' => "How to Get Satta King Result?",
		'answer'   => "<p>Visit trusted websites for real-time updates on all major Satta markets.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Is Satta King Legal?",
		'answer'   => "<p>Satta King is generally considered illegal under Indian gambling laws.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Why Satta King is Famous?",
		'answer'   => "<p>Its popularity comes from simple gameplay, excitement and potential rewards.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Is There Any Trick to Win Satta King?",
		'answer'   => "<p>There is no guaranteed trick. Many players analyze historical results and trends.</p>",
		'active'   => 1,
	),
	array(
		'question' => "What is Satta KingWhat is Satta Record Chart?",
		'answer'   => "<p>A Satta record chart displays historical winning numbers from different markets.</p>",
		'active'   => 1,
	),
	array(
		'question' => "What is the Biggest Win of Satta King?",
		'answer'   => "<p>Major wins are often achieved in high-stake markets like Faridabad, Gali and Disawar.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Your Trusted Source for Satta King Results",
		'answer'   => "<p>We provide real-time updates and accurate information for major Satta markets.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Comprehensive Satta Charts",
		'answer'   => "<p>◦ Faridabad Satta Chart<br>◦ Gali Satta Chart<br>◦ Disawar Satta Chart<br>◦ Delhi Bazar Satta Chart<br>◦ Shri Ganesh Satta Chart</p>",
		'active'   => 1,
	),
	array(
		'question' => "Fast and Reliable Results",
		'answer'   => "<p>Instant updates for various Satta King markets and results.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Play Online Satta with Confidence",
		'answer'   => "<p>Choose verified platforms, secure transactions and stay updated with latest results.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Why Choose Us?",
		'answer'   => "<p>◦ Instant result updates.<br>◦ Comprehensive chart data.<br>◦ Reliable market information.<br>◦ Trusted guidance.</p>",
		'active'   => 1,
	),
	array(
		'question' => "Stay Ahead with Daily Updates",
		'answer'   => "<p>Get daily updates, fast notifications and detailed chart insights.</p>",
		'active'   => 1,
	),
);
