<?php
/**
 * ACF PRO options pages: WordPress admin menu "Satta20".
 *
 * @package Satta20
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the Satta20 admin menu and its sub pages.
 */
function s20_register_options_pages() {
	if ( ! function_exists( 'acf_add_options_page' ) ) {
		return;
	}

	acf_add_options_page(
		array(
			'page_title' => __( 'Satta20 Theme Settings', 'satta20' ),
			'menu_title' => __( 'Satta20', 'satta20' ),
			'menu_slug'  => 's20-settings',
			'capability' => 'manage_options',
			'redirect'   => true,
			'icon_url'   => 'dashicons-star-filled',
			'position'   => 59,
		)
	);

	$sub_pages = array(
		's20-general'    => __( 'General Settings', 'satta20' ),
		's20-header'     => __( 'Header Settings', 'satta20' ),
		's20-results'    => __( 'Results Settings', 'satta20' ),
		's20-contact'    => __( 'Contact Settings', 'satta20' ),
		's20-payment'    => __( 'Payment Settings', 'satta20' ),
		's20-faq'        => __( 'FAQ Settings', 'satta20' ),
		's20-footer'     => __( 'Footer Settings', 'satta20' ),
		's20-social'     => __( 'Social Settings', 'satta20' ),
		's20-shortcodes' => __( 'Shortcode Settings', 'satta20' ),
	);

	foreach ( $sub_pages as $slug => $title ) {
		acf_add_options_sub_page(
			array(
				'page_title'  => $title,
				'menu_title'  => str_replace( ' Settings', '', $title ),
				'menu_slug'   => $slug,
				'parent_slug' => 's20-settings',
				'capability'  => 'manage_options',
			)
		);
	}
}
add_action( 'acf/init', 's20_register_options_pages' );

/**
 * Shortcut link to the existing results plugin (no duplicate management screen).
 */
function s20_plugin_shortcut_menu() {
	if ( ! s20_acf_active() ) {
		return;
	}
	$target = trim( (string) s20_get_option( 'plugin_admin_url', 'admin.php?page=srm-results' ) );
	if ( '' === $target ) {
		return;
	}
	add_submenu_page(
		's20-settings',
		__( 'Games & Results (Plugin)', 'satta20' ),
		__( 'Games & Results →', 'satta20' ),
		'manage_options',
		( 0 === strpos( $target, 'http' ) ) ? $target : admin_url( ltrim( $target, '/' ) )
	);
}
add_action( 'admin_menu', 's20_plugin_shortcut_menu', 99 );
