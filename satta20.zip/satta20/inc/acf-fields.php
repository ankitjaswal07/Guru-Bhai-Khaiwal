<?php
/**
 * ACF PRO field groups (registered in PHP, no manual import required).
 *
 * Every default value below mirrors the current live website so the theme renders
 * identically right after activation; all of it is editable from Satta20 > ... .
 *
 * NOTE: Games and results are NOT defined here. They come from the existing plugin
 * through the shortcode fields (Satta20 > Shortcodes and page-level fields).
 *
 * @package Satta20
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * Small builders (keep the definitions readable).
 * ---------------------------------------------------------------------- */

function s20_acf_f( $group, $name, $label, $type = 'text', $args = array() ) {
	return array_merge(
		array(
			'key'   => 'field_s20_' . $group . '_' . $name,
			'name'  => $name,
			'label' => $label,
			'type'  => $type,
		),
		$args
	);
}

function s20_acf_tab( $group, $label ) {
	return array(
		'key'       => 'field_s20_' . $group . '_tab_' . sanitize_key( $label ),
		'label'     => $label,
		'type'      => 'tab',
		'placement' => 'left',
	);
}

function s20_acf_toggle( $group, $name, $label, $default = 1, $instructions = '' ) {
	return s20_acf_f( $group, $name, $label, 'true_false', array( 'ui' => 1, 'default_value' => $default, 'instructions' => $instructions ) );
}

function s20_acf_text( $group, $name, $label, $default = '', $instructions = '' ) {
	return s20_acf_f( $group, $name, $label, 'text', array( 'default_value' => $default, 'instructions' => $instructions ) );
}

function s20_acf_textarea( $group, $name, $label, $default = '', $rows = 3, $instructions = '' ) {
	return s20_acf_f( $group, $name, $label, 'textarea', array( 'default_value' => $default, 'rows' => $rows, 'new_lines' => '', 'instructions' => $instructions ) );
}

function s20_acf_shortcode( $group, $name, $label, $instructions = '' ) {
	$instructions = $instructions ? $instructions : __( 'Enter the shortcode provided by your results plugin, e.g. [your_shortcode]. Leave empty to hide (or to use the global shortcode where applicable).', 'satta20' );
	return s20_acf_f( $group, $name, $label, 'textarea', array( 'rows' => 2, 'new_lines' => '', 'placeholder' => '[your_shortcode]', 'instructions' => $instructions, 'wrapper' => array( 'class' => 's20-shortcode-field' ) ) );
}

function s20_acf_url( $group, $name, $label, $default = '', $instructions = '' ) {
	return s20_acf_f( $group, $name, $label, 'text', array( 'default_value' => $default, 'placeholder' => 'https://', 'instructions' => $instructions ? $instructions : __( 'Full URL, relative path (/page/), tel:, mailto: or # anchor.', 'satta20' ) ) );
}

function s20_acf_image( $group, $name, $label, $instructions = '' ) {
	return s20_acf_f( $group, $name, $label, 'image', array( 'return_format' => 'array', 'preview_size' => 'medium', 'library' => 'all', 'instructions' => $instructions ) );
}

function s20_acf_number( $group, $name, $label, $default = 0, $append = '', $min = 0 ) {
	return s20_acf_f( $group, $name, $label, 'number', array( 'default_value' => $default, 'append' => $append, 'min' => $min ) );
}

function s20_acf_select( $group, $name, $label, $choices, $default = '' ) {
	return s20_acf_f( $group, $name, $label, 'select', array( 'choices' => $choices, 'default_value' => $default, 'ui' => 0, 'return_format' => 'value' ) );
}

function s20_acf_icon_select( $group, $name, $label, $default = 'none' ) {
	return s20_acf_select( $group, $name, $label, s20_icon_choices( true ), $default );
}

function s20_acf_repeater( $group, $name, $label, $sub_fields, $args = array() ) {
	return s20_acf_f(
		$group,
		$name,
		$label,
		'repeater',
		array_merge(
			array(
				'layout'       => 'row',
				'button_label' => __( 'Add item', 'satta20' ),
				'sub_fields'   => $sub_fields,
			),
			$args
		)
	);
}

function s20_acf_message( $group, $name, $message ) {
	return s20_acf_f( $group, $name, '', 'message', array( 'message' => $message, 'new_lines' => 'wpautop', 'esc_html' => 0 ) );
}

function s20_acf_options_location( $slug ) {
	return array( array( array( 'param' => 'options_page', 'operator' => '==', 'value' => $slug ) ) );
}

function s20_homepage_section_order_choices() {
	$choices = array(
		'hero'            => __( 'Hero', 'satta20' ),
		'games'           => __( 'Active Games', 'satta20' ),
		'today_yesterday' => __( 'Today & Yesterday Results', 'satta20' ),
		'promo'           => __( 'Promotional Cards', 'satta20' ),
		'current_month'   => __( 'Current Month Results', 'satta20' ),
		'previous_month'  => __( 'Previous Month Results', 'satta20' ),
		'contact_direct'  => __( 'Contact Direct', 'satta20' ),
		'contact_us'      => __( 'Contact Us', 'satta20' ),
		'blog'            => __( 'Latest Posts', 'satta20' ),
		'faq'             => __( 'FAQ', 'satta20' ),
	);

	$front_page = (int) get_option( 'page_on_front' );
	$sections   = $front_page && function_exists( 'get_field' ) ? get_field( 'page_sections', $front_page ) : array();
	foreach ( (array) $sections as $index => $section ) {
		if ( isset( $section['active'] ) && ! $section['active'] ) {
			continue;
		}
		$number = (int) $index + 1;
		$label  = ! empty( $section['heading'] ) ? wp_strip_all_tags( $section['heading'] ) : sprintf( __( 'Custom Content Section %d', 'satta20' ), $number );
		$choices[ 'page_section_' . $number ] = $label;
	}

	return $choices;
}

function s20_load_homepage_section_order_field( $field ) {
	$field['choices'] = s20_homepage_section_order_choices();
	return $field;
}

/**
 * Sub-fields shared by promotional / contact cards.
 */
function s20_acf_card_fields( $group ) {
	$g = $group;
	return array(
		s20_acf_toggle( $g, 'card_enabled', __( 'Active', 'satta20' ), 1 ),
		s20_acf_text( $g, 'card_heading', __( 'Strip Heading', 'satta20' ) ),
		s20_acf_icon_select( $g, 'card_icon', __( 'Icon (optional)', 'satta20' ), 'none' ),
		s20_acf_textarea( $g, 'card_description', __( 'Description', 'satta20' ), '', 2 ),
		s20_acf_text( $g, 'card_person_name', __( 'Person Name', 'satta20' ) ),
		s20_acf_text( $g, 'card_phone_text', __( 'Phone Display Text', 'satta20' ), '', __( 'Shown text, e.g. ☎ +91XXXXXXXXXX ☎️', 'satta20' ) ),
		s20_acf_text( $g, 'card_phone', __( 'Phone Number (tel link)', 'satta20' ) ),
		s20_acf_text( $g, 'card_whatsapp', __( 'WhatsApp Number or URL', 'satta20' ) ),
		s20_acf_image( $g, 'card_image', __( 'Image (optional)', 'satta20' ) ),
		s20_acf_text( $g, 'card_button_text', __( 'Button Text', 'satta20' ), 'Whatsaap Us' ),
		s20_acf_url( $g, 'card_button_url', __( 'Button URL (empty = WhatsApp number)', 'satta20' ) ),
		s20_acf_text( $g, 'card_secondary_button_text', __( 'Secondary Button Text', 'satta20' ) ),
		s20_acf_url( $g, 'card_secondary_button_url', __( 'Secondary Button URL (empty = tel: phone)', 'satta20' ) ),
		s20_acf_text( $g, 'card_note', __( 'Note below buttons', 'satta20' ) ),
	);
}

/* -------------------------------------------------------------------------
 * Register groups.
 * ---------------------------------------------------------------------- */

function s20_register_acf_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	/* ---------------------------- General ---------------------------- */
	$g = 'general';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_general',
			'title'    => __( 'General Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_tab( $g, 'Branding' ),
				s20_acf_image( $g, 'site_logo', __( 'Site Logo', 'satta20' ), __( 'Used in header and footer unless overridden there.', 'satta20' ) ),
				s20_acf_number( $g, 'site_logo_width', __( 'Header Logo Max Width', 'satta20' ), 290, 'px', 40 ),
				s20_acf_url( $g, 'site_logo_url', __( 'Logo Link URL (empty = homepage)', 'satta20' ) ),
				s20_acf_toggle( $g, 'load_google_fonts', __( 'Load Google Fonts (Poppins, Oswald, Roboto)', 'satta20' ), 1 ),
				s20_acf_tab( $g, 'Contact Numbers' ),
				s20_acf_text( $g, 'site_phone', __( 'Primary Phone', 'satta20' ), '+918307492992' ),
				s20_acf_text( $g, 'site_whatsapp', __( 'Primary WhatsApp (number or wa.me URL)', 'satta20' ), '+918307492992' ),
				s20_acf_url( $g, 'site_telegram', __( 'Telegram URL', 'satta20' ), '' ),
				s20_acf_text( $g, 'site_email', __( 'Contact Email', 'satta20' ), '' ),
				s20_acf_text( $g, 'site_button_text', __( 'Default WhatsApp Button Text', 'satta20' ), 'Whatsaap Us' ),
				s20_acf_tab( $g, 'Inner Page Notice' ),
				s20_acf_toggle( $g, 'page_notice_enabled', __( 'Show notice box at the bottom of inner pages', 'satta20' ), 1 ),
				s20_acf_text( $g, 'page_notice_heading', __( 'Notice Heading', 'satta20' ), '⚠ IMPORTANT INFORMATION' ),
				s20_acf_textarea( $g, 'page_notice_text', __( 'Notice Text', 'satta20' ), 'Satta20 provides information for informational purposes only. We do not promote or encourage illegal activities.' ),
				s20_acf_tab( $g, 'Plugin' ),
				s20_acf_text( $g, 'plugin_admin_url', __( 'Results Plugin Admin URL', 'satta20' ), 'admin.php?page=srm-results', __( 'Shortcut shown in the Satta20 menu. Games & results are managed only by your existing plugin.', 'satta20' ) ),
			),
			'location' => s20_acf_options_location( 's20-general' ),
		)
	);

	/* ----------------------------- Header ---------------------------- */
	$g = 'header';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_header',
			'title'    => __( 'Header Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_tab( $g, 'Announcement Bar' ),
				s20_acf_toggle( $g, 'header_announcement_enabled', __( 'Show announcement bar', 'satta20' ), 1 ),
				s20_acf_text( $g, 'header_announcement', __( 'Announcement Text', 'satta20' ), '⚠️ This site is for informational purposes only. We do not promote or encourage any illegal activities.' ),
				s20_acf_url( $g, 'header_announcement_url', __( 'Announcement Link (optional)', 'satta20' ) ),
				s20_acf_toggle( $g, 'header_telegram_enabled', __( 'Show Telegram link', 'satta20' ), 1 ),
				s20_acf_text( $g, 'header_telegram_text', __( 'Telegram Text', 'satta20' ), 'Join Telegram' ),
				s20_acf_url( $g, 'header_telegram_url', __( 'Telegram URL (empty = General > Telegram)', 'satta20' ) ),
				s20_acf_toggle( $g, 'header_whatsapp_enabled', __( 'Show WhatsApp link', 'satta20' ), 1 ),
				s20_acf_text( $g, 'header_whatsapp_text', __( 'WhatsApp Text', 'satta20' ), 'WhatsApp' ),
				s20_acf_text( $g, 'header_whatsapp_url', __( 'WhatsApp number/URL (empty = General > WhatsApp)', 'satta20' ) ),
				s20_acf_toggle( $g, 'header_login_enabled', __( 'Show Login link', 'satta20' ), 1 ),
				s20_acf_text( $g, 'header_login_text', __( 'Login Text', 'satta20' ), 'Login' ),
				s20_acf_url( $g, 'header_login_url', __( 'Login URL (empty = results plugin admin page / wp-login)', 'satta20' ) ),
				s20_acf_tab( $g, 'Logo & Navigation' ),
				s20_acf_image( $g, 'header_logo', __( 'Header Logo (overrides General logo)', 'satta20' ) ),
				s20_acf_message( $g, 'nav_msg', __( 'The main navigation is a standard WordPress menu: Appearance > Menus > assign to "Primary Menu (Header)".', 'satta20' ) ),
				s20_acf_toggle( $g, 'header_sticky', __( 'Sticky header on scroll', 'satta20' ), 0 ),
				s20_acf_tab( $g, 'Date Badge' ),
				s20_acf_toggle( $g, 'header_date_enabled', __( 'Show date badge (right side)', 'satta20' ), 1 ),
				s20_acf_text( $g, 'header_date_format', __( 'Date Format (PHP)', 'satta20' ), 'd M Y' ),
				s20_acf_icon_select( $g, 'header_date_icon', __( 'Badge Icon', 'satta20' ), 'calendar' ),
				s20_acf_text( $g, 'header_date_text', __( 'Custom badge text (optional, replaces date)', 'satta20' ) ),
				s20_acf_url( $g, 'header_date_url', __( 'Badge Link (optional)', 'satta20' ) ),
				s20_acf_tab( $g, 'Marquee' ),
				s20_acf_toggle( $g, 'header_marquee_enabled', __( 'Show marquee bar under header', 'satta20' ), 1 ),
				s20_acf_text( $g, 'header_marquee_text', __( 'Marquee Text', 'satta20' ), "India's No 1 Super Fast Result Site (SATTA20.COM)" ),
				s20_acf_toggle( $g, 'header_marquee_scroll', __( 'Scroll the text', 'satta20' ), 1 ),
				s20_acf_number( $g, 'header_marquee_speed', __( 'Scroll duration', 'satta20' ), 18, 'sec', 4 ),
			),
			'location' => s20_acf_options_location( 's20-header' ),
		)
	);

	/* ---------------------------- Homepage --------------------------- */
	$g = 'home';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_homepage',
			'title'    => __( 'Homepage Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_repeater(
					$g,
					'homepage_section_order',
					__( 'Homepage Section Order', 'satta20' ),
					array(
						s20_acf_select(
							'homeorder',
							'section',
							__( 'Section', 'satta20' ),
							array(
								'hero'            => __( 'Hero', 'satta20' ),
								'games'           => __( 'Active Games', 'satta20' ),
								'today_yesterday' => __( 'Today & Yesterday Results', 'satta20' ),
								'promo'           => __( 'Promotional Cards', 'satta20' ),
								'current_month'   => __( 'Current Month Results', 'satta20' ),
								'previous_month'  => __( 'Previous Month Results', 'satta20' ),
								'contact_direct'  => __( 'Contact Direct', 'satta20' ),
								'contact_us'      => __( 'Contact Us', 'satta20' ),
								'blog'            => __( 'Latest Posts', 'satta20' ),
								'faq'             => __( 'FAQ', 'satta20' ),
								'page_section_1' => __( 'Custom Content Section 1', 'satta20' ),
								'page_section_2' => __( 'Custom Content Section 2', 'satta20' ),
								'page_section_3' => __( 'Custom Content Section 3', 'satta20' ),
								'page_section_4' => __( 'Custom Content Section 4', 'satta20' ),
								'page_section_5' => __( 'Custom Content Section 5', 'satta20' ),
								'page_section_6' => __( 'Custom Content Section 6', 'satta20' ),
								'page_section_7' => __( 'Custom Content Section 7', 'satta20' ),
								'page_section_8' => __( 'Custom Content Section 8', 'satta20' ),
								'page_section_9' => __( 'Custom Content Section 9', 'satta20' ),
								'page_section_10' => __( 'Custom Content Section 10', 'satta20' ),
							),
						),
					),
					array(
						'button_label' => __( 'Add section', 'satta20' ),
						'collapsed'    => 'field_s20_homeorder_section',
					)
				),
				s20_acf_tab( $g, 'Hero' ),
				s20_acf_toggle( $g, 'hero_enabled', __( 'Show Hero', 'satta20' ), 1 ),
				s20_acf_text( $g, 'hero_heading', __( 'Strip Heading', 'satta20' ), 'Jonny bhai khiwal' ),
				s20_acf_image( $g, 'hero_strip_image', __( 'Strip Background Image (optional, e.g. strip-bg.png)', 'satta20' ) ),
				s20_acf_textarea( $g, 'hero_description', __( 'Description (optional)', 'satta20' ), '', 2 ),
				s20_acf_image( $g, 'hero_image', __( 'Hero Image (optional)', 'satta20' ) ),
				s20_acf_toggle( $g, 'hero_show_clock', __( 'Show live date & time box', 'satta20' ), 1 ),
				s20_acf_toggle( $g, 'hero_pill_enabled', __( 'Show announcement pill', 'satta20' ), 1 ),
				s20_acf_icon_select( $g, 'hero_pill_icon', __( 'Pill Icon', 'satta20' ), 'megaphone' ),
				s20_acf_image( $g, 'hero_pill_icon_image', __( 'Pill Icon Image (optional, overrides icon)', 'satta20' ) ),
				s20_acf_text( $g, 'hero_pill_text', __( 'Pill Text', 'satta20' ), 'हा भाई यही आती हे सबसे पहले खबर रूको और देखो' ),
				s20_acf_url( $g, 'hero_pill_url', __( 'Pill Link (optional)', 'satta20' ) ),
				s20_acf_text( $g, 'hero_button_text', __( 'Button Text (optional)', 'satta20' ) ),
				s20_acf_url( $g, 'hero_button_url', __( 'Button URL', 'satta20' ) ),
				s20_acf_text( $g, 'hero_secondary_button_text', __( 'Secondary Button Text (optional)', 'satta20' ) ),
				s20_acf_url( $g, 'hero_secondary_button_url', __( 'Secondary Button URL', 'satta20' ) ),
				s20_acf_toggle( $g, 'hero_live_status_enabled', __( 'Show Current / Next Game panel (plugin shortcode)', 'satta20' ), 1 ),
				s20_acf_shortcode( $g, 'hero_live_status_shortcode', __( 'Current / Next Game Shortcode (empty = Shortcodes > Live Status)', 'satta20' ) ),

				s20_acf_tab( $g, 'Active Games' ),
				s20_acf_toggle( $g, 'games_enabled', __( 'Show Active Games section', 'satta20' ), 1 ),
				s20_acf_text( $g, 'games_heading', __( 'Heading', 'satta20' ), '👉सीधे सट्टा कंपनी का No 1 खाईवाल👈' ),
				s20_acf_text( $g, 'games_subheading', __( 'Sub Heading', 'satta20' ), '♕♕ Jonny bhai khiwal  ♕♕' ),
				s20_acf_text( $g, 'games_timing_heading', __( 'Timing Heading', 'satta20' ), 'NEW TIMING FOR GAME👇🏻👇🏻' ),
				s20_acf_textarea( $g, 'games_description', __( 'Description (optional)', 'satta20' ), '', 2 ),
				s20_acf_shortcode( $g, 'home_games_shortcode', __( 'Games Shortcode (empty = Shortcodes > Games)', 'satta20' ) ),
				s20_acf_toggle( $g, 'games_show_payment', __( 'Show Payment block inside this section (content: Satta20 > Payment)', 'satta20' ), 1 ),

				s20_acf_tab( $g, 'Today & Yesterday' ),
				s20_acf_toggle( $g, 'today_yesterday_enabled', __( 'Show Today & Yesterday Results', 'satta20' ), 1 ),
				s20_acf_text( $g, 'today_yesterday_heading', __( 'Heading', 'satta20' ), 'Today & Yesterday Results' ),
				s20_acf_textarea( $g, 'today_yesterday_description', __( 'Description (optional)', 'satta20' ), '', 2 ),
				s20_acf_shortcode( $g, 'home_today_yesterday_shortcode', __( 'Combined Today/Yesterday Shortcode (empty = Shortcodes > Combined)', 'satta20' ) ),
				s20_acf_shortcode( $g, 'today_shortcode', __( "Today's Results Shortcode (optional, used when no combined shortcode)", 'satta20' ) ),
				s20_acf_shortcode( $g, 'yesterday_shortcode', __( "Yesterday's Results Shortcode (optional)", 'satta20' ) ),

				s20_acf_tab( $g, 'Promotional Cards' ),
				s20_acf_toggle( $g, 'promo_enabled', __( 'Show promotional cards (after Today & Yesterday)', 'satta20' ), 1 ),
				s20_acf_repeater( $g, 'promo_cards', __( 'Promotional Cards', 'satta20' ), s20_acf_card_fields( 'promo' ), array( 'button_label' => __( 'Add card', 'satta20' ), 'collapsed' => 'field_s20_promo_card_heading' ) ),

				s20_acf_tab( $g, 'Current Month' ),
				s20_acf_toggle( $g, 'current_month_enabled', __( 'Show Current Month Results', 'satta20' ), 1 ),
				s20_acf_text( $g, 'current_month_heading', __( 'Heading', 'satta20' ), 'Current Month Results' ),
				s20_acf_textarea( $g, 'current_month_description', __( 'Description (optional)', 'satta20' ), '', 2 ),
				s20_acf_shortcode( $g, 'current_month_shortcode', __( 'Current Month Shortcode (empty = Shortcodes setting)', 'satta20' ) ),

				s20_acf_tab( $g, 'Previous Month' ),
				s20_acf_toggle( $g, 'previous_month_enabled', __( 'Show Previous Month Results', 'satta20' ), 1 ),
				s20_acf_text( $g, 'previous_month_heading', __( 'Heading', 'satta20' ), 'Previous Month Results' ),
				s20_acf_textarea( $g, 'previous_month_description', __( 'Description (optional)', 'satta20' ), '', 2 ),
				s20_acf_shortcode( $g, 'previous_month_shortcode', __( 'Previous Month Shortcode (empty = Shortcodes setting)', 'satta20' ) ),

				s20_acf_tab( $g, 'Contact Direct' ),
				s20_acf_toggle( $g, 'contact_direct_enabled', __( 'Show "Contact Direct" card', 'satta20' ), 1 ),
				s20_acf_text( $g, 'contact_direct_heading', __( 'Strip Heading', 'satta20' ), '👑 CONTACT DIRECT WITH MD💣' ),
				s20_acf_textarea( $g, 'contact_direct_description', __( 'Description', 'satta20' ), 'COMPANY के किसी भी खाईवाल द्वारा Misbehave,पेमेंट टाईम पर ना करने की शिकायत करने के लिए👍', 2 ),
				s20_acf_text( $g, 'contact_direct_name', __( 'Person Name', 'satta20' ), 'Vishu Bhai' ),
				s20_acf_text( $g, 'contact_direct_phone_text', __( 'Phone Display Text', 'satta20' ), '☎+917986030340☎️' ),
				s20_acf_text( $g, 'contact_direct_phone', __( 'Phone Number', 'satta20' ), '+917986030340' ),
				s20_acf_text( $g, 'contact_direct_whatsapp', __( 'WhatsApp Number/URL', 'satta20' ), '+917986030340' ),
				s20_acf_image( $g, 'contact_direct_image', __( 'Image (optional)', 'satta20' ) ),
				s20_acf_text( $g, 'contact_direct_button_text', __( 'Button Text', 'satta20' ), 'Whatsaap Us' ),
				s20_acf_url( $g, 'contact_direct_button_url', __( 'Button URL (empty = WhatsApp)', 'satta20' ) ),
				s20_acf_text( $g, 'contact_direct_note', __( 'Note', 'satta20' ), '✅ 1000% तुरंत समाधान 👍' ),

				s20_acf_tab( $g, 'Contact Us' ),
				s20_acf_toggle( $g, 'contact_us_enabled', __( 'Show "Contact Us" card', 'satta20' ), 1 ),
				s20_acf_text( $g, 'contact_us_heading', __( 'Strip Heading', 'satta20' ), 'Contact Us' ),
				s20_acf_textarea( $g, 'contact_us_description', __( 'Description', 'satta20' ), 'For any query', 2 ),
				s20_acf_text( $g, 'contact_us_name', __( 'Person Name', 'satta20' ), 'Vishu Bhai' ),
				s20_acf_text( $g, 'contact_us_phone_text', __( 'Phone Display Text', 'satta20' ), '☎ +918307492992  ☎️' ),
				s20_acf_text( $g, 'contact_us_phone', __( 'Phone Number', 'satta20' ), '+918307492992' ),
				s20_acf_text( $g, 'contact_us_whatsapp', __( 'WhatsApp Number/URL', 'satta20' ), '+918307492992' ),
				s20_acf_image( $g, 'contact_us_image', __( 'Image (optional)', 'satta20' ) ),
				s20_acf_text( $g, 'contact_us_whatsapp_button_text', __( 'WhatsApp Button Text', 'satta20' ), 'Whatsaap Us' ),
				s20_acf_text( $g, 'contact_us_call_button_text', __( 'Call Button Text', 'satta20' ), 'Call Us' ),
				s20_acf_text( $g, 'contact_us_note', __( 'Note', 'satta20' ), '✅ 1000% तुरंत समाधान 👍' ),

				s20_acf_tab( $g, 'Blog' ),
				s20_acf_toggle( $g, 'blog_enabled', __( 'Show Latest Posts section', 'satta20' ), 1 ),
				s20_acf_text( $g, 'blog_heading', __( 'Heading', 'satta20' ), 'Latest Satta King Updates' ),
				s20_acf_textarea( $g, 'blog_description', __( 'Description', 'satta20' ), 'Stay updated with the latest Satta King news, result guides, charts, market information, and helpful insights.', 2 ),
				s20_acf_number( $g, 'blog_posts_count', __( 'Number of posts', 'satta20' ), 6, '', 1 ),
				s20_acf_select( $g, 'blog_layout', __( 'Layout', 'satta20' ), array( 'carousel' => __( 'Carousel (like live site)', 'satta20' ), 'grid' => __( 'Grid', 'satta20' ) ), 'carousel' ),
				s20_acf_select( $g, 'blog_columns', __( 'Cards per row (desktop)', 'satta20' ), array( '2' => '2', '3' => '3', '4' => '4' ), '4' ),
				s20_acf_f( $g, 'blog_category', __( 'Only from category (optional)', 'satta20' ), 'taxonomy', array( 'taxonomy' => 'category', 'field_type' => 'select', 'allow_null' => 1, 'return_format' => 'id', 'add_term' => 0 ) ),
				s20_acf_toggle( $g, 'blog_show_image', __( 'Show featured image', 'satta20' ), 1 ),
				s20_acf_toggle( $g, 'blog_show_date', __( 'Show date', 'satta20' ), 0 ),
				s20_acf_toggle( $g, 'blog_show_excerpt', __( 'Show excerpt', 'satta20' ), 1 ),
				s20_acf_toggle( $g, 'blog_show_category', __( 'Show category', 'satta20' ), 0 ),
				s20_acf_text( $g, 'blog_button_text', __( '"View all" button text (optional)', 'satta20' ) ),
				s20_acf_url( $g, 'blog_button_url', __( 'Button URL (empty = blog page)', 'satta20' ) ),

				s20_acf_tab( $g, 'FAQ' ),
				s20_acf_toggle( $g, 'faq_enabled', __( 'Show FAQ section', 'satta20' ), 1 ),
				s20_acf_text( $g, 'faq_home_heading', __( 'Heading', 'satta20' ), 'Frequently Asked Questions' ),
				s20_acf_textarea( $g, 'faq_home_description', __( 'Description', 'satta20' ), 'Find answers to common questions about Satta King results, charts, markets, and updates.', 2 ),
				s20_acf_number( $g, 'faq_home_limit', __( 'Max items on homepage (0 = all)', 'satta20' ), 0 ),
				s20_acf_message( $g, 'faq_msg', __( 'FAQ items are managed in Satta20 > FAQ.', 'satta20' ) ),
			),
			'location' => array(
				array(
					array( 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ),
					array( 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ),
				),
			),
		)
	);

	/* ---------------------------- Results ---------------------------- */
	$g = 'results';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_results',
			'title'    => __( 'Results Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_message( $g, 'intro', __( 'Default headings for result page templates. Each page can override its heading and shortcode in the page editor.', 'satta20' ) ),
				s20_acf_text( $g, 'results_heading_result_chart', __( 'Result Chart page heading', 'satta20' ), 'Result Chart' ),
				s20_acf_text( $g, 'results_heading_today', __( 'Today page heading', 'satta20' ), "Today's Results" ),
				s20_acf_text( $g, 'results_heading_yesterday', __( 'Yesterday page heading', 'satta20' ), "Yesterday's Results" ),
				s20_acf_text( $g, 'results_heading_current_month', __( 'Monthly page - current month heading', 'satta20' ), 'Current Month Results' ),
				s20_acf_text( $g, 'results_heading_previous_month', __( 'Monthly page - previous month heading', 'satta20' ), 'Previous Month Results' ),
				s20_acf_textarea( $g, 'results_intro', __( 'Intro text shown under result page headings (optional)', 'satta20' ), '', 2 ),
				s20_acf_number( $g, 'results_container_width', __( 'Results container max width', 'satta20' ), 1500, 'px', 320 ),
				s20_acf_toggle( $g, 'results_scroll_hint', __( 'Show "swipe to see more" hint above wide tables on mobile', 'satta20' ), 1 ),
				s20_acf_text( $g, 'results_scroll_hint_text', __( 'Hint text', 'satta20' ), '← Swipe to see all columns →' ),
			),
			'location' => s20_acf_options_location( 's20-results' ),
		)
	);

	/* ---------------------------- Contact ---------------------------- */
	$g = 'contact';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_contact',
			'title'    => __( 'Contact Page Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_tab( $g, 'Get in touch' ),
				s20_acf_text( $g, 'contact_page_heading', __( 'Heading', 'satta20' ), 'GET IN TOUCH' ),
				s20_acf_textarea( $g, 'contact_page_intro', __( 'Intro', 'satta20' ), 'Have questions about the website or its information?', 2 ),
				s20_acf_repeater(
					$g,
					'contact_details',
					__( 'Contact Details', 'satta20' ),
					array(
						s20_acf_icon_select( 'contactd', 'icon', __( 'Icon', 'satta20' ), 'phone' ),
						s20_acf_text( 'contactd', 'label', __( 'Label', 'satta20' ) ),
						s20_acf_text( 'contactd', 'value', __( 'Value', 'satta20' ) ),
						s20_acf_url( 'contactd', 'url', __( 'Link (optional)', 'satta20' ) ),
					),
					array( 'layout' => 'table' )
				),
				s20_acf_toggle( $g, 'contact_show_whatsapp_button', __( 'Show WhatsApp button', 'satta20' ), 1 ),
				s20_acf_tab( $g, 'Form' ),
				s20_acf_text( $g, 'contact_form_heading', __( 'Form Heading', 'satta20' ), 'SEND US A MESSAGE' ),
				s20_acf_textarea( $g, 'contact_form_intro', __( 'Form Intro', 'satta20' ), 'Contact our team using the information below.', 2 ),
				s20_acf_shortcode( $g, 'contact_form_shortcode', __( 'Form plugin shortcode (optional, e.g. Contact Form 7 / WPForms)', 'satta20' ), __( 'If empty, the built-in Name / Email / Message form is used.', 'satta20' ) ),
				s20_acf_text( $g, 'contact_form_recipient', __( 'Built-in form recipient email (empty = admin email)', 'satta20' ) ),
				s20_acf_text( $g, 'contact_form_button_text', __( 'Submit Button Text', 'satta20' ), 'Send' ),
				s20_acf_text( $g, 'contact_form_success', __( 'Success Message', 'satta20' ), 'Thank you! Your message has been sent.' ),
				s20_acf_text( $g, 'contact_form_error', __( 'Error Message', 'satta20' ), 'Sorry, something went wrong. Please try again.' ),
			),
			'location' => s20_acf_options_location( 's20-contact' ),
		)
	);

	/* ---------------------------- Payment ---------------------------- */
	$g = 'payment';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_payment',
			'title'    => __( 'Payment Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_toggle( $g, 'payment_enabled', __( 'Show Payment block', 'satta20' ), 1 ),
				s20_acf_text( $g, 'payment_heading', __( 'Heading', 'satta20' ), 'Payment Option' ),
				s20_acf_toggle( $g, 'payment_show_icons', __( 'Show payment method icons row', 'satta20' ), 0, __( 'The live site currently keeps this row hidden.', 'satta20' ) ),
				s20_acf_repeater(
					$g,
					'payment_methods',
					__( 'Payment Methods', 'satta20' ),
					array(
						s20_acf_image( 'paym', 'image', __( 'Icon / Image', 'satta20' ) ),
						s20_acf_text( 'paym', 'name', __( 'Name', 'satta20' ) ),
						s20_acf_text( 'paym', 'description', __( 'Description (optional)', 'satta20' ) ),
						s20_acf_toggle( 'paym', 'active', __( 'Active', 'satta20' ), 1 ),
					),
					array( 'layout' => 'table' )
				),
				s20_acf_text( $g, 'payment_text', __( 'Payment Text', 'satta20' ), 'PAYTM//BANK TRANSFER//PHONE PAY//GOOGle PAY 👉 +918307492992 📲' ),
				s20_acf_text( $g, 'payment_phone', __( 'Payment Phone / UPI number', 'satta20' ), '+918307492992' ),
				s20_acf_text( $g, 'payment_tagline', __( 'Tagline', 'satta20' ), '👉बिंदास होकर प्ले करो यहां धोखा नहीं पेमेंट मिलती है टाईम पर' ),
				s20_acf_text( $g, 'payment_closing_heading', __( 'Closing Heading', 'satta20' ), '♕♕👑 Jonny bhai khiwal  👑♕♕' ),
				s20_acf_image( $g, 'payment_image', __( 'QR / Payment Image (optional)', 'satta20' ) ),
				s20_acf_text( $g, 'payment_button_text', __( 'Button Text', 'satta20' ), 'Whatsaap Us' ),
				s20_acf_url( $g, 'payment_button_url', __( 'Button URL (empty = WhatsApp of payment phone)', 'satta20' ) ),
			),
			'location' => s20_acf_options_location( 's20-payment' ),
		)
	);

	/* ------------------------------ FAQ ------------------------------ */
	$g = 'faq';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_faq',
			'title'    => __( 'FAQ Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_text( $g, 'faq_heading', __( 'FAQ Page Heading', 'satta20' ), 'Frequently Asked Questions' ),
				s20_acf_textarea( $g, 'faq_description', __( 'FAQ Page Description', 'satta20' ), 'Find answers to common questions about Satta King results, charts, markets, and updates.', 2 ),
				s20_acf_toggle( $g, 'faq_first_open', __( 'Open first item by default', 'satta20' ), 1 ),
				s20_acf_toggle( $g, 'faq_single_open', __( 'Only one item open at a time', 'satta20' ), 0 ),
				s20_acf_repeater(
					$g,
					'faq_items',
					__( 'FAQ Items', 'satta20' ),
					array(
						s20_acf_text( 'faqi', 'question', __( 'Question', 'satta20' ) ),
						s20_acf_f( 'faqi', 'answer', __( 'Answer', 'satta20' ), 'wysiwyg', array( 'tabs' => 'all', 'toolbar' => 'basic', 'media_upload' => 0, 'delay' => 1 ) ),
						s20_acf_toggle( 'faqi', 'active', __( 'Active', 'satta20' ), 1 ),
					),
					array( 'button_label' => __( 'Add question', 'satta20' ), 'collapsed' => 'field_s20_faqi_question' )
				),
			),
			'location' => s20_acf_options_location( 's20-faq' ),
		)
	);

	/* ----------------------------- Footer ---------------------------- */
	$g = 'footer';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_footer',
			'title'    => __( 'Footer Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_tab( $g, 'Brand' ),
				s20_acf_image( $g, 'footer_logo', __( 'Footer Logo (empty = site logo)', 'satta20' ) ),
				s20_acf_text( $g, 'footer_tagline', __( 'Tagline', 'satta20' ), "India's No.1 Satta Result Site" ),
				s20_acf_textarea( $g, 'footer_description', __( 'Description', 'satta20' ), "Satta20 is India's No.1 super fast result site. Get the latest results, charts and updates instantly and accurately.", 3 ),
				s20_acf_image( $g, 'footer_background', __( 'Footer Background Image (optional)', 'satta20' ) ),
				s20_acf_tab( $g, 'Link Columns' ),
				s20_acf_repeater(
					$g,
					'footer_columns',
					__( 'Footer Columns', 'satta20' ),
					array(
						s20_acf_text( 'footc', 'heading', __( 'Column Heading', 'satta20' ) ),
						s20_acf_repeater(
							'footc',
							'links',
							__( 'Links', 'satta20' ),
							array(
								s20_acf_text( 'footl', 'label', __( 'Label', 'satta20' ) ),
								s20_acf_url( 'footl', 'url', __( 'URL', 'satta20' ) ),
								s20_acf_toggle( 'footl', 'new_tab', __( 'New tab', 'satta20' ), 0 ),
							),
							array( 'layout' => 'table', 'button_label' => __( 'Add link', 'satta20' ) )
						),
					),
					array( 'button_label' => __( 'Add column', 'satta20' ), 'collapsed' => 'field_s20_footc_heading', 'max' => 4 )
				),
				s20_acf_toggle( $g, 'footer_show_social', __( 'Show social icons (Satta20 > Social)', 'satta20' ), 1 ),
				s20_acf_tab( $g, 'Disclaimer' ),
				s20_acf_toggle( $g, 'footer_disclaimer_enabled', __( 'Show disclaimer bar', 'satta20' ), 1 ),
				s20_acf_icon_select( $g, 'footer_disclaimer_icon', __( 'Disclaimer Icon', 'satta20' ), 'warning' ),
				s20_acf_text( $g, 'footer_disclaimer_title', __( 'Disclaimer Title', 'satta20' ), 'INFORMATIONAL DISCLAIMER' ),
				s20_acf_textarea( $g, 'footer_disclaimer_text', __( 'Disclaimer Text', 'satta20' ), 'This website is for informational purposes only. We do not promote or encourage illegal gambling or betting activities. Users must be 18+ years to visit this website.', 3 ),
				s20_acf_text( $g, 'footer_age_badge', __( 'Age Badge', 'satta20' ), '18+' ),
				s20_acf_text( $g, 'footer_age_text', __( 'Age Badge Text', 'satta20' ), 'PLAY RESPONSIBLY' ),
				s20_acf_tab( $g, 'Copyright' ),
				s20_acf_text( $g, 'copyright_text', __( 'Copyright Text ({year} = current year)', 'satta20' ), '© {year} Satta20.com | All Rights Reserved.' ),
				s20_acf_textarea( $g, 'footer_extra_text', __( 'Additional text (optional)', 'satta20' ), '', 2 ),
			),
			'location' => s20_acf_options_location( 's20-footer' ),
		)
	);

	/* ----------------------------- Social ---------------------------- */
	$g = 'social';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_social',
			'title'    => __( 'Social Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_repeater(
					$g,
					'social_links',
					__( 'Social Links', 'satta20' ),
					array(
						s20_acf_icon_select( 'soc', 'icon', __( 'Icon', 'satta20' ), 'telegram' ),
						s20_acf_image( 'soc', 'custom_icon', __( 'Custom icon image (optional)', 'satta20' ) ),
						s20_acf_text( 'soc', 'label', __( 'Label', 'satta20' ) ),
						s20_acf_url( 'soc', 'url', __( 'URL', 'satta20' ) ),
					),
					array( 'layout' => 'table', 'button_label' => __( 'Add social link', 'satta20' ) )
				),
				s20_acf_toggle( $g, 'social_show_header', __( 'Also show social icons in the announcement bar', 'satta20' ), 0 ),
			),
			'location' => s20_acf_options_location( 's20-social' ),
		)
	);

	/* --------------------------- Shortcodes -------------------------- */
	$g = 'sc';
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_shortcodes',
			'title'    => __( 'Shortcode Settings (results plugin integration)', 'satta20' ),
			'fields'   => array(
				s20_acf_message( $g, 'intro', __( 'Enter the shortcodes provided by your existing results plugin. The theme only displays their output inside the design - it never stores games or results itself. Individual pages can override these in the page editor.', 'satta20' ) ),
				s20_acf_tab( $g, 'Games' ),
				s20_acf_shortcode( $g, 'games_shortcode', __( 'Game Listing Shortcode', 'satta20' ) ),
				s20_acf_shortcode( $g, 'live_status_shortcode', __( 'Current / Next Game (Live Status) Shortcode', 'satta20' ) ),
				s20_acf_tab( $g, 'Today' ),
				s20_acf_shortcode( $g, 'today_results_shortcode', __( "Today's Results Shortcode", 'satta20' ) ),
				s20_acf_tab( $g, 'Yesterday' ),
				s20_acf_shortcode( $g, 'yesterday_results_shortcode', __( "Yesterday's Results Shortcode", 'satta20' ) ),
				s20_acf_shortcode( $g, 'today_yesterday_shortcode', __( 'Combined Today & Yesterday Shortcode (optional)', 'satta20' ) ),
				s20_acf_tab( $g, 'Current Month' ),
				s20_acf_shortcode( $g, 'current_month_results_shortcode', __( 'Current Month Results Shortcode', 'satta20' ) ),
				s20_acf_tab( $g, 'Previous Month' ),
				s20_acf_shortcode( $g, 'previous_month_results_shortcode', __( 'Previous Month Results Shortcode', 'satta20' ) ),
				s20_acf_tab( $g, 'Result Chart' ),
				s20_acf_shortcode( $g, 'result_chart_shortcode', __( 'Result Chart Shortcode', 'satta20' ) ),
				s20_acf_tab( $g, 'Other' ),
				s20_acf_shortcode( $g, 'additional_shortcode_1', __( 'Additional Shortcode 1', 'satta20' ) ),
				s20_acf_shortcode( $g, 'additional_shortcode_2', __( 'Additional Shortcode 2', 'satta20' ) ),
				s20_acf_shortcode( $g, 'additional_shortcode_3', __( 'Additional Shortcode 3', 'satta20' ) ),
				s20_acf_tab( $g, 'Fallback' ),
				s20_acf_select( $g, 'shortcode_empty_behavior', __( 'When a shortcode field is empty', 'satta20' ), array( 'hide' => __( 'Hide the section', 'satta20' ), 'message' => __( 'Show a fallback message', 'satta20' ) ), 'hide' ),
				s20_acf_text( $g, 'shortcode_empty_message', __( 'Fallback message', 'satta20' ), 'Results will be available soon.' ),
			),
			'location' => s20_acf_options_location( 's20-shortcodes' ),
		)
	);

	/* ------------------- Page-specific shortcode fields --------------- */
	$g = 'page';
	$result_templates = array(
		'page-templates/template-result-chart.php',
		'page-templates/template-today-results.php',
		'page-templates/template-yesterday-results.php',
		'page-templates/template-monthly-results.php',
		'page-templates/template-game-results.php',
	);
	$location = array();
	foreach ( $result_templates as $template ) {
		$location[] = array( array( 'param' => 'page_template', 'operator' => '==', 'value' => $template ) );
	}
	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_page_results',
			'title'    => __( 'Results Page Settings (this page)', 'satta20' ),
			'fields'   => array(
				s20_acf_text( $g, 'page_heading', __( 'Heading override (empty = default heading / page title)', 'satta20' ) ),
				s20_acf_textarea( $g, 'page_intro', __( 'Intro text (optional)', 'satta20' ), '', 2 ),
				s20_acf_shortcode( $g, 'result_chart_shortcode', __( 'Result Chart Shortcode (Result Chart / Game templates)', 'satta20' ) ),
				s20_acf_shortcode( $g, 'today_results_shortcode', __( "Today's Results Shortcode (Today template)", 'satta20' ) ),
				s20_acf_shortcode( $g, 'yesterday_results_shortcode', __( "Yesterday's Results Shortcode (Yesterday template)", 'satta20' ) ),
				s20_acf_shortcode( $g, 'current_month_results_shortcode', __( 'Current Month Shortcode (Monthly template)', 'satta20' ) ),
				s20_acf_shortcode( $g, 'previous_month_results_shortcode', __( 'Previous Month Shortcode (Monthly template)', 'satta20' ) ),
				s20_acf_shortcode( $g, 'page_extra_shortcode', __( 'Additional shortcode (rendered after the main output)', 'satta20' ) ),
			),
			'location' => $location,
			'position' => 'acf_after_title',
		)
	);

	acf_add_local_field_group(
		array(
			'key'      => 'group_s20_page_generic',
			'title'    => __( 'Page Display Settings', 'satta20' ),
			'fields'   => array(
				s20_acf_toggle( $g, 'page_show_title', __( 'Show page title', 'satta20' ), 1 ),
				s20_acf_toggle( $g, 'page_hide_notice', __( 'Hide the bottom notice box on this page', 'satta20' ), 0 ),
				s20_acf_shortcode( $g, 'page_content_shortcode', __( 'Shortcode rendered after the page content (optional)', 'satta20' ) ),
				s20_acf_f(
					$g,
					'page_sections',
					__( 'Page Sections', 'satta20' ),
					'flexible_content',
					array(
						'button_label' => __( 'Add section', 'satta20' ),
						'layouts'      => array(
							'full_content' => array(
								'key'        => 'layout_s20_page_full_content',
								'name'       => 'full_content',
								'label'      => __( 'Full content section', 'satta20' ),
								'display'    => 'block',
								'sub_fields' => array(
									s20_acf_toggle( 'pagefull', 'active', __( 'Active', 'satta20' ), 1 ),
									s20_acf_text( 'pagefull', 'heading', __( 'Heading', 'satta20' ) ),
									s20_acf_f( 'pagefull', 'content', __( 'Content', 'satta20' ), 'wysiwyg', array( 'tabs' => 'all', 'toolbar' => 'full', 'media_upload' => 1 ) ),
								),
							),
							'image_left' => array(
								'key'        => 'layout_s20_page_image_left',
								'name'       => 'image_left',
								'label'      => __( 'Image left, content right', 'satta20' ),
								'display'    => 'block',
								'sub_fields' => array(
									s20_acf_toggle( 'pageimageleft', 'active', __( 'Active', 'satta20' ), 1 ),
									s20_acf_image( 'pageimageleft', 'image', __( 'Image', 'satta20' ) ),
									s20_acf_text( 'pageimageleft', 'heading', __( 'Heading', 'satta20' ) ),
									s20_acf_f( 'pageimageleft', 'content', __( 'Content', 'satta20' ), 'wysiwyg', array( 'tabs' => 'all', 'toolbar' => 'full', 'media_upload' => 1 ) ),
								),
							),
							'content_left' => array(
								'key'        => 'layout_s20_page_content_left',
								'name'       => 'content_left',
								'label'      => __( 'Content left, image right', 'satta20' ),
								'display'    => 'block',
								'sub_fields' => array(
									s20_acf_toggle( 'pagecontentleft', 'active', __( 'Active', 'satta20' ), 1 ),
									s20_acf_text( 'pagecontentleft', 'heading', __( 'Heading', 'satta20' ) ),
									s20_acf_f( 'pagecontentleft', 'content', __( 'Content', 'satta20' ), 'wysiwyg', array( 'tabs' => 'all', 'toolbar' => 'full', 'media_upload' => 1 ) ),
									s20_acf_image( 'pagecontentleft', 'image', __( 'Image', 'satta20' ) ),
								),
							),
						),
					)
				),
			),
			'location' => array(
				array(
					array( 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ),
				),
			),
			'position' => 'acf_after_title',
		)
	);
}
add_action( 'acf/init', 's20_register_acf_fields' );
add_filter( 'acf/load_field/key=field_s20_homeorder_section', 's20_load_homepage_section_order_field' );
