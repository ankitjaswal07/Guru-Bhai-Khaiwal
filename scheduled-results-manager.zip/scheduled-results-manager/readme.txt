=== Scheduled Results Manager ===
Contributors: scheduled-results-manager
Tags: schedule, results, games, countdown, live
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage scheduled games, daily game results, monthly archives, and live countdown displays.

== Description ==

Scheduled Results Manager lets administrators manage recurring scheduled games and daily results, then display them with focused or table-based shortcodes in Gutenberg, Elementor, the Classic Editor, or shortcode-enabled widgets.

Key features:

* Manage games with primary and secondary language names.
* Configure a daily scheduled time for every game.
* Enter and publish daily game results from a fast admin table.
* Determine the current game and next game using the WordPress site timezone.
* Display current game name and current game time independently.
* Display the latest timed game with its time, result status, and result value.
* Display today and yesterday results separately or together.
* Display complete current, selected, and previous month game-result tables.
* Display individual game history with month and year filtering.
* Import and export results with CSV using date,game,result,status columns.
* Update focused status displays through the read-only REST API without page reloads.
* Provide responsive tables and configurable frontend styles.

== Shortcodes ==

Focused game shortcodes:

* `[srm_current_game]` — Current game card with time and result status.
* `[srm_current_game_name]` — Current game name only.
* `[srm_current_game_name show_secondary="no" label="no"]` — Name-only options.
* `[srm_current_game_time]` — Current game scheduled time only.
* `[srm_current_game_time label="no"]` — Time without a label.
* `[srm_latest_game_result]` — Latest game selected by time, including game name, time, result status, and result or Wait for Result.
* `[srm_latest_game_result show_secondary="no" show_result="yes"]` — Latest-result options.
* `[srm_current_result]` — Current game result card.
* `[srm_next_game]` — Next game with countdown.
* `[srm_live_status]` — Combined current and next game status.

Daily result shortcodes:

* `[srm_today_results]` — Today's game results.
* `[srm_yesterday_results]` — Yesterday's game results.
* `[srm_today_yesterday_results]` — Yesterday and today tables together with game names.
* `[srm_today_yesterday_results show_time="yes" show_secondary="yes"]` — Combined-table options.

Monthly result shortcodes:

* `[srm_full_month_results]` — Full current-month table with every active game and date.
* `[srm_monthly_results]` — Full current-month table.
* `[srm_monthly_results month="08" year="2026"]` — Selected archived month.
* `[srm_monthly_results game_id="3" month="08" year="2026"]` — Selected game and month; visitors can change the filters.
* Add `show_filter="no"` to hide the visitor filter controls.
* `[srm_previous_month_results]` — Full previous-calendar-month table.
* `[srm_previous_month_table]` — Alias for the previous-month table.

Game history shortcode:

* `[srm_game_history game_id="1"]`
* `[srm_game_history game_id="1" month="08" year="2026" limit="31"]`

== CSV Format ==

Use:

`date,game,result,status`

Example:

`2026-08-01,IPL / आई पी एल,98,published`

Legacy CSV files using an `event` column remain accepted for compatibility.

== Database ==

The plugin uses custom database tables for performance. Legacy internal table and column identifiers are preserved during upgrades so existing installations do not lose data.

== Installation ==

1. Upload the plugin ZIP through WordPress > Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Open Scheduled Results > Games to manage game names and timings.
4. Open Scheduled Results > Daily Results to enter results.
5. Add the required shortcodes to pages, posts, Elementor shortcode widgets, or Gutenberg shortcode blocks.

== Timezone ==

All current-game, next-game, date, and countdown calculations use the timezone configured under WordPress > Settings > General.

== Changelog ==

= 1.1.0 =
* Added current game name-only shortcode.
* Added current game time-only shortcode.
* Added latest timed game result/status shortcode.
* Added combined yesterday/today results shortcode.
* Added full-month and previous-month aliases.
* Changed all visitor and administrator terminology from event to game.
* Corrected chronological current/next game selection for after-midnight schedules.

= 1.0.0 =
* Initial release.
