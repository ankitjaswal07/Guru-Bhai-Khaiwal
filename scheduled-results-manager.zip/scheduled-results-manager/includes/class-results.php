<?php
/**
 * Results Management Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Results
 */
class SRM_Results {

    /**
     * Get results for a specific date.
     *
     * @param string $date Y-m-d format.
     * @return array<object>
     */
    public static function get_results_for_date( string $date ): array {
        global $wpdb;
        $results_table = SRM_Database::results_table();
        $events_table  = SRM_Database::events_table();

        $query = "SELECT e.id AS event_id, e.event_name, e.event_name_secondary, e.scheduled_time,
                        r.id AS result_id, r.result_value, r.result_status, r.result_date
                 FROM {$events_table} e
                 LEFT JOIN {$results_table} r ON r.event_id = e.id AND r.result_date = %s
                 WHERE e.status = 1";

        if ( SRM_Access::should_enforce_user_game_restrictions() ) {
            $allowed = SRM_Access::get_user_allowed_game_ids();
            if ( empty( $allowed ) ) {
                return array();
            }
            $placeholders = implode( ',', array_fill( 0, count( $allowed ), '%d' ) );
            $query      .= " AND e.id IN ({$placeholders})";
            $query       = $wpdb->prepare( $query, array_merge( array( $date ), $allowed ) );
        } else {
            $query = $wpdb->prepare( $query, $date );
        }

        $query .= " ORDER BY e.display_order ASC, e.scheduled_time ASC";

        return $wpdb->get_results( $query ) ?: array();
    }

    /**
     * Get today's results.
     *
     * @return array<object>
     */
    public static function get_today_results(): array {
        return self::get_results_for_date( self::get_site_date() );
    }

    /**
     * Get yesterday's results.
     *
     * @return array<object>
     */
    public static function get_yesterday_results(): array {
        $tz        = wp_timezone();
        $yesterday = new DateTime( 'yesterday', $tz );
        return self::get_results_for_date( $yesterday->format( 'Y-m-d' ) );
    }

    /**
     * Get results for a full month.
     *
     * @param int $year
     * @param int $month
     * @return array<object> Indexed by result_date then event_id.
     */
    public static function get_monthly_results( int $year, int $month ): array {
        global $wpdb;
        $results_table = SRM_Database::results_table();

        $start = sprintf( '%04d-%02d-01', $year, $month );
        $end   = date( 'Y-m-t', strtotime( $start ) );

        // Check transient cache
        $cache_key = "srm_monthly_{$year}_{$month}";
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT event_id, result_date, result_value, result_status
                 FROM {$results_table}
                 WHERE result_date BETWEEN %s AND %s",
                $start,
                $end
            )
        ) ?: array();

        // Index by date → event_id
        $indexed = array();
        foreach ( $rows as $row ) {
            $indexed[ $row->result_date ][ $row->event_id ] = $row;
        }

        set_transient( $cache_key, $indexed, 5 * MINUTE_IN_SECONDS );
        return $indexed;
    }

    /**
     * Get a single result record.
     *
     * @param int    $event_id
     * @param string $date Y-m-d
     * @return object|null
     */
    public static function get_result( int $event_id, string $date ): ?object {
        global $wpdb;
        $table = SRM_Database::results_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE event_id = %d AND result_date = %s",
                $event_id,
                $date
            )
        );
    }

    /**
     * Save (insert or update) a result.
     *
     * @param int                 $event_id
     * @param string              $date       Y-m-d
     * @param array<string,mixed> $data
     * @return bool|WP_Error
     */
    public static function save_result( int $event_id, string $date, array $data ): bool|WP_Error {
        global $wpdb;

        // Validate event exists
        $event = SRM_Games::get_game( $event_id );
        if ( ! $event ) {
            return new WP_Error( 'invalid_event', __( 'Invalid game.', 'scheduled-results-manager' ) );
        }

        // Sanitize result value
        $result_value = isset( $data['result_value'] ) ? self::sanitize_result_value( $data['result_value'] ) : null;
        $result_status = in_array( $data['result_status'] ?? 'pending', array( 'pending', 'published' ), true )
            ? $data['result_status']
            : 'pending';

        $table = SRM_Database::results_table();
        $now   = current_time( 'mysql' );

        // Check for existing
        $existing = self::get_result( $event_id, $date );

        if ( $existing ) {
            // Update
            $updated = $wpdb->update(
                $table,
                array(
                    'result_value'  => $result_value,
                    'result_status' => $result_status,
                    'updated_at'    => $now,
                ),
                array( 'event_id' => $event_id, 'result_date' => $date ),
                array( '%s', '%s', '%s' ),
                array( '%d', '%s' )
            );
            if ( false === $updated ) {
                return new WP_Error( 'db_error', __( 'Failed to update result.', 'scheduled-results-manager' ) );
            }
        } else {
            // Insert
            $inserted = $wpdb->insert(
                $table,
                array(
                    'event_id'      => $event_id,
                    'result_date'   => $date,
                    'result_value'  => $result_value,
                    'result_status' => $result_status,
                    'created_at'    => $now,
                    'updated_at'    => $now,
                ),
                array( '%d', '%s', '%s', '%s', '%s', '%s' )
            );
            if ( false === $inserted ) {
                return new WP_Error( 'db_error', __( 'Failed to save result.', 'scheduled-results-manager' ) );
            }
        }

        // Invalidate monthly cache
        $year  = (int) date( 'Y', strtotime( $date ) );
        $month = (int) date( 'n', strtotime( $date ) );
        delete_transient( "srm_monthly_{$year}_{$month}" );

        return true;
    }

    /**
     * Delete a result.
     *
     * @param int    $event_id
     * @param string $date Y-m-d
     * @return bool
     */
    public static function delete_result( int $event_id, string $date ): bool {
        global $wpdb;

        $result = $wpdb->delete(
            SRM_Database::results_table(),
            array( 'event_id' => $event_id, 'result_date' => $date ),
            array( '%d', '%s' )
        );

        if ( $result ) {
            $year  = (int) date( 'Y', strtotime( $date ) );
            $month = (int) date( 'n', strtotime( $date ) );
            delete_transient( "srm_monthly_{$year}_{$month}" );
        }

        return (bool) $result;
    }

    /**
     * Get statistics.
     *
     * @return array<string,int>
     */
    public static function get_stats(): array {
        global $wpdb;

        $events_table  = SRM_Database::events_table();
        $results_table = SRM_Database::results_table();
        $today         = self::get_site_date();

        $total_events   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$events_table}" );
        $active_events  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$events_table} WHERE status = 1" );
        $today_results  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$results_table} WHERE result_date = %s", $today ) );
        $pending        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$results_table} WHERE result_date = %s AND result_status = 'pending'", $today ) );
        $published      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$results_table} WHERE result_date = %s AND result_status = 'published'", $today ) );

        return compact( 'total_events', 'active_events', 'today_results', 'pending', 'published' );
    }

    /**
     * AJAX: Save a single result.
     */
    public static function ajax_save_result(): void {
        check_ajax_referer( 'srm_admin_nonce', 'nonce' );

        if ( ! SRM_Access::current_user_can_access_plugin() ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'scheduled-results-manager' ) ) );
        }

        $event_id = absint( $_POST['event_id'] ?? 0 );
        $date     = sanitize_text_field( $_POST['result_date'] ?? '' );

        if ( ! $event_id || ! $date ) {
            wp_send_json_error( array( 'message' => __( 'Missing required fields.', 'scheduled-results-manager' ) ) );
        }

        // Validate date
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid date format.', 'scheduled-results-manager' ) ) );
        }

        $data = array(
            'result_value'  => sanitize_text_field( $_POST['result_value'] ?? '' ),
            'result_status' => sanitize_key( $_POST['result_status'] ?? 'pending' ),
        );

        $result = self::save_result( $event_id, $date, $data );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'message' => __( 'Result saved successfully.', 'scheduled-results-manager' ) ) );
    }

    /**
     * AJAX: Delete a result.
     */
    public static function ajax_delete_result(): void {
        check_ajax_referer( 'srm_admin_nonce', 'nonce' );

        if ( ! SRM_Access::current_user_can_access_plugin() ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'scheduled-results-manager' ) ) );
        }

        $event_id = absint( $_POST['event_id'] ?? 0 );
        $date     = sanitize_text_field( $_POST['result_date'] ?? '' );

        if ( ! $event_id || ! $date ) {
            wp_send_json_error( array( 'message' => __( 'Missing required fields.', 'scheduled-results-manager' ) ) );
        }

        if ( ! get_option( 'srm_allow_deletion', '1' ) ) {
            wp_send_json_error( array( 'message' => __( 'Deletion is disabled.', 'scheduled-results-manager' ) ) );
        }

        $result = self::delete_result( $event_id, $date );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => __( 'Failed to delete result.', 'scheduled-results-manager' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Result deleted.', 'scheduled-results-manager' ) ) );
    }

    /**
     * Sanitize a result value per plugin settings.
     *
     * @param string $value
     * @return string
     */
    public static function sanitize_result_value( string $value ): string {
        $value = trim( sanitize_text_field( $value ) );

        // Limit length
        $value = mb_substr( $value, 0, 50 );

        // Strip tags
        $value = wp_strip_all_tags( $value );

        return $value;
    }

    /**
     * Get current site date in Y-m-d.
     *
     * @return string
     */
    public static function get_site_date(): string {
        return wp_date( 'Y-m-d' );
    }
}
