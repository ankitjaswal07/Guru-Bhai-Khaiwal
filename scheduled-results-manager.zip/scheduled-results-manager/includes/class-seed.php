<?php
/**
 * Default Data Seeder — Games and Results
 *
 * Call from activation or manually to seed the plugin with default games
 * and historical results.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SRM_Seed_Data {

    /**
     * Insert all default games.
     */
    public static function seed_games(): void {
        global $wpdb;
        $table = SRM_Database::events_table();

        $games = array(
            array(
                'event_name' => 'IPL / आई पी एल',
                'event_name_secondary' => 'आई पी एल',
                'slug' => 'ipl',
                'scheduled_time' => '13:10:00',
                'display_order' => 1,
                'status' => 1,
            ),
            array(
                'event_name' => 'RDL BAZAR / RDL बाजार',
                'event_name_secondary' => 'RDL बाजार',
                'slug' => 'rdl-bazar',
                'scheduled_time' => '14:10:00',
                'display_order' => 2,
                'status' => 1,
            ),
            array(
                'event_name' => 'Delhi Bazar / दिल्ली बाज़ार',
                'event_name_secondary' => 'दिल्ली बाज़ार',
                'slug' => 'delhi-bazar',
                'scheduled_time' => '14:55:00',
                'display_order' => 3,
                'status' => 1,
            ),
            array(
                'event_name' => 'Shri Ganesh / श्री गणेश',
                'event_name_secondary' => 'श्री गणेश',
                'slug' => 'shri-ganesh',
                'scheduled_time' => '16:20:00',
                'display_order' => 4,
                'status' => 1,
            ),
            array(
                'event_name' => 'Faridabad / फरीदाबाद',
                'event_name_secondary' => 'फरीदाबाद',
                'slug' => 'faridabad',
                'scheduled_time' => '17:50:00',
                'display_order' => 5,
                'status' => 1,
            ),
            array(
                'event_name' => 'Hukum / हुक्म',
                'event_name_secondary' => 'हुक्म',
                'slug' => 'hukum',
                'scheduled_time' => '18:55:00',
                'display_order' => 6,
                'status' => 1,
            ),
            array(
                'event_name' => 'HR MATKA / HR मटका',
                'event_name_secondary' => 'HR मटका',
                'slug' => 'hr-matka',
                'scheduled_time' => '20:15:00',
                'display_order' => 7,
                'status' => 1,
            ),
            array(
                'event_name' => 'Gaziabad / गाजियाबाद',
                'event_name_secondary' => 'गाजियाबाद',
                'slug' => 'gaziabad',
                'scheduled_time' => '20:30:00',
                'display_order' => 8,
                'status' => 1,
            ),
            array(
                'event_name' => 'Gali / गली',
                'event_name_secondary' => 'गली',
                'slug' => 'gali',
                'scheduled_time' => '23:20:00',
                'display_order' => 9,
                'status' => 1,
            ),
            array(
                'event_name' => 'Dishavar / दिशावर',
                'event_name_secondary' => 'दिशावर',
                'slug' => 'dishavar',
                'scheduled_time' => '02:00:00',
                'display_order' => 10,
                'status' => 1,
            ),
        );

        $now = current_time( 'mysql' );
        foreach ( $games as $game ) {
            $existing_id = $wpdb->get_var(
                $wpdb->prepare( "SELECT id FROM {$table} WHERE slug = %s LIMIT 1", $game['slug'] )
            );
            if ( $existing_id ) {
                continue;
            }

            $wpdb->insert(
                $table,
                array_merge(
                    $game,
                    array(
                        'created_at' => $now,
                        'updated_at' => $now,
                    )
                ),
                array( '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
            );
        }
    }

    /**
     * Insert August 2026 results.
     */
    public static function seed_august_results(): void {
        $results = array(
            array('date'=>'2026-08-01', 'results'=>array('IPL'=>'98','RDL'=>'34','Delhi'=>'71','Shri'=>'26','Farid'=>'57','Hukum'=>'61','HR'=>'53','Gazi'=>'23','Gali'=>'92','Dish'=>null)),
            array('date'=>'2026-08-02', 'results'=>array('IPL'=>'28','RDL'=>'47','Delhi'=>'09','Shri'=>'58','Farid'=>'06','Hukum'=>'61','HR'=>'92','Gazi'=>'15','Gali'=>'31','Dish'=>'31')),
            array('date'=>'2026-08-03', 'results'=>array('IPL'=>'77','RDL'=>'85','Delhi'=>'53','Shri'=>'31','Farid'=>'95','Hukum'=>'87','HR'=>'25','Gazi'=>'60','Gali'=>'59','Dish'=>'74')),
            array('date'=>'2026-08-04', 'results'=>array('IPL'=>'37','RDL'=>'89','Delhi'=>'12','Shri'=>'10','Farid'=>'12','Hukum'=>'48','HR'=>'98','Gazi'=>'24','Gali'=>'27','Dish'=>'31')),
            array('date'=>'2026-08-05', 'results'=>array('IPL'=>'45','RDL'=>'92','Delhi'=>'47','Shri'=>'75','Farid'=>'57','Hukum'=>'71','HR'=>'18','Gazi'=>'22','Gali'=>'85','Dish'=>'93')),
            array('date'=>'2026-08-06', 'results'=>array('IPL'=>'84','RDL'=>'50','Delhi'=>'61','Shri'=>'97','Farid'=>'22','Hukum'=>'65','HR'=>'84','Gazi'=>'89','Gali'=>'80','Dish'=>'51')),
            array('date'=>'2026-08-07', 'results'=>array('IPL'=>'84','RDL'=>'24','Delhi'=>'52','Shri'=>'80','Farid'=>'26','Hukum'=>'49','HR'=>'61','Gazi'=>'60','Gali'=>'35','Dish'=>'83')),
            array('date'=>'2026-08-08', 'results'=>array('IPL'=>'46','RDL'=>'42','Delhi'=>'91','Shri'=>'93','Farid'=>'81','Hukum'=>'28','HR'=>'06','Gazi'=>'99','Gali'=>'93','Dish'=>'96')),
            array('date'=>'2026-08-09', 'results'=>array('IPL'=>'92','RDL'=>'76','Delhi'=>'89','Shri'=>'74','Farid'=>'63','Hukum'=>'49','HR'=>'73','Gazi'=>'53','Gali'=>'97','Dish'=>'16')),
            array('date'=>'2026-08-10', 'results'=>array('IPL'=>'55','RDL'=>'45','Delhi'=>'85','Shri'=>'64','Farid'=>'58','Hukum'=>'09','HR'=>'95','Gazi'=>'69','Gali'=>'57','Dish'=>'64')),
            array('date'=>'2026-08-11', 'results'=>array('IPL'=>'59','RDL'=>'27','Delhi'=>'78','Shri'=>'30','Farid'=>'58','Hukum'=>'97','HR'=>'26','Gazi'=>'31','Gali'=>'92','Dish'=>'88')),
            array('date'=>'2026-08-12', 'results'=>array('IPL'=>'33','RDL'=>'74','Delhi'=>'94','Shri'=>'41','Farid'=>'75','Hukum'=>'28','HR'=>'98','Gazi'=>'63','Gali'=>'36','Dish'=>'19')),
            array('date'=>'2026-08-13', 'results'=>array('IPL'=>'46','RDL'=>'77','Delhi'=>'40','Shri'=>'34','Farid'=>'54','Hukum'=>'14','HR'=>'51','Gazi'=>'79','Gali'=>'61','Dish'=>'79')),
            array('date'=>'2026-08-14', 'results'=>array('IPL'=>'70','RDL'=>'90','Delhi'=>'69','Shri'=>'02','Farid'=>'49','Hukum'=>'19','HR'=>'95','Gazi'=>'38','Gali'=>'71','Dish'=>'12')),
            array('date'=>'2026-08-15', 'results'=>array('IPL'=>'92','RDL'=>'80','Delhi'=>'10','Shri'=>'23','Farid'=>'58','Hukum'=>'33','HR'=>'63','Gazi'=>'40','Gali'=>'71','Dish'=>'49')),
            array('date'=>'2026-08-16', 'results'=>array('IPL'=>'50','RDL'=>'87','Delhi'=>'34','Shri'=>'53','Farid'=>'90','Hukum'=>'68','HR'=>'23','Gazi'=>'99','Gali'=>'59','Dish'=>'57')),
            array('date'=>'2026-08-17', 'results'=>array('IPL'=>'22','RDL'=>'05','Delhi'=>'01','Shri'=>'12','Farid'=>'46','Hukum'=>'93','HR'=>'81','Gazi'=>'20','Gali'=>'15','Dish'=>'40')),
            array('date'=>'2026-08-18', 'results'=>array('IPL'=>'33','RDL'=>'50','Delhi'=>'01','Shri'=>'87','Farid'=>'22','Hukum'=>'63','HR'=>'10','Gazi'=>'32','Gali'=>null,'Dish'=>'29')),
        );

        self::store_results( $results );
    }

    /**
     * Insert July 2026 results.
     */
    public static function seed_july_results(): void {
        $results = array(
            array('date'=>'2026-07-01', 'results'=>array('IPL'=>'65','RDL'=>'18','Delhi'=>'13','Shri'=>'92','Farid'=>'97','Hukum'=>'36','HR'=>'92','Gazi'=>'69','Gali'=>'78','Dish'=>null)),
            array('date'=>'2026-07-02', 'results'=>array('IPL'=>'35','RDL'=>'47','Delhi'=>'12','Shri'=>'27','Farid'=>'69','Hukum'=>'71','HR'=>'04','Gazi'=>'11','Gali'=>'33','Dish'=>'24')),
            array('date'=>'2026-07-03', 'results'=>array('IPL'=>'89','RDL'=>'72','Delhi'=>'96','Shri'=>'42','Farid'=>'73','Hukum'=>'67','HR'=>'36','Gazi'=>'31','Gali'=>'49','Dish'=>'39')),
            array('date'=>'2026-07-04', 'results'=>array('IPL'=>'74','RDL'=>'37','Delhi'=>'57','Shri'=>'27','Farid'=>'34','Hukum'=>'25','HR'=>'25','Gazi'=>'72','Gali'=>'39','Dish'=>'91')),
            array('date'=>'2026-07-05', 'results'=>array('IPL'=>'59','RDL'=>'61','Delhi'=>'32','Shri'=>'87','Farid'=>'92','Hukum'=>'70','HR'=>'54','Gazi'=>'91','Gali'=>'36','Dish'=>'23')),
            array('date'=>'2026-07-06', 'results'=>array('IPL'=>'37','RDL'=>'94','Delhi'=>'57','Shri'=>'54','Farid'=>'19','Hukum'=>'59','HR'=>'59','Gazi'=>'54','Gali'=>'50','Dish'=>'06')),
            array('date'=>'2026-07-07', 'results'=>array('IPL'=>'80','RDL'=>'10','Delhi'=>'26','Shri'=>'45','Farid'=>'04','Hukum'=>'36','HR'=>'85','Gazi'=>'48','Gali'=>'41','Dish'=>'19')),
            array('date'=>'2026-07-08', 'results'=>array('IPL'=>'57','RDL'=>'10','Delhi'=>'83','Shri'=>'22','Farid'=>'41','Hukum'=>'01','HR'=>'22','Gazi'=>'71','Gali'=>'21','Dish'=>'53')),
            array('date'=>'2026-07-09', 'results'=>array('IPL'=>'87','RDL'=>'48','Delhi'=>'12','Shri'=>'94','Farid'=>'88','Hukum'=>'27','HR'=>'27','Gazi'=>'29','Gali'=>'75','Dish'=>'02')),
            array('date'=>'2026-07-10', 'results'=>array('IPL'=>'69','RDL'=>'51','Delhi'=>'12','Shri'=>'30','Farid'=>'74','Hukum'=>'48','HR'=>'81','Gazi'=>'42','Gali'=>'35','Dish'=>'26')),
            array('date'=>'2026-07-11', 'results'=>array('IPL'=>'21','RDL'=>'38','Delhi'=>'14','Shri'=>'96','Farid'=>'32','Hukum'=>'72','HR'=>'28','Gazi'=>'04','Gali'=>'04','Dish'=>'53')),
            array('date'=>'2026-07-12', 'results'=>array('IPL'=>'84','RDL'=>'62','Delhi'=>'18','Shri'=>'29','Farid'=>'91','Hukum'=>'20','HR'=>'10','Gazi'=>'15','Gali'=>'77','Dish'=>'26')),
            array('date'=>'2026-07-13', 'results'=>array('IPL'=>'44','RDL'=>'58','Delhi'=>'38','Shri'=>'96','Farid'=>'05','Hukum'=>'10','HR'=>'18','Gazi'=>'87','Gali'=>'45','Dish'=>'66')),
            array('date'=>'2026-07-14', 'results'=>array('IPL'=>'66','RDL'=>'26','Delhi'=>'92','Shri'=>'88','Farid'=>'93','Hukum'=>'48','HR'=>'21','Gazi'=>'75','Gali'=>'52','Dish'=>'73')),
            array('date'=>'2026-07-15', 'results'=>array('IPL'=>'32','RDL'=>'90','Delhi'=>'00','Shri'=>'77','Farid'=>'60','Hukum'=>'35','HR'=>'88','Gazi'=>'77','Gali'=>'08','Dish'=>'16')),
            array('date'=>'2026-07-16', 'results'=>array('IPL'=>'31','RDL'=>'61','Delhi'=>'37','Shri'=>'62','Farid'=>'15','Hukum'=>'72','HR'=>'83','Gazi'=>'05','Gali'=>'90','Dish'=>'28')),
            array('date'=>'2026-07-17', 'results'=>array('IPL'=>'34','RDL'=>'30','Delhi'=>'18','Shri'=>'75','Farid'=>'30','Hukum'=>'89','HR'=>'03','Gazi'=>'30','Gali'=>'14','Dish'=>'32')),
            array('date'=>'2026-07-18', 'results'=>array('IPL'=>'72','RDL'=>'38','Delhi'=>'47','Shri'=>'26','Farid'=>'07','Hukum'=>'64','HR'=>'46','Gazi'=>'51','Gali'=>'80','Dish'=>'85')),
            array('date'=>'2026-07-19', 'results'=>array('IPL'=>'10','RDL'=>'77','Delhi'=>'85','Shri'=>'22','Farid'=>'83','Hukum'=>'20','HR'=>'98','Gazi'=>'45','Gali'=>'57','Dish'=>'16')),
            array('date'=>'2026-07-20', 'results'=>array('IPL'=>'35','RDL'=>'53','Delhi'=>'49','Shri'=>'57','Farid'=>'47','Hukum'=>'29','HR'=>'26','Gazi'=>'32','Gali'=>'54','Dish'=>'83')),
            array('date'=>'2026-07-21', 'results'=>array('IPL'=>'88','RDL'=>'83','Delhi'=>'95','Shri'=>'44','Farid'=>'06','Hukum'=>'70','HR'=>'59','Gazi'=>'82','Gali'=>'11','Dish'=>'73')),
            array('date'=>'2026-07-22', 'results'=>array('IPL'=>'28','RDL'=>'97','Delhi'=>'83','Shri'=>'28','Farid'=>'34','Hukum'=>'91','HR'=>'43','Gazi'=>'09','Gali'=>'40','Dish'=>'05')),
            array('date'=>'2026-07-23', 'results'=>array('IPL'=>'45','RDL'=>'50','Delhi'=>'86','Shri'=>'75','Farid'=>'39','Hukum'=>'26','HR'=>'21','Gazi'=>'54','Gali'=>'43','Dish'=>'20')),
            array('date'=>'2026-07-24', 'results'=>array('IPL'=>'84','RDL'=>'14','Delhi'=>'56','Shri'=>'74','Farid'=>'76','Hukum'=>'97','HR'=>'59','Gazi'=>'73','Gali'=>'72','Dish'=>'69')),
            array('date'=>'2026-07-25', 'results'=>array('IPL'=>'32','RDL'=>'17','Delhi'=>'09','Shri'=>'92','Farid'=>'32','Hukum'=>'33','HR'=>'42','Gazi'=>'70','Gali'=>'58','Dish'=>'89')),
            array('date'=>'2026-07-26', 'results'=>array('IPL'=>'68','RDL'=>'15','Delhi'=>'61','Shri'=>'09','Farid'=>'22','Hukum'=>'69','HR'=>'84','Gazi'=>'84','Gali'=>'39','Dish'=>'65')),
            array('date'=>'2026-07-27', 'results'=>array('IPL'=>'97','RDL'=>'49','Delhi'=>'80','Shri'=>'93','Farid'=>'74','Hukum'=>'85','HR'=>'43','Gazi'=>'07','Gali'=>'72','Dish'=>'06')),
            array('date'=>'2026-07-28', 'results'=>array('IPL'=>'88','RDL'=>'20','Delhi'=>'61','Shri'=>'81','Farid'=>'27','Hukum'=>'52','HR'=>'51','Gazi'=>'67','Gali'=>'02','Dish'=>'75')),
            array('date'=>'2026-07-29', 'results'=>array('IPL'=>'11','RDL'=>'93','Delhi'=>'54','Shri'=>'04','Farid'=>'60','Hukum'=>'41','HR'=>'06','Gazi'=>'09','Gali'=>'16','Dish'=>'16')),
            array('date'=>'2026-07-30', 'results'=>array('IPL'=>'96','RDL'=>'12','Delhi'=>'81','Shri'=>'86','Farid'=>'40','Hukum'=>'94','HR'=>'88','Gazi'=>'52','Gali'=>'86','Dish'=>'67')),
            array('date'=>'2026-07-31', 'results'=>array('IPL'=>null,'RDL'=>null,'Delhi'=>null,'Shri'=>null,'Farid'=>null,'Hukum'=>null,'HR'=>null,'Gazi'=>null,'Gali'=>null,'Dish'=>'05')),
        );

        self::store_results( $results );
    }

    /**
     * Store a month of default results using stable game slugs.
     * Null values represent intentionally blank cells. Existing rows are never
     * overwritten or deleted by default-data upgrades.
     *
     * @param array<int,array<string,mixed>> $rows Seed rows.
     */
    private static function store_results( array $rows ): void {
        global $wpdb;

        $results_table = SRM_Database::results_table();
        $game_ids      = self::get_game_ids();
        $now           = current_time( 'mysql' );

        foreach ( $rows as $row ) {
            $date = (string) ( $row['date'] ?? '' );
            if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || empty( $row['results'] ) || ! is_array( $row['results'] ) ) {
                continue;
            }

            foreach ( $row['results'] as $game_key => $value ) {
                $game_id = $game_ids[ $game_key ] ?? 0;
                if ( ! $game_id ) {
                    continue;
                }

                if ( null === $value ) {
                    continue;
                }

                $existing_id = $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id FROM {$results_table} WHERE event_id = %d AND result_date = %s LIMIT 1",
                        $game_id,
                        $date
                    )
                );
                $value = sanitize_text_field( (string) $value );

                if ( $existing_id ) {
                    continue;
                }

                $wpdb->insert(
                    $results_table,
                    array(
                        'event_id'      => $game_id,
                        'result_date'   => $date,
                        'result_value'  => $value,
                        'result_status' => 'published',
                        'created_at'    => $now,
                        'updated_at'    => $now,
                    ),
                    array( '%d', '%s', '%s', '%s', '%s', '%s' )
                );
            }
        }
    }

    /**
     * Resolve seed keys to actual game IDs without assuming auto-increment IDs.
     *
     * @return array<string,int>
     */
    private static function get_game_ids(): array {
        global $wpdb;

        $table = SRM_Database::events_table();
        $slugs = array(
            'IPL'    => 'ipl',
            'RDL'    => 'rdl-bazar',
            'Delhi'  => 'delhi-bazar',
            'Shri'   => 'shri-ganesh',
            'Farid'  => 'faridabad',
            'Hukum'  => 'hukum',
            'HR'     => 'hr-matka',
            'Gazi'   => 'gaziabad',
            'Gali'   => 'gali',
            'Dish'   => 'dishavar',
        );
        $ids = array();

        foreach ( $slugs as $key => $slug ) {
            $id = $wpdb->get_var(
                $wpdb->prepare( "SELECT id FROM {$table} WHERE slug = %s LIMIT 1", $slug )
            );
            if ( $id ) {
                $ids[ $key ] = (int) $id;
            }
        }

        return $ids;
    }

    /**
     * Main seeding entry point.
     */
    public static function seed_all(): void {
        self::seed_games();
        self::seed_august_results();
        self::seed_july_results();
    }
}
