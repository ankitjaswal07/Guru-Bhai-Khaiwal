<?php
/**
 * Import / Export Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Import_Export
 */
class SRM_Import_Export {

    /**
     * Process CSV import.
     *
     * Expected columns: date, game, result, status.
     * The legacy event column is also accepted.
     *
     * @param string $file_path Absolute path to uploaded CSV file.
     * @return array<string,mixed> Results summary.
     */
    public static function import_csv( string $file_path ): array {
        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            return array(
                'success' => false,
                'message' => __( 'File not found or not readable.', 'scheduled-results-manager' ),
            );
        }

        $handle = fopen( $file_path, 'r' );
        if ( ! $handle ) {
            return array(
                'success' => false,
                'message' => __( 'Failed to open file.', 'scheduled-results-manager' ),
            );
        }

        $header = fgetcsv( $handle );
        if ( ! $header ) {
            fclose( $handle );
            return array(
                'success' => false,
                'message' => __( 'Empty or invalid CSV file.', 'scheduled-results-manager' ),
            );
        }

        // Normalise header keys
        $header = array_map( 'strtolower', array_map( 'trim', $header ) );

        $required = array( 'date', 'result', 'status' );
        foreach ( $required as $col ) {
            if ( ! in_array( $col, $header, true ) ) {
                fclose( $handle );
                return array(
                    'success' => false,
                    'message' => sprintf(
                        /* translators: %s column name */
                        __( 'Missing required column: %s', 'scheduled-results-manager' ),
                        $col
                    ),
                );
            }
        }

        if ( ! in_array( 'game', $header, true ) && ! in_array( 'event', $header, true ) ) {
            fclose( $handle );
            return array(
                'success' => false,
                'message' => __( 'Missing required column: game', 'scheduled-results-manager' ),
            );
        }

        $col_index = array_flip( $header );
        $game_col  = isset( $col_index['game'] ) ? 'game' : 'event';

        $total   = 0;
        $success = 0;
        $failed  = 0;
        $errors  = array();

        while ( ( $row = fgetcsv( $handle ) ) !== false ) {
            $total++;
            $line = $total + 1; // account for header row

            $date_raw   = trim( $row[ $col_index['date'] ] ?? '' );
            $game_name  = trim( $row[ $col_index[ $game_col ] ] ?? '' );
            $result_val = trim( $row[ $col_index['result'] ] ?? '' );
            $status     = trim( strtolower( $row[ $col_index['status'] ] ?? 'pending' ) );

            // Validate date
            $date = self::parse_date( $date_raw );
            if ( ! $date ) {
                $failed++;
                $errors[] = "Row {$line}: Invalid date '{$date_raw}'.";
                continue;
            }

            // Validate status
            if ( ! in_array( $status, array( 'pending', 'published' ), true ) ) {
                $status = 'pending';
            }

            // Find game by its stored primary name.
            global $wpdb;
            $games_table = SRM_Database::events_table();
            $game = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id FROM {$games_table} WHERE event_name = %s",
                    $game_name
                )
            );

            if ( ! $game ) {
                $failed++;
                $errors[] = "Row {$line}: Game not found: '{$game_name}'.";
                continue;
            }

            $save_result = SRM_Results::save_result( (int) $game->id, $date, array(
                'result_value'  => SRM_Results::sanitize_result_value( $result_val ),
                'result_status' => $status,
            ) );

            if ( is_wp_error( $save_result ) ) {
                $failed++;
                $errors[] = "Row {$line}: " . $save_result->get_error_message();
            } else {
                $success++;
            }
        }

        fclose( $handle );

        return array(
            'success'      => true,
            'total'        => $total,
            'imported'     => $success,
            'failed'       => $failed,
            'errors'       => $errors,
        );
    }

    /**
     * Export results to CSV.
     *
     * @param string|null $start_date Y-m-d
     * @param string|null $end_date   Y-m-d
     * @return void Outputs CSV and exits.
     */
    public static function export_csv( ?string $start_date = null, ?string $end_date = null ): void {
        global $wpdb;

        $results_table = SRM_Database::results_table();
        $events_table  = SRM_Database::events_table();

        if ( ! $start_date ) {
            $start_date = date( 'Y-m-01' );
        }
        if ( ! $end_date ) {
            $end_date = date( 'Y-m-t' );
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT r.result_date, e.event_name, r.result_value, r.result_status
                 FROM {$results_table} r
                 JOIN {$events_table} e ON e.id = r.event_id
                 WHERE r.result_date BETWEEN %s AND %s
                 ORDER BY r.result_date ASC, e.display_order ASC, e.scheduled_time ASC",
                $start_date,
                $end_date
            )
        ) ?: array();

        $filename = 'srm-results-' . $start_date . '-to-' . $end_date . '.csv';

        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );

        $output = fopen( 'php://output', 'w' );
        fputcsv( $output, array( 'date', 'game', 'result', 'status' ) );

        foreach ( $rows as $row ) {
            fputcsv( $output, array(
                $row->result_date,
                $row->event_name,
                $row->result_value ?? '',
                $row->result_status,
            ) );
        }

        fclose( $output );
        exit;
    }

    /**
     * Parse a date string into Y-m-d.
     * Supports: Y-m-d, d/m/Y, m/d/Y
     *
     * @param string $raw
     * @return string|false
     */
    private static function parse_date( string $raw ): string|false {
        // Y-m-d
        if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m ) ) {
            if ( checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
                return $raw;
            }
        }
        // d/m/Y
        if ( preg_match( '/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $raw, $m ) ) {
            if ( checkdate( (int) $m[2], (int) $m[1], (int) $m[3] ) ) {
                return sprintf( '%04d-%02d-%02d', $m[3], $m[2], $m[1] );
            }
        }
        return false;
    }
}
