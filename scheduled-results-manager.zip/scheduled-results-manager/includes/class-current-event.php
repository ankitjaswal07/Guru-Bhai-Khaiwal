<?php
/**
 * Current Game Service Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Current_Event
 * Central service for current/next event calculations.
 */
class SRM_Current_Event {

    /**
     * Get the current game based on the WordPress site timezone.
     *
     * The current game is the chronologically latest active game whose
     * scheduled time has passed today. Display order does not affect this.
     *
     * @return object|null
     */
    public static function get_current_game(): ?object {
        $games        = SRM_Games::get_active_games();
        $current_time = self::get_site_time_seconds();
        $current_game = null;
        $latest_time  = -1;

        foreach ( $games as $game ) {
            $game_time = self::time_to_seconds( $game->scheduled_time );
            if ( $game_time <= $current_time && $game_time > $latest_time ) {
                $current_game = $game;
                $latest_time  = $game_time;
            }
        }

        return $current_game;
    }

    /**
     * Get the next upcoming game.
     *
     * When every game for today has passed, the earliest scheduled game is
     * returned for tomorrow.
     *
     * @return object|null
     */
    public static function get_next_game(): ?object {
        $games        = SRM_Games::get_active_games();
        $current_time = self::get_site_time_seconds();
        $next_game    = null;
        $next_time    = PHP_INT_MAX;

        foreach ( $games as $game ) {
            $game_time = self::time_to_seconds( $game->scheduled_time );
            if ( $game_time > $current_time && $game_time < $next_time ) {
                $next_game = $game;
                $next_time = $game_time;
            }
        }

        if ( $next_game ) {
            return $next_game;
        }

        $first_game = null;
        $first_time = PHP_INT_MAX;
        foreach ( $games as $game ) {
            $game_time = self::time_to_seconds( $game->scheduled_time );
            if ( $game_time < $first_time ) {
                $first_game = $game;
                $first_time = $game_time;
            }
        }

        return $first_game;
    }

    /**
     * Determine whether the next game is scheduled for tomorrow.
     *
     * @return bool
     */
    public static function is_next_game_tomorrow(): bool {
        $games        = SRM_Games::get_active_games();
        $current_time = self::get_site_time_seconds();

        if ( empty( $games ) ) {
            return false;
        }

        foreach ( $games as $game ) {
            if ( self::time_to_seconds( $game->scheduled_time ) > $current_time ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get event status for today.
     *
     * @param object $event
     * @return string pending|published|upcoming
     */
    public static function get_game_status( object $event ): string {
        $result = SRM_Results::get_result( (int) $event->id, SRM_Results::get_site_date() );

        if ( ! $result ) {
            // Check if event has started
            $event_seconds = self::time_to_seconds( $event->scheduled_time );
            $current_time  = self::get_site_time_seconds();

            if ( $event_seconds > $current_time ) {
                return 'upcoming';
            }
            return 'pending';
        }

        return $result->result_status;
    }

    /**
     * Get seconds remaining until the next event.
     *
     * @return int Seconds. Negative if all events passed (seconds until midnight + first event tomorrow).
     */
    public static function get_remaining_seconds(): int {
        $next          = self::get_next_game();
        $current_time  = self::get_site_time_seconds();

        if ( ! $next ) {
            return 0;
        }

        $next_seconds = self::time_to_seconds( $next->scheduled_time );

        if ( self::is_next_game_tomorrow() ) {
            // Seconds until midnight + time of first event
            $seconds_to_midnight = 86400 - $current_time;
            return $seconds_to_midnight + $next_seconds;
        }

        return max( 0, $next_seconds - $current_time );
    }

    /**
     * Get the UNIX timestamp of when the next event fires (for JS countdown).
     *
     * @return int
     */
    public static function get_next_game_timestamp(): int {
        $tz           = wp_timezone();
        $now          = new DateTime( 'now', $tz );
        $next         = self::get_next_game();

        if ( ! $next ) {
            return 0;
        }

        $next_time = self::time_to_seconds( $next->scheduled_time );
        $now_time  = self::get_site_time_seconds();

        if ( self::is_next_game_tomorrow() ) {
            $tomorrow = new DateTime( 'tomorrow', $tz );
            $tomorrow->setTime(
                (int) floor( $next_time / 3600 ),
                (int) floor( ( $next_time % 3600 ) / 60 ),
                $next_time % 60
            );
            return $tomorrow->getTimestamp();
        }

        $today = clone $now;
        $today->setTime(
            (int) floor( $next_time / 3600 ),
            (int) floor( ( $next_time % 3600 ) / 60 ),
            $next_time % 60
        );

        return $today->getTimestamp();
    }

    /**
     * Get today's full schedule with results and statuses.
     *
     * @return array<object>
     */
    public static function get_today_schedule(): array {
        return SRM_Results::get_today_results();
    }

    /**
     * AJAX: Return live status JSON.
     */
    public static function ajax_live_status(): void {
        check_ajax_referer( 'srm_public_nonce', 'nonce' );

        $data = self::build_live_status_data();
        wp_send_json_success( $data );
    }

    /**
     * Build live status array for REST/AJAX response.
     *
     * @return array<string,mixed>
     */
    public static function build_live_status_data(): array {
        $tz  = wp_timezone();
        $now = new DateTime( 'now', $tz );

        $current_game = self::get_current_game();
        $next_game    = self::get_next_game();
        $is_tomorrow   = self::is_next_game_tomorrow();

        $current_data = null;
        if ( $current_game ) {
            $result = SRM_Results::get_result( (int) $current_game->id, SRM_Results::get_site_date() );
            $current_data = array(
                'id'           => (int) $current_game->id,
                'name'         => esc_html( $current_game->event_name ),
                'name_secondary' => esc_html( $current_game->event_name_secondary ?? '' ),
                'time'         => SRM_Games::format_time( $current_game->scheduled_time ),
                'time_24'      => $current_game->scheduled_time,
                'status'       => self::get_game_status( $current_game ),
                'result'       => $result ? esc_html( $result->result_value ) : null,
            );
        }

        $next_data = null;
        if ( $next_game ) {
            $next_data = array(
                'id'             => (int) $next_game->id,
                'name'           => esc_html( $next_game->event_name ),
                'name_secondary' => ! empty( $next_game->event_name_secondary ) && false === strpos( (string) $next_game->event_name, (string) $next_game->event_name_secondary ) ? esc_html( $next_game->event_name_secondary ) : '',
                'time'           => SRM_Games::format_time( $next_game->scheduled_time ),
                'time_24'        => $next_game->scheduled_time,
                'is_tomorrow'    => $is_tomorrow,
                'timestamp'      => self::get_next_game_timestamp(),
            );
        }

        $latest_data = $current_data;
        if ( ! $latest_data && $next_data ) {
            $latest_data = array_merge(
                $next_data,
                array(
                    'status' => 'upcoming',
                    'result' => null,
                )
            );
        }

        return array(
            'current_game' => $current_data,
            'latest_game'  => $latest_data,
            'next_game'    => $next_data,
            'server_time'  => $now->format( 'Y-m-d H:i:s' ),
            'server_ts'    => $now->getTimestamp(),
            'timezone'     => $tz->getName(),
            'today_date'   => $now->format( 'd/m/Y' ),
        );
    }

    /**
     * Convert TIME string HH:MM:SS to seconds since midnight.
     *
     * @param string $time
     * @return int
     */
    public static function time_to_seconds( string $time ): int {
        $parts = explode( ':', $time );
        return ( (int) ( $parts[0] ?? 0 ) ) * 3600
             + ( (int) ( $parts[1] ?? 0 ) ) * 60
             + ( (int) ( $parts[2] ?? 0 ) );
    }

    /**
     * Get current site seconds since midnight.
     *
     * @return int
     */
    public static function get_site_time_seconds(): int {
        $tz  = wp_timezone();
        $now = new DateTime( 'now', $tz );
        return (int) $now->format( 'G' ) * 3600
             + (int) $now->format( 'i' ) * 60
             + (int) $now->format( 's' );
    }
}
