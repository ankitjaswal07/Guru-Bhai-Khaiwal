<?php
/**
 * REST API Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_API
 */
class SRM_API {

    const NAMESPACE = 'srm/v1';

    /**
     * Register REST routes.
     */
    public static function register_routes(): void {
        // Current status endpoint (public)
        register_rest_route( self::NAMESPACE, '/current', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_current_status' ),
            'permission_callback' => '__return_true',
        ) );

        // Today's results
        register_rest_route( self::NAMESPACE, '/today', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_today_results' ),
            'permission_callback' => '__return_true',
        ) );

        // Monthly results
        register_rest_route( self::NAMESPACE, '/monthly', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_monthly_results' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'month' => array(
                    'type'    => 'integer',
                    'minimum' => 1,
                    'maximum' => 12,
                ),
                'year' => array(
                    'type'    => 'integer',
                    'minimum' => 2000,
                    'maximum' => 2100,
                ),
            ),
        ) );

        // Games list.
        register_rest_route( self::NAMESPACE, '/games', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_games' ),
            'permission_callback' => '__return_true',
        ) );

        // Legacy route alias retained for existing integrations.
        register_rest_route( self::NAMESPACE, '/events', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_games' ),
            'permission_callback' => '__return_true',
        ) );
    }

    /**
     * GET /wp-json/srm/v1/current
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function get_current_status( WP_REST_Request $request ): WP_REST_Response {
        $data = SRM_Current_Event::build_live_status_data();
        return new WP_REST_Response( $data, 200 );
    }

    /**
     * GET /wp-json/srm/v1/today
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function get_today_results( WP_REST_Request $request ): WP_REST_Response {
        $rows    = SRM_Results::get_today_results();
        $results = array();

        foreach ( $rows as $row ) {
            $results[] = array(
                'game_id'        => (int) $row->event_id,
                'game_name'      => esc_html( $row->event_name ),
                'scheduled_time' => SRM_Games::format_time( $row->scheduled_time ),
                'result'         => null !== $row->result_value && '' !== (string) $row->result_value ? esc_html( $row->result_value ) : null,
                'status'         => $row->result_status ?? 'pending',
            );
        }

        $tz  = wp_timezone();
        $now = new DateTime( 'now', $tz );

        return new WP_REST_Response( array(
            'date'    => $now->format( 'Y-m-d' ),
            'results' => $results,
        ), 200 );
    }

    /**
     * GET /wp-json/srm/v1/monthly?month=8&year=2026
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function get_monthly_results( WP_REST_Request $request ): WP_REST_Response {
        $tz    = wp_timezone();
        $now   = new DateTime( 'now', $tz );
        $month = (int) ( $request->get_param( 'month' ) ?? $now->format( 'n' ) );
        $year  = (int) ( $request->get_param( 'year' ) ?? $now->format( 'Y' ) );

        $events  = SRM_Games::get_active_games();
        $data    = SRM_Results::get_monthly_results( $year, $month );
        $days    = (int) date( 't', mktime( 0, 0, 0, $month, 1, $year ) );

        $rows = array();
        for ( $d = 1; $d <= $days; $d++ ) {
            $date    = sprintf( '%04d-%02d-%02d', $year, $month, $d );
            $row_obj = array( 'date' => $date, 'results' => array() );

            foreach ( $events as $event ) {
                $result = $data[ $date ][ $event->id ] ?? null;
                $row_obj['results'][ (int) $event->id ] = $result ? esc_html( $result->result_value ) : null;
            }
            $rows[] = $row_obj;
        }

        $event_cols = array();
        foreach ( $events as $event ) {
            $event_cols[] = array(
                'id'   => (int) $event->id,
                'name' => esc_html( $event->event_name ),
                'time' => SRM_Games::format_time( $event->scheduled_time ),
            );
        }

        return new WP_REST_Response( array(
            'month' => $month,
            'year'  => $year,
            'games' => $event_cols,
            'rows'  => $rows,
        ), 200 );
    }

    /**
     * GET /wp-json/srm/v1/games
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response
     */
    public static function get_games( WP_REST_Request $request ): WP_REST_Response {
        $games  = SRM_Games::get_active_games();
        $output = array();

        foreach ( $games as $game ) {
            $output[] = array(
                'id'             => (int) $game->id,
                'name'           => esc_html( $game->event_name ),
                'name_secondary' => ! empty( $game->event_name_secondary ) && false === strpos( (string) $game->event_name, (string) $game->event_name_secondary ) ? esc_html( $game->event_name_secondary ) : '',
                'time'           => SRM_Games::format_time( $game->scheduled_time ),
                'time_24'        => $game->scheduled_time,
                'display_order'  => (int) $game->display_order,
            );
        }

        return new WP_REST_Response( $output, 200 );
    }
}
