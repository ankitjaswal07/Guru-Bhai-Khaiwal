<?php
/**
 * Main Plugin Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Plugin
 * Central bootstrap class.
 */
class SRM_Plugin {

    /** @var SRM_Plugin|null */
    private static ?SRM_Plugin $instance = null;

    /**
     * Get singleton instance.
     */
    public static function get_instance(): SRM_Plugin {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Init hooks.
     */
    private function init_hooks(): void {
        // Apply database/default-data upgrades once per plugin version.
        add_action( 'init', array( $this, 'maybe_upgrade' ), 5 );

        // Register REST API routes
        add_action( 'rest_api_init', array( 'SRM_API', 'register_routes' ) );

        // Register shortcodes
        add_action( 'init', array( 'SRM_Shortcodes', 'register' ) );

        // Admin
        if ( is_admin() ) {
            $admin = new SRM_Admin();
            $admin->init();
        }

        // Public
        if ( ! is_admin() ) {
            $public = new SRM_Public();
            $public->init();
        }

        // AJAX handlers (logged-in users)
        add_action( 'wp_ajax_srm_save_result',       array( 'SRM_Results', 'ajax_save_result' ) );
        add_action( 'wp_ajax_srm_delete_result',     array( 'SRM_Results', 'ajax_delete_result' ) );
        add_action( 'wp_ajax_srm_save_event_order',  array( 'SRM_Games', 'ajax_save_order' ) );
        add_action( 'wp_ajax_srm_toggle_game',      array( 'SRM_Games', 'ajax_toggle_status' ) );
        add_action( 'wp_ajax_srm_get_live_status',   array( 'SRM_Current_Event', 'ajax_live_status' ) );

        // AJAX for non-logged-in (public live status)
        add_action( 'wp_ajax_nopriv_srm_get_live_status', array( 'SRM_Current_Event', 'ajax_live_status' ) );
    }

    /**
     * Apply database and default-data upgrades when the plugin version changes.
     */
    public function maybe_upgrade(): void {
        $installed_version = (string) get_option( SRM_Database::DB_VERSION_OPTION, '0.0.0' );
        if ( version_compare( $installed_version, SRM_Database::DB_VERSION, '<' ) ) {
            SRM_Database::install();
        }
    }

    /**
     * Plugin deactivation.
     */
    public static function deactivate(): void {
        flush_rewrite_rules();
    }
}
