<?php
/**
 * Shortcodes Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Shortcodes
 */
class SRM_Shortcodes {

    /**
     * Register all shortcodes.
     */
    public static function register(): void {
        $codes = array(
            'srm_current_game'            => 'render_current_game',
            'srm_current_game_name'       => 'render_current_game_name',
            'srm_current_game_time'       => 'render_current_game_time',
            'srm_latest_game_result'      => 'render_latest_game_result',
            'srm_current_result'          => 'render_current_result',
            'srm_next_game'               => 'render_next_game',
            'srm_live_status'             => 'render_live_status',
            'srm_today_results'           => 'render_today_results',
            'srm_yesterday_results'       => 'render_yesterday_results',
            'srm_today_yesterday_results' => 'render_today_yesterday_results',
            'srm_monthly_results'         => 'render_monthly_results',
            'srm_full_month_results'      => 'render_monthly_results',
            'srm_previous_month_results'  => 'render_previous_month_results',
            'srm_previous_month_table'    => 'render_previous_month_results',
            'srm_game_history'            => 'render_game_history',
            // Legacy alias retained so existing pages do not break.
            'srm_event_history'           => 'render_game_history',
            // Active games list (plural and aliases)
            'srm_active_games'            => 'render_active_games',
            'srm_active_game_list'        => 'render_active_games',
            'srm_active_games_list'       => 'render_active_games',
            // Legacy/singular alias
            'srm_active_game'             => 'render_active_games',
        );

        foreach ( $codes as $tag => $method ) {
            add_shortcode( $tag, array( __CLASS__, $method ) );
        }
    }

    // -----------------------------------------------------------------------
    // TODAY RESULTS
    // -----------------------------------------------------------------------

    /**
     * [srm_today_results show_time="yes"]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_today_results( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_time'       => 'yes',
            'show_secondary'  => 'no',
            'title'           => '',
        ), $atts, 'srm_today_results' );

        $results   = SRM_Results::get_today_results();
        $today_str = wp_date( get_option( 'srm_date_format', 'd/m/Y' ) );

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/today-results.php';
        return ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // YESTERDAY RESULTS
    // -----------------------------------------------------------------------

    /**
     * [srm_yesterday_results]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_yesterday_results( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_time'      => 'yes',
            'show_secondary' => 'no',
            'title'          => '',
        ), $atts, 'srm_yesterday_results' );

        $results = SRM_Results::get_yesterday_results();

        $tz        = wp_timezone();
        $yesterday = new DateTime( 'yesterday', $tz );
        $date_str  = $yesterday->format( get_option( 'srm_date_format', 'd/m/Y' ) );

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/yesterday-results.php';
        return (string) ob_get_clean();
    }

    /**
     * Show yesterday and today results together with game names.
     *
     * [srm_today_yesterday_results show_time="yes" show_secondary="yes"]
     *
     * @param array<string,string> $atts Shortcode attributes.
     * @return string
     */
    public static function render_today_yesterday_results( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_time'      => 'yes',
            'show_secondary' => 'no',
            'title'          => '',
        ), $atts, 'srm_today_yesterday_results' );

        $tz                = wp_timezone();
        $now               = new DateTime( 'now', $tz );
        $yesterday         = new DateTime( 'yesterday', $tz );
        $date_format       = get_option( 'srm_date_format', 'd/m/Y' );
        $today_results     = SRM_Results::get_today_results();
        $yesterday_results = SRM_Results::get_yesterday_results();
        $today_str         = $now->format( $date_format );
        $yesterday_str     = $yesterday->format( $date_format );

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/today-yesterday-results.php';
        return (string) ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // MONTHLY RESULTS
    // -----------------------------------------------------------------------

    /**
    * [srm_monthly_results game_id="3" month="08" year="2026" show_filter="yes"]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_monthly_results( array $atts = array() ): string {
        $tz  = wp_timezone();
        $now = new DateTime( 'now', $tz );

        $atts = shortcode_atts( array(
            'game_id'     => '0',
            'month'       => $now->format( 'n' ),
            'year'        => $now->format( 'Y' ),
            'title'       => '',
            'show_filter' => 'yes',
        ), $atts, 'srm_monthly_results' );

        $game_id = isset( $_GET['srm_game_id'] ) ? absint( $_GET['srm_game_id'] ) : absint( $atts['game_id'] );
        $month   = isset( $_GET['srm_month'] ) ? absint( $_GET['srm_month'] ) : (int) $atts['month'];
        $year    = isset( $_GET['srm_year'] ) ? absint( $_GET['srm_year'] ) : (int) $atts['year'];
        $month   = max( 1, min( 12, $month ) );
        $year    = max( 2000, min( 2100, $year ) );
        $events = SRM_Games::get_active_games();
        $filter_events = $events;
        if ( $game_id > 0 ) {
            $events = array_values( array_filter( $events, static function ( $event ) use ( $game_id ): bool {
                return (int) $event->id === $game_id;
            } ) );
        }
        $data   = SRM_Results::get_monthly_results( $year, $month );
        $days   = (int) date( 't', mktime( 0, 0, 0, $month, 1, $year ) );

        $date_format = get_option( 'srm_date_format', 'd/m/Y' );
        $month_label = date( 'F Y', mktime( 0, 0, 0, $month, 1, $year ) );
        $selected_game_id = $game_id;
        $filter_options   = $filter_events;

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/monthly-results.php';
        return ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // PREVIOUS MONTH RESULTS
    // -----------------------------------------------------------------------

    /**
     * [srm_previous_month_results]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_previous_month_results( array $atts = array() ): string {
        $tz   = wp_timezone();
        $prev = new DateTime( 'first day of last month', $tz );

        $atts = shortcode_atts( array(
            'title' => '',
        ), $atts, 'srm_previous_month_results' );

        $month  = (int) $prev->format( 'n' );
        $year   = (int) $prev->format( 'Y' );
        $events = SRM_Games::get_active_games();
        $data   = SRM_Results::get_monthly_results( $year, $month );
        $days   = (int) $prev->format( 't' );

        $date_format = get_option( 'srm_date_format', 'd/m/Y' );
        $month_label = $prev->format( 'F Y' );

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/monthly-results.php';
        return ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // CURRENT GAME
    // -----------------------------------------------------------------------

    /**
     * [srm_current_game show_countdown="yes"]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_current_game( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_countdown' => 'no',
            'show_result'    => 'yes',
        ), $atts, 'srm_current_game' );

        $game   = SRM_Current_Event::get_current_game();
        $event  = $game; // Template compatibility with versions before 1.1.0.
        $result = null;
        $status = 'none';

        if ( $game ) {
            $status = SRM_Current_Event::get_game_status( $game );
            $result = SRM_Results::get_result( (int) $game->id, SRM_Results::get_site_date() );
        }

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/current-event.php';
        return (string) ob_get_clean();
    }

    /**
     * Show only the current game name.
     *
     * [srm_current_game_name show_secondary="yes" label="no"]
     *
     * @param array<string,string> $atts Shortcode attributes.
     * @return string
     */
    public static function render_current_game_name( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_secondary' => 'no',
            'label'          => 'yes',
        ), $atts, 'srm_current_game_name' );
        $game = SRM_Current_Event::get_current_game();

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/current-game-name.php';
        return (string) ob_get_clean();
    }

    /**
     * Show only the scheduled time of the current game.
     *
     * [srm_current_game_time label="yes"]
     *
     * @param array<string,string> $atts Shortcode attributes.
     * @return string
     */
    public static function render_current_game_time( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'label' => 'yes',
        ), $atts, 'srm_current_game_time' );
        $game = SRM_Current_Event::get_current_game();

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/current-game-time.php';
        return (string) ob_get_clean();
    }

    /**
     * Show the latest game selected by time, its scheduled time, and result state.
     * Before the first game, the first upcoming game is shown as waiting.
     *
     * [srm_latest_game_result show_secondary="yes"]
     *
     * @param array<string,string> $atts Shortcode attributes.
     * @return string
     */
    public static function render_latest_game_result( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_secondary' => 'yes',
            'show_result'    => 'yes',
            'title'          => '',
        ), $atts, 'srm_latest_game_result' );

        $game        = SRM_Current_Event::get_current_game();
        $is_upcoming = false;
        if ( ! $game ) {
            $game        = SRM_Current_Event::get_next_game();
            $is_upcoming = true;
        }

        $result = null;
        $status = $is_upcoming ? 'upcoming' : 'none';
        if ( $game && ! $is_upcoming ) {
            $result = SRM_Results::get_result( (int) $game->id, SRM_Results::get_site_date() );
            $status = SRM_Current_Event::get_game_status( $game );
        }

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/latest-game-result.php';
        return (string) ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // CURRENT RESULT
    // -----------------------------------------------------------------------

    /**
     * [srm_current_result]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_current_result( array $atts = array() ): string {
        $atts = shortcode_atts( array(), $atts, 'srm_current_result' );

        $event  = SRM_Current_Event::get_current_game();
        $result = null;

        if ( $event ) {
            $result = SRM_Results::get_result( (int) $event->id, SRM_Results::get_site_date() );
        }

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/current-result.php';
        return ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // NEXT GAME
    // -----------------------------------------------------------------------

    /**
     * [srm_next_game show_countdown="yes"]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_next_game( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_countdown' => 'yes',
        ), $atts, 'srm_next_game' );

        $event         = SRM_Current_Event::get_next_game();
        $is_tomorrow   = SRM_Current_Event::is_next_game_tomorrow();
        $next_ts       = SRM_Current_Event::get_next_game_timestamp();
        $remaining     = SRM_Current_Event::get_remaining_seconds();

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/next-event.php';
        return ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // LIVE STATUS
    // -----------------------------------------------------------------------

    /**
     * [srm_live_status]
     *
     * @param array<string,string> $atts
     * @return string
     */
    public static function render_live_status( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_current' => 'yes',
            'show_next'    => 'yes',
        ), $atts, 'srm_live_status' );

        $current_game = SRM_Current_Event::get_current_game();
        $next_game    = SRM_Current_Event::get_next_game();
        $is_tomorrow   = SRM_Current_Event::is_next_game_tomorrow();
        $next_ts       = SRM_Current_Event::get_next_game_timestamp();

        $current_result = null;
        $current_status = 'none';

        if ( $current_game ) {
            $current_status = SRM_Current_Event::get_game_status( $current_game );
            $current_result = SRM_Results::get_result( (int) $current_game->id, SRM_Results::get_site_date() );
        }

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/live-status.php';
        return ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // ACTIVE GAMES
    // -----------------------------------------------------------------------

    /**
     * [srm_active_games show_time="yes" show_secondary="no" ul_class=""]
     *
     * @param array<string,string> $atts Shortcode attributes.
     * @return string
     */
    public static function render_active_games( array $atts = array() ): string {
        $atts = shortcode_atts( array(
            'show_time'      => 'yes',
            'show_secondary' => 'no',
            'ul_class'       => '',
        ), $atts, 'srm_active_games' );

        $games = SRM_Games::get_active_games();

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/active-games.php';
        return (string) ob_get_clean();
    }

    // -----------------------------------------------------------------------
    // GAME HISTORY
    // -----------------------------------------------------------------------

    /**
     * [srm_game_history game_id="12" month="08" year="2026" limit="31"]
     *
     * @param array<string,string> $atts Shortcode attributes.
     * @return string
     */
    public static function render_game_history( array $atts = array() ): string {
        $tz  = wp_timezone();
        $now = new DateTime( 'now', $tz );

        $atts = shortcode_atts( array(
            'game_id'  => '0',
            'event_id' => '0',
            'month'    => $now->format( 'n' ),
            'year'     => $now->format( 'Y' ),
            'limit'    => '31',
        ), $atts, 'srm_game_history' );

        $game_id = absint( $atts['game_id'] );
        if ( ! $game_id ) {
            $game_id = absint( $atts['event_id'] );
        }
        $event_id = $game_id; // Internal database compatibility.
        $month    = (int) $atts['month'];
        $year     = (int) $atts['year'];
        $limit    = min( absint( $atts['limit'] ), 365 );

        if ( ! $game_id ) {
            return '<p class="srm-error">' . esc_html__( 'Please provide a valid game_id.', 'scheduled-results-manager' ) . '</p>';
        }

        $event = SRM_Games::get_game( $game_id );
        if ( ! $event ) {
            return '<p class="srm-error">' . esc_html__( 'Game not found.', 'scheduled-results-manager' ) . '</p>';
        }

        global $wpdb;
        $results_table = SRM_Database::results_table();
        $start = sprintf( '%04d-%02d-01', $year, $month );
        $end   = date( 'Y-m-t', strtotime( $start ) );

        $history = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$results_table}
                 WHERE event_id = %d AND result_date BETWEEN %s AND %s
                 ORDER BY result_date ASC
                 LIMIT %d",
                $event_id,
                $start,
                $end,
                $limit
            )
        ) ?: array();

        $date_format = get_option( 'srm_date_format', 'd/m/Y' );
        $month_label = date( 'F Y', mktime( 0, 0, 0, $month, 1, $year ) );

        ob_start();
        include SRM_PLUGIN_DIR . 'templates/event-history.php';
        return ob_get_clean();
    }
}
