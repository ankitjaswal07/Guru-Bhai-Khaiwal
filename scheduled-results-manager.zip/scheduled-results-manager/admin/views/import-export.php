<?php
/**
 * Admin Import / Export View
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! SRM_Access::current_user_can_access_plugin() ) {
    wp_die( esc_html__( 'You do not have permission to access this page.', 'scheduled-results-manager' ) );
}

$import_result = get_transient( 'srm_import_result_' . get_current_user_id() );
if ( $import_result ) {
    delete_transient( 'srm_import_result_' . get_current_user_id() );
}
?>
<div class="wrap srm-admin-wrap">
    <h1 class="srm-page-title">
        <span class="dashicons dashicons-database-import"></span>
        <?php esc_html_e( 'Import / Export', 'scheduled-results-manager' ); ?>
    </h1>

    <div class="srm-two-columns">

        <!-- Import -->
        <div class="srm-column">
            <div class="srm-box">
                <h2><?php esc_html_e( 'Import Results', 'scheduled-results-manager' ); ?></h2>
                <p><?php esc_html_e( 'Upload a CSV file to import results. The file must have the following columns:', 'scheduled-results-manager' ); ?></p>
                <pre class="srm-csv-example">date,game,result,status
2026-08-01,IPL / आई पी एल,98,published
2026-08-01,RDL BAZAR / RDL बाजार,34,published
2026-08-01,Delhi Bazar / दिल्ली बाज़ार,71,published</pre>

                <?php if ( $import_result && ! empty( $import_result['success'] ) ) : ?>
                <div class="srm-import-results notice notice-info">
                    <h4><?php esc_html_e( 'Import Results', 'scheduled-results-manager' ); ?></h4>
                    <ul>
                        <li><?php printf( esc_html__( 'Total rows: %d', 'scheduled-results-manager' ), (int) $import_result['total'] ); ?></li>
                        <li><?php printf( esc_html__( 'Imported: %d', 'scheduled-results-manager' ), (int) $import_result['imported'] ); ?></li>
                        <li><?php printf( esc_html__( 'Failed: %d', 'scheduled-results-manager' ), (int) $import_result['failed'] ); ?></li>
                    </ul>
                    <?php if ( ! empty( $import_result['errors'] ) ) : ?>
                        <ul class="srm-import-errors">
                            <?php foreach ( $import_result['errors'] as $error ) : ?>
                                <li><?php echo esc_html( $error ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <form method="post" action="" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'srm_import_csv' ); ?>
                    <input type="hidden" name="srm_action" value="import_csv">
                    <table class="form-table srm-form-table">
                        <tr>
                            <th><label for="import_file"><?php esc_html_e( 'CSV File', 'scheduled-results-manager' ); ?></label></th>
                            <td>
                                <input type="file" id="import_file" name="import_file" accept=".csv,text/csv" required>
                                <p class="description"><?php esc_html_e( 'Accepted format: .csv', 'scheduled-results-manager' ); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Import CSV', 'scheduled-results-manager' ); ?></button></p>
                </form>
            </div>
        </div>

        <!-- Export -->
        <div class="srm-column">
            <div class="srm-box">
                <h2><?php esc_html_e( 'Export Results', 'scheduled-results-manager' ); ?></h2>
                <p><?php esc_html_e( 'Export results for a date range as a CSV file.', 'scheduled-results-manager' ); ?></p>

                <form method="post" action="">
                    <?php wp_nonce_field( 'srm_export_csv' ); ?>
                    <input type="hidden" name="srm_action" value="export_csv">
                    <table class="form-table srm-form-table">
                        <tr>
                            <th><label for="export_start"><?php esc_html_e( 'Start Date', 'scheduled-results-manager' ); ?></label></th>
                            <td>
                                <input type="date" id="export_start" name="export_start"
                                       value="<?php echo esc_attr( date( 'Y-m-01' ) ); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="export_end"><?php esc_html_e( 'End Date', 'scheduled-results-manager' ); ?></label></th>
                            <td>
                                <input type="date" id="export_end" name="export_end"
                                       value="<?php echo esc_attr( date( 'Y-m-t' ) ); ?>">
                            </td>
                        </tr>
                    </table>
                    <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Export CSV', 'scheduled-results-manager' ); ?></button></p>
                </form>
            </div>

            <!-- Shortcodes Reference -->
            <div class="srm-box srm-shortcodes-ref">
                <h2><?php esc_html_e( 'Shortcode Reference', 'scheduled-results-manager' ); ?></h2>
                <table class="srm-info-table">
                    <tr><td><code>[srm_current_game]</code></td><td><?php esc_html_e( 'Current game card with result status', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_current_game_name]</code></td><td><?php esc_html_e( 'Current game name only', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_current_game_time]</code></td><td><?php esc_html_e( 'Current game time only', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_latest_game_result]</code></td><td><?php esc_html_e( 'Latest game name, time, result status, and result', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_today_yesterday_results]</code></td><td><?php esc_html_e( 'Yesterday and today results with game names', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_today_results]</code></td><td><?php esc_html_e( "Today's game results table", 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_yesterday_results]</code></td><td><?php esc_html_e( "Yesterday's game results table", 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_full_month_results]</code></td><td><?php esc_html_e( 'Full current-month game results table', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_monthly_results month="08" year="2026"]</code></td><td><?php esc_html_e( 'Selected month game results table', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_previous_month_results]</code></td><td><?php esc_html_e( 'Previous-month game results table', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_next_game]</code></td><td><?php esc_html_e( 'Next game with countdown', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_live_status]</code></td><td><?php esc_html_e( 'Combined current and next game status', 'scheduled-results-manager' ); ?></td></tr>
                    <tr><td><code>[srm_game_history game_id="1"]</code></td><td><?php esc_html_e( 'Individual game history', 'scheduled-results-manager' ); ?></td></tr>
                </table>
            </div>
        </div>
    </div>
</div>
