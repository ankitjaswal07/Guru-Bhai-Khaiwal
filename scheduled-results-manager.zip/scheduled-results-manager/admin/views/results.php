<?php
/**
 * Admin Daily Results View
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! SRM_Access::current_user_can_access_plugin() ) {
    wp_die( esc_html__( 'You do not have permission to access this page.', 'scheduled-results-manager' ) );
}

$selected_date  = isset( $_GET['result_date'] ) ? sanitize_text_field( $_GET['result_date'] ) : wp_date( 'Y-m-d' );
$display_date   = wp_date( get_option( 'srm_date_format', 'd/m/Y' ), strtotime( $selected_date ) );
$results        = SRM_Results::get_results_for_date( $selected_date );
$allow_deletion = get_option( 'srm_allow_deletion', '1' );
?>
<div class="wrap srm-admin-wrap">
    <h1 class="srm-page-title">
        <span class="dashicons dashicons-edit"></span>
        <?php esc_html_e( 'Daily Results', 'scheduled-results-manager' ); ?>
    </h1>

    <!-- Date Selector -->
    <div class="srm-date-selector">
        <form method="get" action="">
            <input type="hidden" name="page" value="srm-results">
            <label for="result_date"><strong><?php esc_html_e( 'Select Date:', 'scheduled-results-manager' ); ?></strong></label>
            <input type="date" id="result_date" name="result_date"
                   value="<?php echo esc_attr( $selected_date ); ?>">
            <button type="submit" class="button button-primary"><?php esc_html_e( 'Load', 'scheduled-results-manager' ); ?></button>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=srm-results' ) ); ?>" class="button button-secondary">
                <?php esc_html_e( 'Today', 'scheduled-results-manager' ); ?>
            </a>
        </form>
        <div class="srm-selected-date">
            <?php
            printf(
                /* translators: %s date string */
                esc_html__( 'Showing results for: %s', 'scheduled-results-manager' ),
                '<strong>' . esc_html( $display_date ) . '</strong>'
            );
            ?>
        </div>
    </div>

    <div id="srm-ajax-message" class="srm-ajax-message" style="display:none;"></div>

    <?php if ( empty( $results ) ) : ?>
        <p><?php esc_html_e( 'No active games found. Please add games first.', 'scheduled-results-manager' ); ?></p>
    <?php else : ?>

    <!-- Bulk Save Controls -->
    <div class="srm-bulk-controls">
        <button type="button" id="srm-save-all" class="button button-primary">
            <?php esc_html_e( 'Save All Results', 'scheduled-results-manager' ); ?>
        </button>
        <button type="button" id="srm-publish-all" class="button button-secondary">
            <?php esc_html_e( 'Publish All', 'scheduled-results-manager' ); ?>
        </button>
        <span id="srm-bulk-status" style="margin-left:10px;"></span>
      
            <a href="https://satta20.com" class="button button-secondary">
               Back To Home
            </a>

    </div>

    <table class="wp-list-table widefat fixed striped srm-results-table" id="srm-results-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Game', 'scheduled-results-manager' ); ?></th>
                <th><?php esc_html_e( 'Scheduled Time', 'scheduled-results-manager' ); ?></th>
                <th><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></th>
                <th><?php esc_html_e( 'Status', 'scheduled-results-manager' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'scheduled-results-manager' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $results as $row ) : ?>
            <tr class="srm-result-row" data-event-id="<?php echo esc_attr( (string) $row->event_id ); ?>">
                <td>
                    <strong><?php echo esc_html( $row->event_name ); ?></strong>
                    <?php if ( $row->event_name_secondary ) : ?>
                        <br><small class="srm-secondary"><?php echo esc_html( $row->event_name_secondary ); ?></small>
                    <?php endif; ?>
                </td>
                <td><?php echo esc_html( SRM_Games::format_time( $row->scheduled_time ) ); ?></td>
                <td>
                    <input type="text" class="srm-result-input regular-text"
                           name="result_value[<?php echo esc_attr( (string) $row->event_id ); ?>]"
                           value="<?php echo esc_attr( $row->result_value ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Enter result...', 'scheduled-results-manager' ); ?>"
                           maxlength="50"
                           data-event-id="<?php echo esc_attr( (string) $row->event_id ); ?>"
                           data-date="<?php echo esc_attr( $selected_date ); ?>">
                </td>
                <td>
                    <select class="srm-status-select"
                            name="result_status[<?php echo esc_attr( (string) $row->event_id ); ?>]"
                            data-event-id="<?php echo esc_attr( (string) $row->event_id ); ?>">
                        <!-- <option value="pending" <?php selected( $row->result_status ?? 'pending', 'pending' ); ?>>
                            <?php esc_html_e( 'Pending', 'scheduled-results-manager' ); ?>
                        </option> -->
                        <option value="published" <?php selected( $row->result_status ?? '', 'published' ); ?>>
                            <?php esc_html_e( 'Published', 'scheduled-results-manager' ); ?>
                        </option>
                    </select>
                </td>
                <td class="srm-actions">
                    <button type="button" class="button button-small srm-save-single"
                            data-event-id="<?php echo esc_attr( (string) $row->event_id ); ?>"
                            data-date="<?php echo esc_attr( $selected_date ); ?>">
                        <?php echo $row->result_id ? esc_html__( 'Update', 'scheduled-results-manager' ) : esc_html__( 'Save', 'scheduled-results-manager' ); ?>
                    </button>
                    <?php if ( $allow_deletion && $row->result_id ) : ?>
                    <button type="button" class="button button-small button-link-delete srm-delete-result"
                            data-event-id="<?php echo esc_attr( (string) $row->event_id ); ?>"
                            data-date="<?php echo esc_attr( $selected_date ); ?>">
                        <?php esc_html_e( 'Clear', 'scheduled-results-manager' ); ?>
                    </button>
                    <?php endif; ?>
                    <span class="srm-row-status" id="row-status-<?php echo esc_attr( (string) $row->event_id ); ?>"></span>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <input type="hidden" id="srm-result-date" value="<?php echo esc_attr( $selected_date ); ?>">
    <?php endif; ?>
</div>
