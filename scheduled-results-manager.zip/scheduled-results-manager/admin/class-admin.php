<?php
/**
 * Admin Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Admin
 */
class SRM_Admin {

    /**
     * Current admin page slug.
     *
     * @var string
     */
    private string $current_page = '';

    /**
     * Init admin hooks.
     */
    public function init(): void {
        add_action( 'admin_menu',            array( $this, 'register_menus' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_notices',         array( $this, 'admin_notices' ) );
        add_action( 'admin_init',            array( $this, 'handle_actions' ) );
        add_action( 'show_user_profile',     array( $this, 'render_user_access_fields' ) );
        add_action( 'edit_user_profile',     array( $this, 'render_user_access_fields' ) );
        add_action( 'personal_options_update', array( $this, 'save_user_access_fields' ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_user_access_fields' ) );
    }

    /**
     * Register admin menus.
     */
    public function register_menus(): void {
        if ( ! SRM_Access::current_user_can_access_plugin() ) {
            return;
        }

        add_menu_page(
            __( 'Scheduled Results', 'scheduled-results-manager' ),
            __( 'Scheduled Results', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-dashboard',
            array( $this, 'page_dashboard' ),
            'dashicons-calendar-alt',
            30
        );

        add_submenu_page(
            'srm-dashboard',
            __( 'Dashboard', 'scheduled-results-manager' ),
            __( 'Dashboard', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-dashboard',
            array( $this, 'page_dashboard' )
        );

        add_submenu_page(
            'srm-dashboard',
            __( 'Games', 'scheduled-results-manager' ),
            __( 'Games', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-events',
            array( $this, 'page_events' )
        );

        add_submenu_page(
            'srm-dashboard',
            __( 'Daily Results', 'scheduled-results-manager' ),
            __( 'Daily Results', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-results',
            array( $this, 'page_results' )
        );

        add_submenu_page(
            'srm-dashboard',
            __( 'Monthly Results', 'scheduled-results-manager' ),
            __( 'Monthly Results', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-monthly',
            array( $this, 'page_monthly' )
        );

        add_submenu_page(
            'srm-dashboard',
            __( 'Settings', 'scheduled-results-manager' ),
            __( 'Settings', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-settings',
            array( $this, 'page_settings' )
        );

        add_submenu_page(
            'srm-dashboard',
            __( 'Import / Export', 'scheduled-results-manager' ),
            __( 'Import / Export', 'scheduled-results-manager' ),
            SRM_Access::capability(),
            'srm-import-export',
            array( $this, 'page_import_export' )
        );
    }

    /**
     * Enqueue admin assets.
     *
     * @param string $hook Current admin page hook.
     */
    public function enqueue_assets( string $hook ): void {
        // Only on our pages
        if ( strpos( $hook, 'srm-' ) === false && strpos( $hook, 'srm_' ) === false ) {
            return;
        }

        wp_enqueue_style(
            'srm-admin',
            SRM_PLUGIN_URL . 'admin/css/admin.css',
            array(),
            SRM_VERSION
        );

        wp_enqueue_script( 'jquery-ui-sortable' );

        wp_enqueue_script(
            'srm-admin',
            SRM_PLUGIN_URL . 'admin/js/admin.js',
            array( 'jquery', 'jquery-ui-sortable' ),
            SRM_VERSION,
            true
        );

        wp_localize_script( 'srm-admin', 'srmAdmin', array(
            'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'srm_admin_nonce' ),
            'strings'     => array(
                'confirmDelete'  => __( 'Are you sure you want to delete this?', 'scheduled-results-manager' ),
                'saving'         => __( 'Saving…', 'scheduled-results-manager' ),
                'saved'          => __( 'Saved!', 'scheduled-results-manager' ),
                'error'          => __( 'An error occurred. Please try again.', 'scheduled-results-manager' ),
            ),
        ) );
    }

    /**
     * Display admin notices from redirects.
     */
    public function admin_notices(): void {
        if ( ! SRM_Access::current_user_can_access_plugin() ) {
            return;
        }

        if ( ! isset( $_GET['srm_notice'] ) ) {
            return;
        }

        $messages = array(
            'event_created'   => array( 'success', __( 'Game created successfully.', 'scheduled-results-manager' ) ),
            'event_updated'   => array( 'success', __( 'Game updated successfully.', 'scheduled-results-manager' ) ),
            'event_deleted'   => array( 'success', __( 'Game deleted successfully.', 'scheduled-results-manager' ) ),
            'event_duplicate' => array( 'success', __( 'Game duplicated successfully.', 'scheduled-results-manager' ) ),
            'result_saved'    => array( 'success', __( 'Result saved successfully.', 'scheduled-results-manager' ) ),
            'settings_saved'  => array( 'success', __( 'Settings saved successfully.', 'scheduled-results-manager' ) ),
            'import_done'     => array( 'success', __( 'Import completed.', 'scheduled-results-manager' ) ),
            'error'           => array( 'error',   __( 'An error occurred. Please try again.', 'scheduled-results-manager' ) ),
        );

        $notice_key = sanitize_key( $_GET['srm_notice'] );

        if ( isset( $messages[ $notice_key ] ) ) {
            [ $type, $message ] = $messages[ $notice_key ];
            printf(
                '<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
                esc_attr( $type ),
                esc_html( $message )
            );
        }
    }

    /**
     * Handle non-AJAX admin actions (form submissions).
     */
    public function handle_actions(): void {
        if ( ! SRM_Access::current_user_can_access_plugin() ) {
            return;
        }

        $action = sanitize_key( $_REQUEST['srm_action'] ?? '' );

        if ( ! $action ) {
            return;
        }

        switch ( $action ) {
            case 'create_game':
                $this->handle_create_game();
                break;
            case 'update_game':
                $this->handle_update_game();
                break;
            case 'delete_game':
                $this->handle_delete_game();
                break;
            case 'duplicate_game':
                $this->handle_duplicate_game();
                break;
            case 'save_settings':
                $this->handle_save_settings();
                break;
            case 'export_csv':
                $this->handle_export_csv();
                break;
            case 'import_csv':
                $this->handle_import_csv();
                break;
        }
    }

    /**
     * Render allowed games selection in a user profile.
     *
     * @param WP_User $user User being edited.
     */
    public function render_user_access_fields( WP_User $user ): void {
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_scheduled_results' ) ) {
            return;
        }

        $games    = SRM_Games::get_all_games();
        $selected = SRM_Access::get_user_allowed_game_ids( (int) $user->ID );
        $selected_map = array_fill_keys( $selected, true );
        ?>
        <h3><?php esc_html_e( 'Scheduled Results Manager', 'scheduled-results-manager' ); ?></h3>
        <table class="form-table">
            <tr>
                <th><label><?php esc_html_e( 'Allowed Games', 'scheduled-results-manager' ); ?></label></th>
                <td>
                    <?php if ( empty( $games ) ) : ?>
                        <p><?php esc_html_e( 'No games yet. Add a game first to assign access.', 'scheduled-results-manager' ); ?></p>
                    <?php else : ?>
                        <fieldset>
                            <?php foreach ( $games as $game ) : ?>
                                <label style="display:block;margin:0 0 8px;">
                                    <input type="checkbox" name="srm_allowed_games[]" value="<?php echo esc_attr( (string) $game->id ); ?>" <?php checked( ! empty( $selected_map[ (int) $game->id ] ) ); ?>>
                                    <?php echo esc_html( $game->event_name ); ?>
                                </label>
                            <?php endforeach; ?>
                        </fieldset>
                    <?php endif; ?>
                    <p class="description"><?php esc_html_e( 'Only selected games will be available to this user.', 'scheduled-results-manager' ); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Save allowed games from user profile.
     *
     * @param int $user_id User being saved.
     */
    public function save_user_access_fields( int $user_id ): void {
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_scheduled_results' ) ) {
            return;
        }

        if ( ! isset( $_POST['srm_allowed_games'] ) ) {
            SRM_Access::save_user_allowed_games( $user_id, array() );
            return;
        }

        $selected = array_map( 'absint', (array) $_POST['srm_allowed_games'] );
        SRM_Access::save_user_allowed_games( $user_id, $selected );
    }

    // -----------------------------------------------------------------------
    // Page renderers
    // -----------------------------------------------------------------------

    public function page_dashboard(): void {
        require SRM_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public function page_events(): void {
        require SRM_PLUGIN_DIR . 'admin/views/events.php';
    }

    public function page_results(): void {
        require SRM_PLUGIN_DIR . 'admin/views/results.php';
    }

    public function page_monthly(): void {
        require SRM_PLUGIN_DIR . 'admin/views/monthly-results.php';
    }

    public function page_settings(): void {
        require SRM_PLUGIN_DIR . 'admin/views/settings.php';
    }

    public function page_import_export(): void {
        require SRM_PLUGIN_DIR . 'admin/views/import-export.php';
    }

    // -----------------------------------------------------------------------
    // Action handlers
    // -----------------------------------------------------------------------

    private function handle_create_game(): void {
        check_admin_referer( 'srm_create_game' );

        $result = SRM_Games::create_game( $_POST );

        if ( is_wp_error( $result ) ) {
            wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=error&srm_error=' . urlencode( $result->get_error_message() ) ) );
            exit;
        }

        wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=event_created' ) );
        exit;
    }

    private function handle_update_game(): void {
        check_admin_referer( 'srm_update_game' );

        $id     = absint( $_POST['event_id'] ?? 0 );
        $result = SRM_Games::update_game( $id, $_POST );

        if ( is_wp_error( $result ) ) {
            wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=error&srm_error=' . urlencode( $result->get_error_message() ) ) );
            exit;
        }

        wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=event_updated' ) );
        exit;
    }

    private function handle_delete_game(): void {
        $id = absint( $_GET['event_id'] ?? 0 );
        check_admin_referer( 'srm_delete_game_' . $id );

        SRM_Games::delete_game( $id );

        wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=event_deleted' ) );
        exit;
    }

    private function handle_duplicate_game(): void {
        $id = absint( $_GET['event_id'] ?? 0 );
        check_admin_referer( 'srm_duplicate_game_' . $id );

        $result = SRM_Games::duplicate_game( $id );

        if ( is_wp_error( $result ) ) {
            wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=error' ) );
            exit;
        }

        wp_redirect( admin_url( 'admin.php?page=srm-events&srm_notice=event_duplicate' ) );
        exit;
    }

    private function handle_save_settings(): void {
        check_admin_referer( 'srm_save_settings' );
        SRM_Settings::save( $_POST );
        wp_redirect( admin_url( 'admin.php?page=srm-settings&srm_notice=settings_saved' ) );
        exit;
    }

    private function handle_export_csv(): void {
        check_admin_referer( 'srm_export_csv' );

        $start = sanitize_text_field( $_POST['export_start'] ?? '' );
        $end   = sanitize_text_field( $_POST['export_end'] ?? '' );

        if ( ! $start ) {
            $start = date( 'Y-m-01' );
        }
        if ( ! $end ) {
            $end = date( 'Y-m-t' );
        }

        SRM_Import_Export::export_csv( $start, $end );
    }

    private function handle_import_csv(): void {
        check_admin_referer( 'srm_import_csv' );

        if ( ! isset( $_FILES['import_file'] ) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK ) {
            wp_redirect( admin_url( 'admin.php?page=srm-import-export&srm_notice=error' ) );
            exit;
        }

        $file    = $_FILES['import_file'];
        $allowed = array( 'text/csv', 'application/vnd.ms-excel', 'text/plain' );

        if ( ! in_array( $file['type'], $allowed, true ) ) {
            wp_redirect( admin_url( 'admin.php?page=srm-import-export&srm_notice=error' ) );
            exit;
        }

        $result = SRM_Import_Export::import_csv( $file['tmp_name'] );

        // Store import result in transient for display
        set_transient( 'srm_import_result_' . get_current_user_id(), $result, 60 );

        wp_redirect( admin_url( 'admin.php?page=srm-import-export&srm_notice=import_done' ) );
        exit;
    }
}
