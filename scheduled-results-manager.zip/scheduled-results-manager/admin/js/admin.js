/**
 * Scheduled Results Manager — Admin JavaScript
 */

/* global srmAdmin, jQuery */
(function ($) {
    'use strict';

    var admin = {

        // -------------------------------------------------------------------
        // Init
        // -------------------------------------------------------------------
        init: function () {
            this.bindSaveSingle();
            this.bindSaveAll();
            this.bindPublishAll();
            this.bindDeleteResult();
            this.bindToggleStatus();
            this.bindSortable();
            this.initAdminCountdown();
        },

        // -------------------------------------------------------------------
        // Save a single result via AJAX
        // -------------------------------------------------------------------
        bindSaveSingle: function () {
            $(document).on('click', '.srm-save-single', function () {
                var $btn     = $(this);
                var eventId  = $btn.data('event-id');
                var date     = $btn.data('date') || $('#srm-result-date').val();
                var $row     = $btn.closest('tr');
                var value    = $row.find('.srm-result-input').val();
                var status   = $row.find('.srm-status-select').val();
                var $spinner = $row.find('.srm-row-status');

                $btn.prop('disabled', true).text(srmAdmin.strings.saving);
                $spinner.text('').removeClass('srm-saved srm-error');

                $.post(srmAdmin.ajaxUrl, {
                    action:         'srm_save_result',
                    nonce:          srmAdmin.nonce,
                    event_id:       eventId,
                    result_date:    date,
                    result_value:   value,
                    result_status:  status,
                }, function (response) {
                    if (response.success) {
                        $spinner.text('✓').addClass('srm-saved');
                        $btn.text('Update');
                        admin.showMessage(response.data.message, 'success');
                    } else {
                        $spinner.text('✗').addClass('srm-error');
                        admin.showMessage(response.data.message || srmAdmin.strings.error, 'error');
                    }
                }).fail(function () {
                    $spinner.text('✗').addClass('srm-error');
                    admin.showMessage(srmAdmin.strings.error, 'error');
                }).always(function () {
                    $btn.prop('disabled', false);
                });
            });
        },

        // -------------------------------------------------------------------
        // Save all results
        // -------------------------------------------------------------------
        bindSaveAll: function () {
            $(document).on('click', '#srm-save-all', function () {
                var $btn  = $(this);
                var date  = $('#srm-result-date').val();
                var total = 0;
                var done  = 0;
                var errors = 0;

                $btn.prop('disabled', true).text(srmAdmin.strings.saving);

                var rows = $('.srm-result-row');
                total    = rows.length;

                if (total === 0) {
                    $btn.prop('disabled', false).text(srmAdmin.strings.saved);
                    return;
                }

                rows.each(function () {
                    var $row    = $(this);
                    var eventId = $row.data('event-id');
                    var value   = $row.find('.srm-result-input').val();
                    var status  = $row.find('.srm-status-select').val();

                    $.post(srmAdmin.ajaxUrl, {
                        action:        'srm_save_result',
                        nonce:         srmAdmin.nonce,
                        event_id:      eventId,
                        result_date:   date,
                        result_value:  value,
                        result_status: status,
                    }, function (resp) {
                        done++;
                        if (!resp.success) { errors++; }
                        if (done === total) {
                            $btn.prop('disabled', false).text(srmAdmin.strings.saved);
                            if (errors === 0) {
                                admin.showMessage('All results saved successfully.', 'success');
                            } else {
                                admin.showMessage(errors + ' result(s) failed to save.', 'error');
                            }
                        }
                    }).fail(function () {
                        done++;
                        errors++;
                        if (done === total) {
                            $btn.prop('disabled', false).text(srmAdmin.strings.saved);
                            admin.showMessage(srmAdmin.strings.error, 'error');
                        }
                    });
                });
            });
        },

        // -------------------------------------------------------------------
        // Publish all results
        // -------------------------------------------------------------------
        bindPublishAll: function () {
            $(document).on('click', '#srm-publish-all', function () {
                $('.srm-status-select').val('published');
                $('#srm-save-all').trigger('click');
            });
        },

        // -------------------------------------------------------------------
        // Delete a result via AJAX
        // -------------------------------------------------------------------
        bindDeleteResult: function () {
            $(document).on('click', '.srm-delete-result', function () {
                if (!confirm(srmAdmin.strings.confirmDelete)) {
                    return;
                }

                var $btn    = $(this);
                var eventId = $btn.data('event-id');
                var date    = $btn.data('date') || $('#srm-result-date').val();
                var $row    = $btn.closest('tr');

                $.post(srmAdmin.ajaxUrl, {
                    action:      'srm_delete_result',
                    nonce:       srmAdmin.nonce,
                    event_id:    eventId,
                    result_date: date,
                }, function (response) {
                    if (response.success) {
                        $row.find('.srm-result-input').val('');
                        $row.find('.srm-status-select').val('pending');
                        $btn.hide();
                        admin.showMessage(response.data.message, 'success');
                    } else {
                        admin.showMessage(response.data.message || srmAdmin.strings.error, 'error');
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // Toggle event active status
        // -------------------------------------------------------------------
        bindToggleStatus: function () {
            $(document).on('click', '.srm-toggle-status', function () {
                var $btn    = $(this);
                var eventId = $btn.data('event-id');

                $btn.prop('disabled', true);

                $.post(srmAdmin.ajaxUrl, {
                    action:   'srm_toggle_game',
                    nonce:    srmAdmin.nonce,
                    event_id: eventId,
                }, function (response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        admin.showMessage(response.data.message || srmAdmin.strings.error, 'error');
                        $btn.prop('disabled', false);
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // Drag-and-drop sortable event list
        // -------------------------------------------------------------------
        bindSortable: function () {
            var $table = $('#srm-sortable-events tbody');
            if (!$table.length || !$.fn.sortable) { return; }

            $table.sortable({
                handle:      '.srm-drag-handle',
                placeholder: 'srm-sortable-placeholder',
                axis:        'y',
                update: function () {
                    var order = [];
                    $table.find('tr[data-event-id]').each(function () {
                        order.push($(this).data('event-id'));
                    });

                    $.post(srmAdmin.ajaxUrl, {
                        action: 'srm_save_event_order',
                        nonce:  srmAdmin.nonce,
                        order:  order,
                    }, function (response) {
                        if (response.success) {
                            admin.showMessage(response.data.message, 'success');
                        }
                    });
                },
            });
        },

        // -------------------------------------------------------------------
        // Admin dashboard countdown
        // -------------------------------------------------------------------
        initAdminCountdown: function () {
            var $cd = $('#srm-admin-countdown');
            if (!$cd.length) { return; }

            function pad(n) {
                return String(n).padStart(2, '0');
            }

            function tick() {
                var ts   = parseInt($cd.data('timestamp'), 10);
                var nowTs = Math.floor(Date.now() / 1000);
                var diff  = Math.max(0, ts - nowTs);
                var h     = Math.floor(diff / 3600);
                var m     = Math.floor((diff % 3600) / 60);
                var s     = diff % 60;
                $cd.text(pad(h) + ':' + pad(m) + ':' + pad(s));
            }

            setInterval(tick, 1000);
            tick();
        },

        // -------------------------------------------------------------------
        // Show an admin AJAX message
        // -------------------------------------------------------------------
        showMessage: function (message, type) {
            var $msg = $('#srm-ajax-message');
            $msg.removeClass('srm-ajax-success srm-ajax-error')
                .addClass('srm-ajax-' + type)
                .text(message)
                .show();

            clearTimeout(admin._msgTimer);
            admin._msgTimer = setTimeout(function () {
                $msg.fadeOut();
            }, 4000);
        },

        _msgTimer: null,
    };

    $(document).ready(function () {
        if (window.srmAdmin) {
            admin.init();
        }
    });

})(jQuery);
