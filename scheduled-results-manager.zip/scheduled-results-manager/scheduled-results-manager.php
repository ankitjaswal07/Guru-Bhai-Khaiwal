<?php
/**
 * Plugin Name: Scheduled Results Manager
 * Plugin URI:  https://example.com/scheduled-results-manager
 * Description: Manage scheduled games, daily results, monthly archives, and live game countdown displays.
 * Version:     1.1.0
 * Author:      Your Name
 * Author URI:  https://example.com
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: scheduled-results-manager
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP:  8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants
define( 'SRM_VERSION', '1.1.0' );
define( 'SRM_PLUGIN_FILE', __FILE__ );
define( 'SRM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SRM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SRM_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Autoload includes
require_once SRM_PLUGIN_DIR . 'includes/class-database.php';
require_once SRM_PLUGIN_DIR . 'includes/class-access.php';
require_once SRM_PLUGIN_DIR . 'includes/class-events.php';
require_once SRM_PLUGIN_DIR . 'includes/class-results.php';
require_once SRM_PLUGIN_DIR . 'includes/class-current-event.php';
require_once SRM_PLUGIN_DIR . 'includes/class-shortcodes.php';
require_once SRM_PLUGIN_DIR . 'includes/class-api.php';
require_once SRM_PLUGIN_DIR . 'includes/class-import-export.php';
require_once SRM_PLUGIN_DIR . 'includes/class-seed.php';
require_once SRM_PLUGIN_DIR . 'includes/class-settings.php';
require_once SRM_PLUGIN_DIR . 'includes/class-plugin.php';

if ( is_admin() ) {
    require_once SRM_PLUGIN_DIR . 'admin/class-admin.php';
}

if ( ! is_admin() ) {
    require_once SRM_PLUGIN_DIR . 'public/class-public.php';
}

// Activation / Deactivation / Uninstall hooks
register_activation_hook( __FILE__, array( 'SRM_Database', 'install' ) );
register_deactivation_hook( __FILE__, array( 'SRM_Plugin', 'deactivate' ) );

/**
 * Initialise the plugin.
 */
function srm_init() {
    // Load text domain
    load_plugin_textdomain(
        'scheduled-results-manager',
        false,
        dirname( SRM_PLUGIN_BASENAME ) . '/languages/'
    );

    // Boot main plugin class
    SRM_Plugin::get_instance();
}
add_action( 'plugins_loaded', 'srm_init' );
