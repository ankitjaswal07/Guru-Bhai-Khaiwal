<?php
/**
 * Uninstall Script
 *
 * Runs when the plugin is deleted from WordPress → Plugins.
 * Only deletes data if the administrator has enabled that option.
 *
 * @package ScheduledResultsManager
 */

// Only run during uninstall
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

require_once plugin_dir_path( __FILE__ ) . 'includes/class-database.php';

// Check setting: delete all data?
$delete = get_option( 'srm_delete_on_uninstall', '0' );

if ( '1' === $delete ) {
    SRM_Database::drop_tables();
    SRM_Database::delete_options();
    SRM_Database::remove_capabilities();
}
