<?php
/**
 * Template: Current Result Card
 *
 * @var object|null $event
 * @var object|null $result
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="srm-wrap srm-event-card-wrap" data-component="current-result"
     data-nonce="<?php echo esc_attr( wp_create_nonce( 'srm_public_nonce' ) ); ?>">

    <div class="srm-event-card-fe">
        <div class="srm-card-label"><?php esc_html_e( 'Current Game', 'scheduled-results-manager' ); ?></div>

        <?php if ( $event ) : ?>
            <div class="srm-card-event-name"><?php echo esc_html( $event->event_name ); ?></div>
            <div class="srm-card-section-label"><?php esc_html_e( 'Time', 'scheduled-results-manager' ); ?></div>
            <div class="srm-card-event-time"><?php echo esc_html( SRM_Games::format_time( $event->scheduled_time ) ); ?></div>

            <?php if ( $result && $result->result_status === 'published' ) : ?>
                <div class="srm-card-section-label"><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></div>
                <div class="srm-card-result-value"><?php echo esc_html( $result->result_value ); ?></div>
            <?php else : ?>
                <div class="srm-card-status-label srm-status-pending">
                    <?php esc_html_e( 'Wait for Result', 'scheduled-results-manager' ); ?>
                </div>
            <?php endif; ?>
        <?php else : ?>
            <div class="srm-card-no-event"><?php esc_html_e( 'No game currently active.', 'scheduled-results-manager' ); ?></div>
        <?php endif; ?>
    </div>
</div>
