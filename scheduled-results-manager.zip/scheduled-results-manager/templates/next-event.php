<?php
/**
 * Template: Next Game Card with Countdown
 *
 * @var object|null $event
 * @var bool        $is_tomorrow
 * @var int         $next_ts   UNIX timestamp of next event
 * @var int         $remaining Seconds remaining
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_countdown = 'yes' === ( $atts['show_countdown'] ?? 'yes' );
$unique_id      = 'srm-next-' . wp_rand( 1000, 9999 );
?>
<div class="srm-wrap srm-event-card-wrap" id="<?php echo esc_attr( $unique_id ); ?>"
     data-component="next-event"
     data-nonce="<?php echo esc_attr( wp_create_nonce( 'srm_public_nonce' ) ); ?>">

    <div class="srm-event-card-fe srm-next-card-fe">
        <div class="srm-card-label"><?php esc_html_e( 'Next Game', 'scheduled-results-manager' ); ?></div>

        <?php if ( $event ) : ?>
            <div class="srm-card-event-name"><?php echo esc_html( $event->event_name ); ?></div>
            <?php if ( ! empty( $event->event_name_secondary ) && false === strpos( (string) $event->event_name, (string) $event->event_name_secondary ) ) : ?>
                <div class="srm-card-event-secondary"><?php echo esc_html( $event->event_name_secondary ); ?></div>
            <?php endif; ?>
            <div class="srm-card-event-time"><?php echo esc_html( SRM_Games::format_time( $event->scheduled_time ) ); ?></div>
            <?php if ( $is_tomorrow ) : ?>
                <div class="srm-card-tomorrow"><?php esc_html_e( 'Tomorrow', 'scheduled-results-manager' ); ?></div>
            <?php endif; ?>

            <?php if ( $show_countdown ) : ?>
            <div class="srm-countdown-wrap">
                <div class="srm-countdown-label"><?php esc_html_e( 'Time Remaining', 'scheduled-results-manager' ); ?></div>
                <div class="srm-countdown" data-timestamp="<?php echo esc_attr( (string) $next_ts ); ?>">
                    <?php
                    // Server-side initial render
                    $h = floor( $remaining / 3600 );
                    $m = floor( ( $remaining % 3600 ) / 60 );
                    $s = $remaining % 60;
                    echo esc_html( sprintf( '%02d:%02d:%02d', $h, $m, $s ) );
                    ?>
                </div>
            </div>
            <?php endif; ?>
        <?php else : ?>
            <div class="srm-card-no-event"><?php esc_html_e( 'No upcoming games.', 'scheduled-results-manager' ); ?></div>
        <?php endif; ?>
    </div>
</div>
