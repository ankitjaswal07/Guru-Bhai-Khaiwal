<?php
/**
 * Template: Latest Timed Game Result Status
 *
 * @var object|null $game
 * @var object|null $result
 * @var string $status
 * @var bool $is_upcoming
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$title          = ! empty( $atts['title'] ) ? sanitize_text_field( $atts['title'] ) : __( 'Latest Game Result', 'scheduled-results-manager' );
$show_secondary = 'yes' === ( $atts['show_secondary'] ?? 'yes' );
$show_result    = 'yes' === ( $atts['show_result'] ?? 'yes' );
$is_published   = $result && 'published' === $status && null !== $result->result_value && '' !== (string) $result->result_value;
?>
<div class="srm-wrap srm-latest-game-status" data-component="latest-game-result" data-show-secondary="<?php echo esc_attr( $show_secondary ? 'yes' : 'no' ); ?>" aria-live="polite">
    <div class="srm-latest-game-card">
        <div class="srm-card-label"><?php echo esc_html( $title ); ?></div>
        <?php if ( $game ) : ?>
            <div class="srm-card-event-name" data-srm-latest-game-name><?php echo esc_html( $game->event_name ); ?></div>
            <div class="srm-card-event-secondary" data-srm-latest-game-secondary<?php echo ( $show_secondary && ! empty( $game->event_name_secondary ) ) ? '' : ' hidden'; ?>><?php echo esc_html( $show_secondary ? (string) $game->event_name_secondary : '' ); ?></div>
            <time class="srm-card-event-time" data-srm-latest-game-time><?php echo esc_html( SRM_Games::format_time( $game->scheduled_time ) ); ?></time>
            <div class="srm-card-status-label <?php echo esc_attr( $is_published ? 'srm-status-published' : ( $is_upcoming ? 'srm-status-upcoming' : 'srm-status-pending' ) ); ?>" data-srm-latest-game-status>
                <?php echo esc_html( $is_published ? __( 'Result Published', 'scheduled-results-manager' ) : __( 'Wait for Result', 'scheduled-results-manager' ) ); ?>
            </div>
            <?php if ( $show_result ) : ?>
                <div class="srm-card-result" data-srm-latest-game-result-wrap<?php echo $is_published ? '' : ' hidden'; ?>>
                    <span class="srm-card-result-label"><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></span>
                    <span class="srm-card-result-value" data-srm-latest-game-result><?php echo esc_html( $is_published ? (string) $result->result_value : '' ); ?></span>
                </div>
            <?php endif; ?>
        <?php else : ?>
            <div class="srm-card-no-event" data-srm-latest-game-empty><?php esc_html_e( 'No active games are configured.', 'scheduled-results-manager' ); ?></div>
        <?php endif; ?>
    </div>
</div>
