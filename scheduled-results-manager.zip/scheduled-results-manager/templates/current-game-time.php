<?php
/**
 * Template: Current Game Time
 *
 * @var object|null $game
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_label = 'yes' === ( $atts['label'] ?? 'yes' );
?>
<div class="srm-wrap srm-focus-value" data-component="current-game-time" aria-live="polite">
    <?php if ( $show_label ) : ?>
        <span class="srm-focus-label"><?php esc_html_e( 'Current Game Time', 'scheduled-results-manager' ); ?></span>
    <?php endif; ?>
    <time class="srm-focus-time" data-srm-current-game-time>
        <?php echo esc_html( $game ? SRM_Games::format_time( $game->scheduled_time ) : '—' ); ?>
    </time>
</div>
