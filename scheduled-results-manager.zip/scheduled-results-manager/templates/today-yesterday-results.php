<?php
/**
 * Template: Today and Yesterday Results
 *
 * @var array<object> $today_results
 * @var array<object> $yesterday_results
 * @var string $today_str
 * @var string $yesterday_str
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_time      = 'yes' === ( $atts['show_time'] ?? 'yes' );
$show_secondary = 'yes' === ( $atts['show_secondary'] ?? 'no' );
$title          = ! empty( $atts['title'] )
    ? sanitize_text_field( $atts['title'] )
    : __( 'Today and Yesterday Results', 'scheduled-results-manager' );

/**
 * Build a combined list of games from both days.
 * Games are matched using event_name.
 */
$combined_games = array();

/**
 * Add Yesterday's games first.
 */
foreach ( $yesterday_results as $row ) {

    $game_key = strtolower( trim( (string) $row->event_name ) );

    if ( '' === $game_key ) {
        continue;
    }

    if ( ! isset( $combined_games[ $game_key ] ) ) {
        $combined_games[ $game_key ] = array(
            'event_name'           => $row->event_name,
            'event_name_secondary' => $row->event_name_secondary ?? '',
            'scheduled_time'       => $row->scheduled_time,
            'yesterday'             => $row,
            'today'                 => null,
        );
    } else {
        $combined_games[ $game_key ]['yesterday'] = $row;
    }
}

/**
 * Add Today's games.
 */
foreach ( $today_results as $row ) {

    $game_key = strtolower( trim( (string) $row->event_name ) );

    if ( '' === $game_key ) {
        continue;
    }

    if ( ! isset( $combined_games[ $game_key ] ) ) {
        $combined_games[ $game_key ] = array(
            'event_name'           => $row->event_name,
            'event_name_secondary' => $row->event_name_secondary ?? '',
            'scheduled_time'       => $row->scheduled_time,
            'yesterday'             => null,
            'today'                 => $row,
        );
    } else {
        $combined_games[ $game_key ]['today'] = $row;

        /**
         * Prefer today's scheduled time when available.
         */
        if ( ! empty( $row->scheduled_time ) ) {
            $combined_games[ $game_key ]['scheduled_time'] = $row->scheduled_time;
        }

        if (
            empty( $combined_games[ $game_key ]['event_name_secondary'] )
            && ! empty( $row->event_name_secondary )
        ) {
            $combined_games[ $game_key ]['event_name_secondary'] = $row->event_name_secondary;
        }
    }
}
?>
<style>
    
    /* Combined Today + Yesterday Results Table */
.srm-combined-results-table {
    width: 100%;
    border-collapse: collapse;
}

/* Make every column equal width */
.srm-combined-results-table th,
.srm-combined-results-table td {
    width: 25%;
    min-width: 85px;
    text-align: center;
    vertical-align: middle;
    border: 1px solid #cdcdcd;
}

/* Center the game name as well */
.srm-combined-results-table .srm-event-col {
    text-align: center;
}

/* Center event name and secondary name */
.srm-combined-results-table .srm-event-primary,
.srm-combined-results-table .srm-event-secondary-fe {
    display: block;
    text-align: center;
}

/* Center game time */
.srm-combined-results-table .srm-time-col {
    text-align: center;
}

/* Center both result columns */
.srm-combined-results-table .srm-result-col {
    text-align: center;
}

/* Keep result text centered */
.srm-combined-results-table .srm-result-published,
.srm-combined-results-table .srm-result-pending {
    display: inline-block;
    text-align: center;
}
p.head-p {
    display: flex;
    justify-content: center;
    gap: 5px;   
}
@media screen and (max-width: 767px) {
    .srm-event-col{padding:5px!important;}
    p.head-p {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    gap:0px;
    max-height: 25px;
    margin: -2px 0 20px;
}
}

</style>
<div class="srm-wrap srm-today-yesterday-results">

    <h3 class="srm-table-title srm-combined-title">
        <?php echo esc_html( $title ); ?>
    </h3>             
    
 <!--span style="color:#fff; text-align:center; font-size:18px;"><?php
    //                     printf(
    //                         esc_html__('(%s)', 'scheduled-results-manager' ),
    //                         esc_html( $today_str )
    //                     );
    //                     ?>
                    </span-->

    <div class="srm-table-responsive">
                       
        <table class="srm-table srm-combined-results-table">

            <thead>
                <tr>

                    <th scope="col">
                        <?php esc_html_e( 'Game', 'scheduled-results-manager' ); ?>
                    </th>

                    <?php if ( $show_time ) : ?>
                        <th scope="col">
                            <?php esc_html_e( 'Game Time', 'scheduled-results-manager' ); ?>
                        </th>
                    <?php endif; ?>

                    <th scope="col">
                        <?php
                        printf(
                           __( '<p class="head-p">Yesterday<span>Result</span></p>', 'scheduled-results-manager' ),
                            esc_html( $yesterday_str )
                        );
                        ?>
                    </th>

                    <th scope="col">
                        <?php
                        printf(
                            // esc_html__( 'Today Result (%s)', 'scheduled-results-manager' ),
                             __( '<p class="head-p">Today<span>Result</span></p>', 'scheduled-results-manager' ),
                            esc_html( $today_str )
                        );
                        ?>
                    </th>

                </tr>
            </thead>

            <tbody>

                <?php if ( ! empty( $combined_games ) ) : ?>

                    <?php foreach ( $combined_games as $game ) : ?>

                        <?php
                        $yesterday = $game['yesterday'];
                        $today     = $game['today'];
                        ?>

                        <tr>

                            <!-- Game Name -->
                            <th scope="row" class="srm-event-col">

                                <span class="srm-event-primary">
                                    <?php echo esc_html( $game['event_name'] ); ?>
                                </span>

                                <?php
                                if (
                                    $show_secondary
                                    && ! empty( $game['event_name_secondary'] )
                                    && false === strpos(
                                        (string) $game['event_name'],
                                        (string) $game['event_name_secondary']
                                    )
                                ) :
                                ?>

                                    <span class="srm-event-secondary-fe">
                                        <?php echo esc_html( $game['event_name_secondary'] ); ?>
                                    </span>

                                <?php endif; ?>

                            </th>

                            <!-- Game Time -->
                            <?php if ( $show_time ) : ?>

                                <td class="srm-time-col">

                                    <?php
                                    if ( ! empty( $game['scheduled_time'] ) ) {
                                        echo esc_html(
                                            SRM_Games::format_time(
                                                $game['scheduled_time']
                                            )
                                        );
                                    } else {
                                        echo '—';
                                    }
                                    ?>

                                </td>

                            <?php endif; ?>


                            <!-- Yesterday Result -->
                            <td class="srm-result-col srm-yesterday-result">

                                <?php
                                if (
                                    $yesterday
                                    && 'published' === $yesterday->result_status
                                    && null !== $yesterday->result_value
                                    && '' !== (string) $yesterday->result_value
                                ) :
                                ?>

                                    <span class="srm-result-published">
                                        <?php echo esc_html( $yesterday->result_value ); ?>
                                    </span>

                                <?php elseif ( $yesterday ) : ?>

                                    <span class="srm-result-pending">
                                        <?php esc_html_e( 'Wait', 'scheduled-results-manager' ); ?>
                                    </span>

                                <?php else : ?>

                                    <span class="srm-result-pending">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- Today Result -->
                            <td class="srm-result-col srm-today-result">

                                <?php
                                if (
                                    $today
                                    && 'published' === $today->result_status
                                    && null !== $today->result_value
                                    && '' !== (string) $today->result_value
                                ) :
                                ?>

                                    <span class="srm-result-published">
                                        <?php echo esc_html( $today->result_value ); ?>
                                    </span>

                                <?php elseif ( $today ) : ?>

                                    <span class="srm-result-pending">
                                        <?php esc_html_e( 'Wait', 'scheduled-results-manager' ); ?>
                                    </span>

                                <?php else : ?>

                                    <span class="srm-result-pending">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else : ?>

                    <tr>

                        <td
                            colspan="<?php echo esc_attr( $show_time ? '4' : '3' ); ?>"
                            class="srm-no-results"
                        >
                            <?php esc_html_e( 'No games found.', 'scheduled-results-manager' ); ?>
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>