<?php
/**
 * Template: Game History
 *
 * @var object       $event
 * @var array<object> $history
 * @var string       $date_format
 * @var string       $month_label
 * @var int          $month
 * @var int          $year
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="srm-wrap srm-event-history">
    <div class="srm-table-header">
        <h3 class="srm-table-title">
            <?php
            printf(
                /* translators: 1: event name, 2: month/year */
                esc_html__( '%1$s — %2$s', 'scheduled-results-manager' ),
                esc_html( $event->event_name ),
                esc_html( $month_label )
            );
            ?>
        </h3>
        <div class="srm-event-meta-info">
            <?php echo esc_html( SRM_Games::format_time( $event->scheduled_time ) ); ?>
        </div>
    </div>

    <?php if ( empty( $history ) ) : ?>
        <p class="srm-no-data"><?php esc_html_e( 'No results found for this period.', 'scheduled-results-manager' ); ?></p>
    <?php else : ?>
    <div class="srm-table-responsive">
        <table class="srm-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Date', 'scheduled-results-manager' ); ?></th>
                    <th><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'scheduled-results-manager' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $history as $record ) : ?>
                <tr>
                    <td class="srm-date-cell">
                        <?php echo esc_html( date( $date_format, strtotime( $record->result_date ) ) ); ?>
                    </td>
                    <td class="srm-result-cell">
                        <?php
                        if ( $record->result_status === 'published' && $record->result_value !== null ) {
                            echo '<span class="srm-result-published">' . esc_html( $record->result_value ) . '</span>';
                        } else {
                            echo '<span class="srm-result-pending">—</span>';
                        }
                        ?>
                    </td>
                    <td>
                        <?php if ( 'published' === $record->result_status ) : ?>
                            <span class="srm-badge-fe srm-badge-fe-success"><?php esc_html_e( 'Published', 'scheduled-results-manager' ); ?></span>
                        <?php else : ?>
                            <span class="srm-badge-fe srm-badge-fe-pending"><?php esc_html_e( 'Pending', 'scheduled-results-manager' ); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
