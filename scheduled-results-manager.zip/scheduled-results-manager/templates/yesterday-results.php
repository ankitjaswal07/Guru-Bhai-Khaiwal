<?php
/**
 * Template: Yesterday's Results
 *
 * @var array<object> $results
 * @var string        $date_str  Formatted date string
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_time      = 'yes' === ( $atts['show_time'] ?? 'yes' );
$show_secondary = 'yes' === ( $atts['show_secondary'] ?? 'no' );
$title          = ! empty( $atts['title'] ) ? esc_html( $atts['title'] ) : esc_html__( "Yesterday's Results", 'scheduled-results-manager' );
?>
<div class="srm-wrap srm-yesterday-results">
    <div class="srm-table-header">
        <h3 class="srm-table-title"><?php echo $title; ?></h3>
        <div class="srm-table-date"><?php esc_html_e( 'Date:', 'scheduled-results-manager' ); ?> <strong><?php echo esc_html( $date_str ); ?></strong></div>
    </div>

    <?php if ( empty( $results ) ) : ?>
        <p class="srm-no-data"><?php esc_html_e( 'No results found for yesterday.', 'scheduled-results-manager' ); ?></p>
    <?php else : ?>
    <div class="srm-table-responsive">
        <table class="srm-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Game', 'scheduled-results-manager' ); ?></th>
                    <?php if ( $show_time ) : ?>
                    <th><?php esc_html_e( 'Game Time', 'scheduled-results-manager' ); ?></th>
                    <?php endif; ?>
                    <th><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $results as $row ) : ?>
                <tr>
                    <td class="srm-event-col">
                        <span class="srm-event-primary"><?php echo esc_html( $row->event_name ); ?></span>
                        <?php if ( $show_secondary && ! empty( $row->event_name_secondary ) && false === strpos( (string) $row->event_name, (string) $row->event_name_secondary ) ) : ?>
                            <span class="srm-event-secondary-fe"><?php echo esc_html( $row->event_name_secondary ); ?></span>
                        <?php endif; ?>
                    </td>
                    <?php if ( $show_time ) : ?>
                    <td class="srm-time-col"><?php echo esc_html( SRM_Games::format_time( $row->scheduled_time ) ); ?></td>
                    <?php endif; ?>
                    <td class="srm-result-col">
                        <?php
                        if ( $row->result_status === 'published' && $row->result_value !== null ) {
                            echo '<span class="srm-result-published">' . esc_html( $row->result_value ) . '</span>';
                        } else {
                            echo '<span class="srm-result-pending">—</span>';
                        }
                        ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
