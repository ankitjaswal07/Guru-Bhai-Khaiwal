<?php
/**
 * Template: Current Game Card
 *
 * @var object|null  $event
 * @var object|null  $result
 * @var string       $status  pending|published|upcoming|none
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_result   = 'yes' === ( $atts['show_result'] ?? 'yes' );
$unique_id     = 'srm-current-' . wp_rand( 1000, 9999 );
?>
<div class="srm-wrap srm-event-card-wrap" id="<?php echo esc_attr( $unique_id ); ?>"
     data-component="current-event"
     data-nonce="<?php echo esc_attr( wp_create_nonce( 'srm_public_nonce' ) ); ?>">

    <div class="srm-event-card-fe">
        <div class="srm-card-label"><?php esc_html_e( 'Current Game', 'scheduled-results-manager' ); ?></div>

        <?php if ( $event ) : ?>
            <div class="srm-card-event-name"><?php echo esc_html( $event->event_name ); ?></div>
            <?php if ( ! empty( $event->event_name_secondary ) && false === strpos( (string) $event->event_name, (string) $event->event_name_secondary ) ) : ?>
                <div class="srm-card-event-secondary"><?php echo esc_html( $event->event_name_secondary ); ?></div>
            <?php endif; ?>
            <div class="srm-card-event-time"><?php echo esc_html( SRM_Games::format_time( $event->scheduled_time ) ); ?></div>

            <div class="srm-card-status">
                <?php if ( 'published' === $status && $result ) : ?>
                    <div class="srm-card-status-label srm-status-published">
                        <?php esc_html_e( 'Result Published', 'scheduled-results-manager' ); ?>
                    </div>
                    <?php if ( $show_result ) : ?>
                    <div class="srm-card-result">
                        <span class="srm-card-result-label"><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></span>
                        <span class="srm-card-result-value"><?php echo esc_html( $result->result_value ); ?></span>
                    </div>
                    <?php endif; ?>
                <?php elseif ( 'upcoming' === $status ) : ?>
                    <div class="srm-card-status-label srm-status-upcoming">
                        <?php esc_html_e( 'Upcoming', 'scheduled-results-manager' ); ?>
                    </div>
                <?php else : ?>
                    <div class="srm-card-status-label srm-status-pending">
                        <?php esc_html_e( 'Waiting for Result', 'scheduled-results-manager' ); ?>
                    </div>
                <?php endif; ?>
            </div>

        <?php else : ?>
            <div class="srm-card-no-event"><?php esc_html_e( 'No game currently active.', 'scheduled-results-manager' ); ?></div>
        <?php endif; ?>
    </div>
</div>
