<?php
/**
 * Template: Live Status (Combined Current + Next)
 *
 * @var object|null $current_game
 * @var object|null $next_game
 * @var object|null $current_result
 * @var string      $current_status
 * @var bool        $is_tomorrow
 * @var int         $next_ts
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_current = 'yes' === ( $atts['show_current'] ?? 'yes' );
$show_next    = 'yes' === ( $atts['show_next'] ?? 'yes' );
$unique_id    = 'srm-live-' . wp_rand( 1000, 9999 );

$interval = (int) get_option( 'srm_ajax_interval', 30 );
$remaining = SRM_Current_Event::get_remaining_seconds();
?>
<div class="srm-wrap srm-live-status-wrap" id="<?php echo esc_attr( $unique_id ); ?>"
     data-component="live-status"
     data-nonce="<?php echo esc_attr( wp_create_nonce( 'srm_public_nonce' ) ); ?>"
     data-interval="<?php echo esc_attr( (string) $interval ); ?>">

    <div class="srm-live-grid">

        <?php if ( $show_current ) : ?>
        <!-- Current Game Panel -->
        <div class="srm-live-panel srm-live-current" id="<?php echo esc_attr( $unique_id ); ?>-current">
            <div class="srm-card-label"><?php esc_html_e( 'Current Game', 'scheduled-results-manager' ); ?></div>

            <?php if ( $current_game ) : ?>
                <div class="srm-card-event-name"><?php echo esc_html( $current_game->event_name ); ?></div>
                <?php if ( ! empty( $current_game->event_name_secondary ) && false === strpos( (string) $current_game->event_name, (string) $current_game->event_name_secondary ) ) : ?>
                    <div class="srm-card-event-secondary"><?php echo esc_html( $current_game->event_name_secondary ); ?></div>
                <?php endif; ?>
                <div class="srm-card-event-time"><?php echo esc_html( SRM_Games::format_time( $current_game->scheduled_time ) ); ?></div>

                <?php if ( 'published' === $current_status && $current_result ) : ?>
                    <div class="srm-card-status-label srm-status-published">
                        <?php esc_html_e( 'Result Published', 'scheduled-results-manager' ); ?>
                    </div>
                    <div class="srm-card-result">
                        <span class="srm-card-result-label"><?php esc_html_e( 'Result', 'scheduled-results-manager' ); ?></span>
                        <span class="srm-card-result-value"><?php echo esc_html( $current_result->result_value ); ?></span>
                    </div>
                <?php else : ?>
                    <div class="srm-card-status-label srm-status-pending">
                        <?php esc_html_e( 'Waiting for Result', 'scheduled-results-manager' ); ?>
                    </div>
                <?php endif; ?>
            <?php else : ?>
                <div class="srm-card-no-event"><?php esc_html_e( 'No game currently active.', 'scheduled-results-manager' ); ?></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ( $show_next ) : ?>
        <!-- Next Game Panel -->
        <div class="srm-live-panel srm-live-next" id="<?php echo esc_attr( $unique_id ); ?>-next">
            <div class="srm-card-label"><?php esc_html_e( 'Next Game', 'scheduled-results-manager' ); ?></div>

            <?php if ( $next_game ) : ?>
                <div class="srm-card-event-name"><?php echo esc_html( $next_game->event_name ); ?></div>
                <?php if ( ! empty( $next_game->event_name_secondary ) && false === strpos( (string) $next_game->event_name, (string) $next_game->event_name_secondary ) ) : ?>
                    <div class="srm-card-event-secondary"><?php echo esc_html( $next_game->event_name_secondary ); ?></div>
                <?php endif; ?>
                <div class="srm-card-event-time"><?php echo esc_html( SRM_Games::format_time( $next_game->scheduled_time ) ); ?></div>
                <?php if ( $is_tomorrow ) : ?>
                    <div class="srm-card-tomorrow"><?php esc_html_e( 'Tomorrow', 'scheduled-results-manager' ); ?></div>
                <?php endif; ?>

                <div class="srm-countdown-wrap">
                    <div class="srm-countdown-label"><?php esc_html_e( 'Time to Game', 'scheduled-results-manager' ); ?></div>
                    <div class="srm-countdown" data-timestamp="<?php echo esc_attr( (string) $next_ts ); ?>">
                        <?php
                        $h = floor( $remaining / 3600 );
                        $m = floor( ( $remaining % 3600 ) / 60 );
                        $s = $remaining % 60;
                        echo esc_html( sprintf( '%02d:%02d:%02d', $h, $m, $s ) );
                        ?>
                    </div>
                </div>
            <?php else : ?>
                <div class="srm-card-no-event"><?php esc_html_e( 'No upcoming games.', 'scheduled-results-manager' ); ?></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </div>
</div>
