<?php
/**
 * Template: Current Game Name
 *
 * @var object|null $game
 * @var array<string,string> $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$show_secondary = 'yes' === ( $atts['show_secondary'] ?? 'yes' );
$show_label     = 'yes' === ( $atts['label'] ?? 'yes' );
?>
<div class="srm-wrap srm-focus-value" data-component="current-game-name" data-show-secondary="<?php echo esc_attr( $show_secondary ? 'yes' : 'no' ); ?>" aria-live="polite">
    <?php if ( $show_label ) : ?>
        <span class="srm-focus-label"><?php esc_html_e( 'Current Game', 'scheduled-results-manager' ); ?></span>
    <?php endif; ?>
    <span class="srm-focus-primary" data-srm-current-game-name>
        <?php echo esc_html( $game ? $game->event_name : __( 'No game currently active.', 'scheduled-results-manager' ) ); ?>
    </span>
    <span class="srm-focus-secondary" data-srm-current-game-secondary<?php echo ( $game && $show_secondary && ! empty( $game->event_name_secondary ) ) ? '' : ' hidden'; ?>>
        <?php echo esc_html( $game && $show_secondary ? (string) $game->event_name_secondary : '' ); ?>
    </span>
</div>
