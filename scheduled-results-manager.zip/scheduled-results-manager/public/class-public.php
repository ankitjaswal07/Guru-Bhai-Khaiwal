<?php
/**
 * Public-facing Class
 *
 * @package ScheduledResultsManager
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SRM_Public
 */
class SRM_Public {

    /**
     * Init public hooks.
     */
    public function init(): void {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_head',            array( $this, 'output_css_vars' ) );
    }

    /**
     * Enqueue frontend assets.
     */
    public function enqueue_assets(): void {
        wp_enqueue_style(
            'srm-frontend',
            SRM_PLUGIN_URL . 'public/css/frontend.css',
            array(),
            SRM_VERSION
        );

        $countdown_enabled = get_option( 'srm_countdown_enabled', '1' );

        wp_enqueue_script(
            'srm-frontend',
            SRM_PLUGIN_URL . 'public/js/frontend.js',
            array( 'jquery' ),
            SRM_VERSION,
            true
        );

        wp_localize_script( 'srm-frontend', 'srmFrontend', array(
            'ajaxUrl'          => admin_url( 'admin-ajax.php' ),
            'restUrl'          => rest_url( 'srm/v1/current' ),
            'nonce'            => wp_create_nonce( 'srm_public_nonce' ),
            'interval'         => (int) get_option( 'srm_ajax_interval', 30 ) * 1000,
            'countdownEnabled' => $countdown_enabled,
            'strings'          => array(
                'waitForResult'   => __( 'Wait for Result', 'scheduled-results-manager' ),
                'resultPublished' => __( 'Result Published', 'scheduled-results-manager' ),
                'waitingResult'   => __( 'Waiting for Result', 'scheduled-results-manager' ),
                'noGame'          => __( 'No game currently active.', 'scheduled-results-manager' ),
                'tomorrow'        => __( 'Tomorrow', 'scheduled-results-manager' ),
                'timeRemaining'   => __( 'Time Remaining', 'scheduled-results-manager' ),
            ),
        ) );
    }

    /**
     * Output CSS custom properties in <head>.
     */
    public function output_css_vars(): void {
        echo '<style id="srm-css-vars">' . SRM_Settings::get_css_vars() . '</style>' . "\n";
    }
}
