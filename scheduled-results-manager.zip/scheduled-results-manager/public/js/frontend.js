/**
 * Scheduled Results Manager — Frontend JavaScript
 * Handles: countdown timers, live AJAX updates.
 */

/* global srmFrontend, jQuery */
(function ($) {
    'use strict';

    // -----------------------------------------------------------------------
    // Countdown timers
    // -----------------------------------------------------------------------

    /**
     * Pad a number to 2 digits.
     * @param {number} n
     * @returns {string}
     */
    function pad(n) {
        return String(n).padStart(2, '0');
    }

    /**
     * Format seconds into HH:MM:SS.
     * @param {number} seconds
     * @returns {string}
     */
    function formatSeconds(seconds) {
        if (seconds <= 0) {
            return '00:00:00';
        }
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        return pad(h) + ':' + pad(m) + ':' + pad(s);
    }

    /**
     * Update a single countdown element.
     * @param {jQuery} $el
     * @param {number} targetTs - UNIX timestamp (seconds) of target event time
     */
    function updateCountdown($el, targetTs) {
        var nowTs   = Math.floor(Date.now() / 1000);
        var diff    = targetTs - nowTs;
        var display = formatSeconds(Math.max(0, diff));
        $el.text(display);
        return diff;
    }

    /**
     * Start countdown timers on all [data-timestamp] elements.
     */
    function initCountdowns() {
        $('.srm-countdown[data-timestamp]').each(function () {
            var $el    = $(this);
            var ts     = parseInt($el.data('timestamp'), 10);

            if (!ts) { return; }

            // Tick every second
            var interval = setInterval(function () {
                var diff = updateCountdown($el, ts);
                if (diff <= 0) {
                    clearInterval(interval);
                    // When countdown finishes, trigger a live update
                    fetchLiveStatus();
                }
            }, 1000);

            // Initial render
            updateCountdown($el, ts);
        });
    }

    // -----------------------------------------------------------------------
    // Live Status AJAX Updates
    // -----------------------------------------------------------------------

    /**
     * Fetch live status from the REST API or AJAX.
     */
    function fetchLiveStatus() {
        var restUrl = (srmFrontend && srmFrontend.restUrl) ? srmFrontend.restUrl : null;

        if (!restUrl) {
            return;
        }

        $.getJSON(restUrl, function (data) {
            updateLiveComponents(data);
        }).fail(function () {
            // Silently fail — do not disturb the user
        });
    }

    /**
     * Update all live-status components with fresh data.
     * @param {Object} data - Response from /wp-json/srm/v1/current
     */
    function updateLiveComponents(data) {
        if (!data) { return; }

        var cur    = data.current_game;
        var latest = data.latest_game || cur || data.next_game;
        var next   = data.next_game;

        // Update current-game cards and current-result cards.
        $('[data-component="current-event"], [data-component="current-result"]').each(function () {
            updateCurrentEventPanel($(this), cur);
        });

        // Update focused current-game name output.
        $('[data-component="current-game-name"]').each(function () {
            var $wrap = $(this);
            var strings = srmFrontend ? srmFrontend.strings : {};
            $wrap.find('[data-srm-current-game-name]').text(cur ? (cur.name || '') : (strings.noGame || 'No game currently active.'));
            if ($wrap.data('show-secondary') !== 'no' && cur && cur.name_secondary) {
                $wrap.find('[data-srm-current-game-secondary]').text(cur.name_secondary).prop('hidden', false).show();
            } else {
                $wrap.find('[data-srm-current-game-secondary]').prop('hidden', true).hide();
            }
        });

        // Update focused current-game time output.
        $('[data-component="current-game-time"]').each(function () {
            $(this).find('[data-srm-current-game-time]').text(cur ? (cur.time || '—') : '—');
        });

        // Update latest game/time/result-status output.
        $('[data-component="latest-game-result"]').each(function () {
            updateLatestGamePanel($(this), latest);
        });

        // Update all next-game components.
        $('[data-component="next-event"]').each(function () {
            updateNextEventPanel($(this), next);
        });

        // Update combined live-status panels.
        $('[data-component="live-status"]').each(function () {
            var $wrap = $(this);
            updateCurrentEventPanel($wrap.find('.srm-live-current'), cur);
            updateNextEventPanel($wrap.find('.srm-live-next'), next);
        });

        // Admin dashboard countdown
        if (next && next.timestamp) {
            $('#srm-admin-countdown').data('timestamp', next.timestamp);
        }
    }

    /**
     * Render the current-event panel.
     * @param {jQuery} $panel
     * @param {Object|null} cur
     */
    function updateCurrentEventPanel($panel, cur) {
        if (!$panel.length) { return; }

        var strings = srmFrontend ? srmFrontend.strings : {};

        if (!cur) {
            $panel.find('.srm-card-event-name').text(strings.noGame || 'No game currently active.');
            $panel.find('.srm-card-event-secondary, .srm-card-event-time, .srm-card-status').hide();
            return;
        }

        // Game name
        $panel.find('.srm-card-event-name').text(cur.name || '');

        // Secondary name
        if (cur.name_secondary) {
            $panel.find('.srm-card-event-secondary').text(cur.name_secondary).show();
        } else {
            $panel.find('.srm-card-event-secondary').hide();
        }

        // Time
        $panel.find('.srm-card-event-time').text(cur.time || '').show();

        // Status
        var $status = $panel.find('.srm-card-status, .srm-card-status-label');

        if (cur.status === 'published' && cur.result !== null && cur.result !== '') {
            $panel.find('.srm-card-status-label')
                .text(strings.resultPublished || 'Result Published')
                .removeClass('srm-status-pending srm-status-upcoming')
                .addClass('srm-status-published')
                .show();

            $panel.find('.srm-card-result-value').text(cur.result).show();
            $panel.find('.srm-card-result').show();
        } else {
            $panel.find('.srm-card-status-label')
                .text(strings.waitingResult || 'Waiting for Result')
                .removeClass('srm-status-published srm-status-upcoming')
                .addClass('srm-status-pending')
                .show();

            $panel.find('.srm-card-result').hide();
        }
    }

    /**
     * Render the focused latest-game result panel.
     * @param {jQuery} $panel
     * @param {Object|null} game
     */
    function updateLatestGamePanel($panel, game) {
        if (!$panel.length || !game) { return; }

        var strings = srmFrontend ? srmFrontend.strings : {};
        var published = game.status === 'published' && game.result !== null && game.result !== '';
        var $status = $panel.find('[data-srm-latest-game-status]');

        $panel.find('[data-srm-latest-game-name]').text(game.name || '');
        $panel.find('[data-srm-latest-game-time]').text(game.time || '—');
        $panel.find('[data-srm-latest-game-empty]').hide();

        if ($panel.data('show-secondary') !== 'no' && game.name_secondary) {
            $panel.find('[data-srm-latest-game-secondary]').text(game.name_secondary).prop('hidden', false).show();
        } else {
            $panel.find('[data-srm-latest-game-secondary]').prop('hidden', true).hide();
        }

        $status
            .text(published ? (strings.resultPublished || 'Result Published') : (strings.waitForResult || 'Wait for Result'))
            .removeClass('srm-status-published srm-status-pending srm-status-upcoming')
            .addClass(published ? 'srm-status-published' : (game.status === 'upcoming' ? 'srm-status-upcoming' : 'srm-status-pending'))
            .show();

        if (published) {
            $panel.find('[data-srm-latest-game-result]').text(game.result);
            $panel.find('[data-srm-latest-game-result-wrap]').prop('hidden', false).show();
        } else {
            $panel.find('[data-srm-latest-game-result-wrap]').prop('hidden', true).hide();
        }
    }

    /**
     * Render the next-game panel.
     * @param {jQuery} $panel
     * @param {Object|null} next
     */
    function updateNextEventPanel($panel, next) {
        if (!$panel.length) { return; }

        if (!next) { return; }

        $panel.find('.srm-card-event-name').text(next.name || '');
        $panel.find('.srm-card-event-time').text(next.time || '');

        if (next.name_secondary) {
            $panel.find('.srm-card-event-secondary').text(next.name_secondary).show();
        } else {
            $panel.find('.srm-card-event-secondary').hide();
        }

        // Tomorrow label
        if (next.is_tomorrow) {
            $panel.find('.srm-card-tomorrow').show();
        } else {
            $panel.find('.srm-card-tomorrow').hide();
        }

        // Update countdown target and re-tick
        if (next.timestamp) {
            $panel.find('.srm-countdown').data('timestamp', next.timestamp);
        }
    }

    // -----------------------------------------------------------------------
    // Periodic live updates
    // -----------------------------------------------------------------------

    function startLivePolling() {
        var interval = (srmFrontend && srmFrontend.interval) ? srmFrontend.interval : 30000;

        // Minimum 10 seconds
        interval = Math.max(interval, 10000);

        setInterval(fetchLiveStatus, interval);
    }

    // -----------------------------------------------------------------------
    // Admin countdown (dashboard)
    // -----------------------------------------------------------------------

    function initAdminCountdowns() {
        var $adminCd = $('#srm-admin-countdown');
        if (!$adminCd.length) { return; }

        setInterval(function () {
            var ts = parseInt($adminCd.data('timestamp'), 10);
            if (ts) {
                updateCountdown($adminCd, ts);
            }
        }, 1000);
    }

    // -----------------------------------------------------------------------
    // DOMReady
    // -----------------------------------------------------------------------

    $(document).ready(function () {

        // Only run if plugin data is present
        if (!window.srmFrontend) { return; }

        // Countdown timers
        if (srmFrontend.countdownEnabled !== '0') {
            initCountdowns();
            initAdminCountdowns();
        }

        // Live polling
        var hasLiveComponents = $('[data-component]').length > 0;
        if (hasLiveComponents) {
            startLivePolling();
        }

    });

})(jQuery);
